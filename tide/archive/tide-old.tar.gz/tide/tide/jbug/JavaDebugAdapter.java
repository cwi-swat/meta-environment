package tide.jbug;

//{ imports

import aterm.*;
import aterm.tool.ToolException;

import java.util.*;
import java.net.*;
import java.io.*;
import com.sun.jdi.*;
import com.sun.jdi.connect.*;
import com.sun.jdi.event.*;
import com.sun.jdi.request.*;

//}

public class JavaDebugAdapter
  extends DebugAdapterTif
  implements DebugState
{
	private VirtualMachine vm;
	private static int nextID = 0;
	private Map threadByID;
	private Map threadByRef;

	private EventQueue eventQueue;
	private EventRequestManager requests;
	private EventHandler handler;
	private Thread handlerThread;

	private String breakThreadName    = null;
	private String breakClass         = null;
	private String breakMethod        = null;
	private DebugThread breakThread   = null;
	private ClassPrepareRequest prepareRequest = null;
	private BreakpointRequest breakRequest = null;

	//{ class EventLoop

	class EventHandler
	  implements Runnable
	{
		private JavaDebugAdapter adapter;
		private EventQueue queue;
		private Thread thread;
		private boolean running;

		public EventHandler(EventQueue queue, JavaDebugAdapter adapter)
		{
			this.queue = queue;
			this.adapter = adapter;
			thread = new Thread(this);
			thread.start();
		}

		public void run()
		{
			running = true;

			while(running) {
				try {
					EventSet events = queue.waitEvent();
					adapter.handleEvents(events);
				} catch (InterruptedException e) {
				} catch (VMDisconnectedException e) {
					running = false;
				} catch (Exception e) {
					System.err.println("exception received: ");
					e.printStackTrace();
				}
			}
		}
	}

	//}

	//{ public static void main(String[] args)

	/**
		* Startup a new JavaDebugAdapter
		*/

	public static void main(String[] args)
		throws IllegalConnectorArgumentsException, VMStartException, IOException,
		       ToolException
	{
		int i;

		VirtualMachineManager manager = Bootstrap.virtualMachineManager();
		List connectors = manager.launchingConnectors();
		ListIterator it = connectors.listIterator();
		LaunchingConnector connector = (LaunchingConnector)it.next();
	  Map arguments = connector.defaultArguments();

		Connector.Argument main = (Connector.Argument)arguments.get("main");
		String argString = null;
		
		String breakMethod = null;
		for(i=0; i<args.length && !args[i].startsWith("-app"); i++)
			;

		for(++i; i<args.length; i++) {
			if(argString == null)
				argString = "";
			else
				argString += " ";
			argString += args[i];
		}

		main.setValue(argString);
		arguments.put("main", main);
		System.err.println("args = " + arguments);

		Iterator allargs = arguments.values().iterator();
		while(allargs.hasNext()) {
			Connector.Argument arg = (Connector.Argument)allargs.next();
			System.err.println("name:        " + arg.name());
			System.err.println("description: " + arg.description());
			System.err.println("mustSpecify: " + arg.mustSpecify());
			System.err.println("value:       " + arg.value());
		}		

		VirtualMachine vm = connector.launch(arguments);
		System.err.println("vm = " + vm);
		/*while(it.hasNext()) {
			LaunchingConnector connector = (LaunchingConnector)it.next();
			System.err.println("l.c.: " + connector.description());
			System.err.println("args: " + connector.defaultArguments());
		}
		*/

		JavaDebugAdapter adapter = new JavaDebugAdapter(vm, args);
		adapter.connect();
		adapter.start();
	}

	//}

	//{ public JavaDebugAdapter(VirtualMachine vm, String[] args)

	/**
		* Create a new JavaDebugAdapter object
		*/

	public JavaDebugAdapter(VirtualMachine vm, String[] args)
		throws UnknownHostException
	{
		super(args);
		this.vm = vm;
		threadByID  = new HashMap();
		threadByRef = new HashMap();

		eventQueue = vm.eventQueue();
		requests = vm.eventRequestManager();

		int i;
		breakThreadName = "main";
		breakMethod     = "main";
		for(i=0; i<args.length && !args[i].startsWith("-app"); i++) {
			if(args[i].equals("-break")) {
				//{ Handle break spec
				
				String breakSpec = args[++i];
				int idx = breakSpec.indexOf(':');
				if(idx >= 0) {
					breakThreadName = breakSpec.substring(0, idx);
					breakSpec = breakSpec.substring(idx+1);
				}
				
				idx = breakSpec.lastIndexOf('.');
				if(idx >= 0) {
					breakClass = breakSpec.substring(0, idx);
					breakSpec = breakSpec.substring(idx+1);
				}
				
				breakMethod = breakSpec;
				
				//}
			}
		}

		if(i<args.length && args[i].startsWith("-app") && breakClass == null) {
			if(args[i].startsWith("-app") && breakClass == null) {
				breakClass = args[++i];
			}
		}
	}

	//}

	//{ public void threadCreated(ThreadReference t)

	/**
		* A new thread has been created
		*/

	public void threadCreated(ThreadReference t)
	{
		String id = t.name();
		DebugThread thread = new DebugThread(this, id, t, vm);
		threadByID.put(id, thread);
		threadByRef.put(t, thread);

		if(breakThreadName != null && breakThreadName.equals(t.name())) {
			System.err.println("breaking at: " + breakThreadName + ":" +
												 breakClass + "." + breakMethod);
			prepareRequest = requests.createClassPrepareRequest();
			prepareRequest.addClassFilter(breakClass);
			prepareRequest.enable();
			breakThread  = thread;

			//breakRequest = requests.createMethodEntryRequest();
			//breakRequest.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
			//breakRequest.addClassFilter(breakClass);
			//breakRequest.addThreadFilter(t);
			//breakRequest.enable();
		}

		try {
			event((ATermAppl)ATerm.make("process-created(<str>)", id));
			System.err.println("processCreated: " + id);
		} catch (ToolException e) {
			System.err.println("tool exception: " + e.getMessage());
		}

		t.resume();
	}

	//}

	//{ public void start()

	/**
		* Start the execution by gathering all running (non-system) threads
		*/

	public void start()
	{
		StepRequest request;

/*		List threads = vm.allThreads();
		Iterator iter = threads.iterator();
		while(iter.hasNext()) {
			ThreadReference thread = (ThreadReference)iter.next();
			threadCreated(thread);
		}
		*/
		ThreadStartRequest startRequest = requests.createThreadStartRequest();
		startRequest.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
		startRequest.enable();

		handler = new EventHandler(eventQueue, this);

		vm.resume();

		run();
	}

	//}
	//{ public void handleEvents(EventSet events)

	/**
		* Handle a set of debugging events
		*/

	public void handleEvents(EventSet events)
	{
		System.err.println("events: " + events);
		EventIterator iter = events.eventIterator();
		while(iter.hasNext()) {
			Event event = iter.nextEvent();
			EventRequest request = event.request();
			if(request != null && request == prepareRequest) {
				//{ Handling prepareRequest

				ReferenceType type = ((ClassPrepareEvent)event).referenceType();
				List methods = type.methodsByName(breakMethod);
				Iterator it = methods.iterator();
				while(it.hasNext()) {
					requests.deleteEventRequest(prepareRequest);
					prepareRequest = null;
					Method method  = (Method)it.next();
					try {
						Location start = (Location)method.allLineLocations().get(0);
						System.err.println("Method: " + method + ", location: " + start);
						breakRequest   = requests.createBreakpointRequest(start);
						breakRequest.addThreadFilter(breakThread.getThreadReference());
						breakRequest.enable();
					} catch (AbsentInformationException e) {
						System.err.println("no debugging information for class " +
															 breakClass);
					}
					breakThread.getThreadReference().resume();
				}

				//}
			} if(request != null && request == breakRequest) {
				//{ Handle the initial break event

				System.err.println("event: " + event);
				requests.deleteEventRequest(breakRequest);
				breakRequest = null;
				breakThread.handleEvent(event, DebugRule.PORT_INITIAL);

				//}
			} else if(event instanceof VMStartEvent) {
				//{ Handle a VMStartEvent

				ThreadReference first = ((VMStartEvent)event).thread();
				//threadCreated(first);
				//System.err.println("first thread created: " + first.name());

				//}
			} else if(event instanceof ThreadStartEvent) {
				//{ Handle a ThreadStartEvent

				ThreadReference thread = ((ThreadStartEvent)event).thread();
				System.err.println("thread created: " + thread.name());
				threadCreated(thread);

				//}
			} else if(event instanceof ThreadDeathEvent) {
				//{ Handle a ThreadDeathEvent

				System.err.println("thread death! " + 
													 ((ThreadDeathEvent)event).thread());

				//}
			} else if(event instanceof StepEvent) {
				//{ Handle a StepEvent

				StepRequest stepRequest = (StepRequest)request;
				DebugThread thread = 
					(DebugThread)threadByRef.get(stepRequest.thread());
				if(thread != null) {
					System.err.println("handling step event: " + event);
					thread.handleEvent(event, DebugRule.PORT_STEP);
				} else 
					System.err.println("ignoring event: " + event);

				//}
			} else if(event instanceof BreakpointEvent) {
				//{ Handle a BreakpointEvent

				DebugThread thread =
					(DebugThread)threadByRef.get(((BreakpointEvent)event).thread());
				if(thread != null) {
					System.err.println("handling break event: " + event);
					thread.handleEvent(event, DebugRule.PORT_LOCATION);
				} else
					System.err.println("ignoring event: " + event);

				//}
			}
		}
		System.err.println("handleEvents done: " + events);
	}

	//}

	//{ ATerm createRule(String id, ATerm owner, ATerm port, ATerm cond,ATerm acts)

	ATerm createRule(String pid, ATerm owner, ATerm type, ATerm port, ATerm cond, ATerm act)
	{
		DebugThread thread = (DebugThread)threadByID.get(pid);
		int id = nextID++;
		Integer ID = new Integer(id);
		DebugRule rule = new DebugRule(id, pid, thread.getThreadReference(), 
																	 owner, type, port, cond, act);
		thread.addRule(rule);
		Vector args = new Vector(7);
		args.addElement(pid);
		args.addElement(owner);
		args.addElement(ID);
		args.addElement(type);
		args.addElement(port);
		args.addElement(cond);
		args.addElement(act);
		return ATerm.make("snd-value(rule-created(<str>,<term>,<int>,<term>," +
											"<term>,<term>,<term>))", args.elements());
	}

	//}
	//{ void modifyRule(String id, owner, ruleId, port, cond, acts)

	void modifyRule(String id, ATerm owner, int ruleId, 
									ATerm port, ATerm cond, ATerm acts)
	{
	}

	//}
	//{ void deleteRule(String id, ATerm owner, int ruleId)

	void deleteRule(String id, ATerm owner, int ruleId)
	{
	}

	//}
	//{ void enableRule(String pid, ATerm creator, int ruleID)

	/**
		* Enable a rule
		*/

	void enableRule(String pid, ATerm creator, int ruleID)
	{
		DebugThread thread = (DebugThread)threadByID.get(pid);
		thread.enableRule(ruleID);
	}

	//}
	//{ void disableRule(String pid, ATerm creator, int ruleID)

	/**
		* Disable a rule
		*/

	void disableRule(String pid, ATerm creator, int ruleID)
	{
		DebugThread thread = (DebugThread)threadByID.get(pid);
		thread.disableRule(ruleID);
	}

	//}

	//{ ATerm evaluate(String id, ATerm acts)

	ATerm evaluate(String id, ATerm acts)
	{
		System.err.println("evaluate: id=" + id + ", acts=" + acts);
		DebugThread thread = (DebugThread)threadByID.get(id);
		ATerm result = evaluate(thread, acts);

		return ATerm.make("snd-value(evaluated(<str>,<term>,<term>))",
											id, acts, result);
	}

	//}
	//{ public ATerm evaluate(DebugThread thread, ATerm acts)

	/**
		* Evaluate a number of actions
		*/

	public ATerm evaluate(DebugThread thread, ATerm acts)
	{
		Vector matches;

		System.err.println("evaluate: thread=" + thread + ", acts=" + acts);
		if(acts.getType() == ATerm.LIST) {
			//{ Evaluate all entries in a list

			ATermList list = (ATermList)acts;
			ATermList result = ATerm.the_world.empty;
			while(!list.isEmpty()) {
				ATerm res = evaluate(thread, list.getFirst());
				list = list.getNext();
				if(res.match("true") != null)
					result = result.append(res);
			}
			if(result.isEmpty())
				return ATerm.make("true");
			return (ATerm)result;

			//}
		}

		//{ true

		if(acts.match("true") != null) {
			return acts;
		}

		//}
		//{ break

		if(acts.match("break") != null) {
			thread.doBreak();
			return ATerm.make("true");
		}

		//}
		//{ resume

		if(acts.match("resume") != null) {
			thread.resume();
			return ATerm.make("true");
		}

		//}
		//{ cpe

		if(acts.match("cpe") != null) {
			try {
				if(thread.getThreadReference().frameCount() == 0)
					return ATerm.make("cpe(unknown)");

				StackFrame frame = thread.getThreadReference().frame(0);
				System.err.println("frame=" + frame);
				Location location = frame.location();
				System.err.println("location=" + location);
				int linenr = location.lineNumber();
				String source = location.sourceFile();

				String relpath;
				ObjectReference object = frame.thisObject();
				if(object != null) {
					ReferenceType   type   = object.referenceType();
					String name = type.name();
					int index = name.lastIndexOf('.');
					name = name.substring(0, index);
					relpath = name.replace('.', '/') + "/" + source;
				} else {
					relpath = source;
				}

				return ATerm.make("cpe(line(<str>,<int>))", 
													relpath, new Integer(linenr));
			} catch (IncompatibleThreadStateException e) {
				return ATerm.make("error(<str>)", e.getMessage());
			} catch (AbsentInformationException e) {
				return ATerm.make("cpe(unknown)");
			}
		}

		//}
		//{ equal(<term>,<term>)

		matches = acts.match("equal(<term>,<term>)");
		if(matches != null) {
			ATerm expr1 = (ATerm)matches.elementAt(0);
			ATerm expr2 = (ATerm)matches.elementAt(1);
			ATerm val1 = evaluate(thread, expr1);
			ATerm val2 = evaluate(thread, expr2);

			if(val1.equals(val2))
				return ATerm.parse("true");
			else
				return ATerm.parse("false");
		}

		//}
		//{ higher-equal(<term>,<term>)

		matches = acts.match("higher-equal(<term>,<term>)");
		if(matches != null) {
			ATerm expr1 = (ATerm)matches.elementAt(0);
			ATerm expr2 = (ATerm)matches.elementAt(1);

			ATerm val1 = evaluate(thread, expr1);
			ATerm val2 = evaluate(thread, expr2);

			if(val1.getType() == ATerm.INT && val2.getType() == ATerm.INT) {
				if(((ATermInt)val1).getInt() >= ((ATermInt)val2).getInt())
					return ATerm.parse("true");
				else
					return ATerm.parse("false");
			}

			return ATerm.make("error(\"type error in higher-equal\",<term>,<term>)",
												val1, val2);
		}

		//}
		//{ quote(<term>)

		matches = acts.match("quote(<term>)");
		if(matches != null)
			return (ATerm)matches.elementAt(0);

		//}
		//{ start-depth

		if(acts.match("start-depth") != null) {
			// Return the starting frame depth
			return ATerm.parse("" + thread.getStartFrameDepth());
		}	

		//}
		//{ current-depth

		if(acts.match("current-depth") != null) {
			// Return the current frame depth
			return ATerm.parse("" + thread.getCurrentFrameDepth());
		}	

		//}
		//{ state

		if(acts.match("state") != null) {
			// The current execution-state of this process
			if(thread.isRunning())
				return ATerm.parse("running");
			else
				return ATerm.parse("stopped");
		}

		//}
		//{ disable

		matches = acts.match("disable(<list>)");
		if(matches != null) {
			ATermList rules = (ATermList)matches.elementAt(0);
			if(rules.isEmpty()) {
				// Disable the current rule
				thread.disableRule(thread.getCurrentRule().getID());
			} else {
				// Disable all argument rules
				while(!rules.isEmpty()) {
					int ruleID = ((ATermInt)rules.getFirst()).getInt();
					thread.disableRule(ruleID);
					rules = rules.getNext();
				}
			}
			return ATerm.make("true");
		}

		//}

		return ATerm.make("unknown-command(<term>)", acts);
	}

	//}
	//{ public void watchpoint(DebugThread thread, DebugRule rule, ATerm value)

	/**
		* Generate a watchpoint event
		*/

	public void watchpoint(DebugThread thread, DebugRule rule, ATerm value)
	{
		try {
			post((ATermAppl)ATerm.make("watchpoint(<term>,<str>,<int>,<term>)",
																 rule.getOwner(), thread.getID(),
																 new Integer(rule == null ? -1 : rule.getID()), value));
		} catch (ToolException e) {
			System.err.println("ToolException: " + e.getMessage());
		}
	}

	//}

	//{ void recTerminate(ATerm t)

	void recTerminate(ATerm t)
	{
	}

	//}
	//{ void recAckEvent(ATerm t0)

	void recAckEvent(ATerm evt)
	{
	}

	//}
}
