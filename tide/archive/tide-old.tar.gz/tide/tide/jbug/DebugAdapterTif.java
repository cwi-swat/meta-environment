// Java tool interface class DebugAdapterTif
// This file is generated automatically, please do not edit!
// generation time: Sep 2, 1999 2:26:56 PM

package tide.jbug;
import aterm.*;
import aterm.tool.*;
import java.net.UnknownHostException;
import java.net.InetAddress;
import java.util.Vector;
import java.util.Hashtable;


abstract public class DebugAdapterTif extends Tool
{
  // This table will hold the complete input signature
  private Hashtable sigTable = new Hashtable();

  // Declare the patterns that are used to match against incoming terms
  private ATerm PenableRule0;
  private ATerm PdisableRule0;
  private ATerm PmodifyRule0;
  private ATerm PdeleteRule0;
  private ATerm Pevaluate0;
  private ATerm PcreateRule0;
  private ATerm PrecTerminate0;
  private ATerm PrecAckEvent0;

  // Mimic the three constructors from the Tool class
  protected DebugAdapterTif(String name) throws UnknownHostException { super(name); init(); }
  protected DebugAdapterTif(String name, InetAddress address, int port) throws UnknownHostException  { super(name, address, port); init(); }
  protected DebugAdapterTif(String[] args) throws UnknownHostException { super(args); init(); }

  // Initializations common to all constructors
  private void init() { initSigTable(); initPatterns(); }

  // This method initializes the table with input signatures
  private void initSigTable()
  {
    try {
      sigTable.put(world.parse("rec-terminate(<control>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<debug-adapter>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<debug-tool>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<painter>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<visualizer>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<painter>,execute-command(<int>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<painter>,destroy-canvas(<int>))"), new Boolean(true));
      sigTable.put(world.parse("rec-eval(<painter>,create-canvas)"), new Boolean(true));
      sigTable.put(world.parse("rec-eval(<visualizer>,get-templates)"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<visualizer>,update(vis-key(<term>,<int>),<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-ack-event(<visualizer>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<visualizer>,visualize(vis-key(<term>,<int>),canvas-key(<painter>,<int>),<str>,<str>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-tool>,event(<term>,<term>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-ack-event(<debug-tool>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-adapter>,delete-rule(<str>,<term>,<int>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-adapter>,modify-rule(<str>,<term>,<int>,<term>,<term>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-adapter>,disable-rule(<str>,<term>,<int>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-adapter>,enable-rule(<str>,<term>,<int>))"), new Boolean(true));
      sigTable.put(world.parse("rec-eval(<debug-adapter>,create-rule(<str>,<term>,<term>,<term>,<term>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-eval(<debug-adapter>,evaluate(<str>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-ack-event(<debug-adapter>,<term>)"), new Boolean(true));
    } catch (ParseError e) { }
  }

  // Initialize the patterns that are used to match against incoming terms
  private void initPatterns()
  {
    try {
      PenableRule0 = world.parse("rec-do(enable-rule(<str>,<term>,<int>))");
      PdisableRule0 = world.parse("rec-do(disable-rule(<str>,<term>,<int>))");
      PmodifyRule0 = world.parse("rec-do(modify-rule(<str>,<term>,<int>,<term>,<term>,<term>))");
      PdeleteRule0 = world.parse("rec-do(delete-rule(<str>,<term>,<int>))");
      Pevaluate0 = world.parse("rec-eval(evaluate(<str>,<term>))");
      PcreateRule0 = world.parse("rec-eval(create-rule(<str>,<term>,<term>,<term>,<term>,<term>))");
      PrecTerminate0 = world.parse("rec-terminate(<term>)");
      PrecAckEvent0 = world.parse("rec-ack-event(<term>)");
    } catch (ParseError e) {}
  }


  // Override these abstract methods to handle incoming ToolBus terms
  abstract void enableRule(String s0, ATerm t1, int i2) throws ToolException;
  abstract void disableRule(String s0, ATerm t1, int i2) throws ToolException;
  abstract void modifyRule(String s0, ATerm t1, int i2, ATerm t3, ATerm t4, ATerm t5) throws ToolException;
  abstract void deleteRule(String s0, ATerm t1, int i2) throws ToolException;
  abstract ATerm evaluate(String s0, ATerm t1) throws ToolException;
  abstract ATerm createRule(String s0, ATerm t1, ATerm t2, ATerm t3, ATerm t4, ATerm t5) throws ToolException;
  abstract void recTerminate(ATerm t0) throws ToolException;
  abstract void recAckEvent(ATerm t0) throws ToolException;

  // The generic handler calls the specific handlers
  protected ATerm handler(ATerm term)
	throws ToolException
  {
    Vector result;
        result = term.match(PenableRule0);
    if(result != null) {
      enableRule((String)result.elementAt(0), (ATerm)result.elementAt(1), ((Integer)result.elementAt(2)).intValue());
      return null;
    }

    result = term.match(PdisableRule0);
    if(result != null) {
      disableRule((String)result.elementAt(0), (ATerm)result.elementAt(1), ((Integer)result.elementAt(2)).intValue());
      return null;
    }

    result = term.match(PmodifyRule0);
    if(result != null) {
      modifyRule((String)result.elementAt(0), (ATerm)result.elementAt(1), ((Integer)result.elementAt(2)).intValue(), (ATerm)result.elementAt(3), (ATerm)result.elementAt(4), (ATerm)result.elementAt(5));
      return null;
    }

    result = term.match(PdeleteRule0);
    if(result != null) {
      deleteRule((String)result.elementAt(0), (ATerm)result.elementAt(1), ((Integer)result.elementAt(2)).intValue());
      return null;
    }

    result = term.match(Pevaluate0);
    if(result != null) {
      return evaluate((String)result.elementAt(0), (ATerm)result.elementAt(1));
    }

    result = term.match(PcreateRule0);
    if(result != null) {
      return createRule((String)result.elementAt(0), (ATerm)result.elementAt(1), (ATerm)result.elementAt(2), (ATerm)result.elementAt(3), (ATerm)result.elementAt(4), (ATerm)result.elementAt(5));
    }

    result = term.match(PrecTerminate0);
    if(result != null) {
      recTerminate((ATerm)result.elementAt(0));
      return null;
    }

    result = term.match(PrecAckEvent0);
    if(result != null) {
      recAckEvent((ATerm)result.elementAt(0));
      return null;
    }


      notInInputSignature(term);
    return null;
  }

  // Check the input signature
  protected void checkInputSignature(ATermList sigs)
         throws ToolException
  {
    while(!sigs.isEmpty()) {
      ATermAppl sig = (ATermAppl)sigs.getFirst();
      sigs = sigs.getNext();
      if(!sigTable.containsKey(sig)) {
        // Sorry, but the term is not in the input signature!
        notInInputSignature(sig);
      }
    }
  }

  // This function is called when an input term
  // was not in the input signature.
  void notInInputSignature(ATerm t)
        throws ToolException
  {
    throw new ToolException(this, "term not in input signature", t);
  }
}

