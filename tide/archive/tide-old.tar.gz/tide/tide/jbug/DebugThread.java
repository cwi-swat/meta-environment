package tide.jbug;

import aterm.*;

import java.util.*;

import com.sun.jdi.*;
import com.sun.jdi.request.*;
import com.sun.jdi.event.*;

public class DebugThread
{
	DebugState state;

	VirtualMachine vm;
	EventRequestManager requests;

	String id;
	ThreadReference thread;
	StepRequest stepRequest;

	Map rulesByID;
	Map[] rules = new Map[DebugRule.NR_PORT_TYPES];

	boolean starting;
	int nrEnabledStepRules;

	boolean running;
	int startFrame;

	DebugRule currentRule;

	//{ public DebugThread(JavaDebugAdapter adapter, String id, t, vm)

	public DebugThread(DebugState state, String id, 
										 ThreadReference t, VirtualMachine vm)
	{
		this.id  = id;
		thread   = t;

		this.state = state;
		this.vm = vm;
		//vm.setDebugTraceMode(VirtualMachine.TRACE_ALL);

		rulesByID = new HashMap();

		for(int i=0; i<DebugRule.NR_PORT_TYPES; i++) {
			rules[i] = new HashMap(10);
		}

	  requests = vm.eventRequestManager();

		stepRequest = requests.createStepRequest(thread, StepRequest.STEP_LINE,
																						 StepRequest.STEP_INTO);
		stepRequest.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
		//stepRequest.enable();

		/*ThreadGroupReference group = thread.threadGroup();
		if(!group.name().equals("system")) {
			stepRequest.enable();
			starting = true;
		}
		*/
	}

	//}
	//{ public String getID()

	/**
		* Retrieve the ID of this thread
		*/

	public String getID()
	{
		return id;
	}

	//}
	//{ public ThreadReference getThreadReference()

	/**
		* Retrieve the threadreference for this thread
		*/

	public ThreadReference getThreadReference()
	{
		return thread;
	}

	//}
	//{ ClassType findClassType(String file)

	/**
		* Find the classtype of a file
		*/

	ClassType findClassType(String file)
	{
		String fqn = file.substring(0, file.length()-5).replace('/', '.');
		System.err.println("searching for class-type: " + fqn);
		Iterator iter = vm.allClasses().iterator();
		while(iter.hasNext()) {
			ReferenceType reftype = (ReferenceType)iter.next();
			if(reftype.name().equals(fqn)) {
				if(reftype instanceof ClassType) {
					System.err.println("found: " + reftype.name());
					return (ClassType)reftype;
				}
			}
			System.err.println("  not equal: " + reftype.name());
		}
		return null;
	}

	//}
	//{ Location  findLocation(String file, int line)

	/**
		* Find a specific location
		*/

	Location findLocation(String file, int line)
	{
		ClassType classtype = findClassType(file);
		if(classtype == null)
			return null;

		try {
			List locs   = classtype.locationsOfLine(line);
			if(locs.size() != 0) {
				Location location = (Location)locs.get(0);
				System.err.println("location found: " + location);
				return location;
			}
		} catch (AbsentInformationException e) {
		}

		System.err.println("no code at line: " + line + " in file: " + file);

		return null;
	}

	//}

	//{ public void resume()

	/**
		* Resume execution of this thread
		*/

	public void resume()
	{
		System.err.println("resuming thread..");
		System.err.println("isSuspended = " + thread.isSuspended());
		System.err.println("status = " + getStatusString());

		if(!running) {
			try {
				startFrame = thread.frameCount();
			} catch (IncompatibleThreadStateException e) {
				startFrame = 0;
			}
			System.err.println("**** FIRING RULES WITH PORT 'STARTED'");
			running = true;
			condFireEnabledRules(DebugRule.PORT_STARTED);
		}

		if(nrEnabledStepRules > 0)
			stepRequest.enable();
		else
			stepRequest.disable();

		System.err.println("BEFORE RESUME");
		thread.resume();
		System.err.println("AFTER RESUME");
		/*System.err.println("isSuspended = " + thread.isSuspended());
		System.err.println("status = " + getStatusString());
		*/
		System.err.println("leaving resume()");
	}

	//}
	//{ public void doBreak()

	/**
		* Stop this thread
		*/

	public void doBreak()
	{
		running = false;
		System.err.println("suspending thread!");
	}

	//}

	//{ public void addRule(DebugRule rule)

	/**
		* Add a new rule
		*/

	public void addRule(DebugRule rule)
	{
		Integer id = new Integer(rule.getID());

		System.err.println("adding rule: " + rule);
		rulesByID.put(id, rule);
		ATerm port = rule.getPort();
		int porttype = rule.getPortType();
		rules[porttype].put(id, rule);

		switch(porttype) {
			case DebugRule.PORT_STEP:
				//{ Prepare for single stepping

				System.err.println("%%% step rule count: " + 
													 rules[porttype].size());

				//}
				break;

			case DebugRule.PORT_LOCATION:
				//{ The request should be a breakRequest at the port location

				Vector result = rule.getPort().match("location(line(<str>,<int>))");
				if(result == null)
					throw new RuntimeException("unknown location spec: " + rule.getPort());
				String file = (String)result.elementAt(0);
				int line    = ((Integer)result.elementAt(1)).intValue();
				Location loc = findLocation(file, line);
				if(loc != null) {
					BreakpointRequest breakRequest;
					breakRequest = requests.createBreakpointRequest(loc);
					rule.setRequest(breakRequest);
				}

				//}
				break;
		}
	}

	//}
	//{ public void enableRule(int ruleId)

	/**
		* Enable a specific rule
		*/

	public void enableRule(int ruleID)
	{
		DebugRule rule = (DebugRule)rulesByID.get(new Integer(ruleID));
		rule.setEnabled(true);

		System.err.println("enabling rule: " + rule + ", porttype=" +
											 rule.getPortType());

		switch(rule.getPortType()) {
			case DebugRule.PORT_STEP:
				//{ Handle STEP port enabling

				nrEnabledStepRules++;
				System.err.println("enabling STEP rule: " + nrEnabledStepRules);

				//}
				break;
		}
	}

	//}
	//{ public void disableRule(int ruleId)

	/**
		* Disable a specific rule
		*/

	public void disableRule(int ruleID)
	{
		DebugRule rule = (DebugRule)rulesByID.get(new Integer(ruleID));
		rule.setEnabled(false);

		switch(rule.getPortType()) {
			case DebugRule.PORT_STEP:
				//{ Handle STEP port enabling

				--nrEnabledStepRules;
				System.err.println("disabling STEP rule: " + nrEnabledStepRules);

				//}
				break;
		}

	}

	//}

	//{ public void handleEvent(Event event, int porttype)

	/**
		* Handle a specific event
		*/

	public void handleEvent(Event event, int porttype)
	{
		Iterator iter;

	  System.err.println("handleEvent: " + porttype);

		switch(porttype) {
			case DebugRule.PORT_INITIAL:
				running = false;
				break;

			case DebugRule.PORT_STEP:
				//thread.resume();
				condFireEnabledRules(DebugRule.PORT_STEP);
				break;
		}

		if(running) {
			System.err.println("before resume");
			resume();
			System.err.println("after resume");
		} else
			condFireEnabledRules(DebugRule.PORT_STOPPED);
	}

	//}
	//{ public void condFireEnabledRules(int porttype)

	/**
		* Fire all enabled rules for a certain porttype
		*/

	public void condFireEnabledRules(int porttype)
	{
		System.err.println("### rule count (" + porttype + ") : " + 
											 rules[porttype].size());

		Iterator iter = rules[porttype].values().iterator();
		while(iter.hasNext()) {
			DebugRule rule = (DebugRule)iter.next();
			System.err.println("rule: " + rule + ", enabled: " + rule.isEnabled());
			if(rule.isEnabled())
				condFireRule(rule);
		}
	}

	//}
	//{ public void condFireRule(DebugRule rule)

	/**
		* Conditionally fire a debug rule
		*/

	public void condFireRule(DebugRule rule)
	{
		DebugRule oldRule;

		System.err.println("condFireRule: " + rule);
		oldRule = currentRule;
		ATerm result = state.evaluate(this, rule.getCondition());

		if(result.match("true") != null) {
			fireRule(rule);
		} else {
			System.err.println("condition failed: " + rule.getCondition());
		}

		currentRule = oldRule;
	}

	//}
	//{ public void fireRule(DebugRule rule)

	/**
		* Actually fire a rule
		*/

	public void fireRule(DebugRule rule)
	{
		System.err.println("fireRule: " + rule);
		ATerm result = state.evaluate(this, rule.getAction());
		if(result.match("true") == null) {
			state.watchpoint(this, rule, result);
			System.err.println("watchpoint activated: " + result);
		}
	}

	//}

	//{ public boolean isRunning()

	/**
		* Retrieve execution state
		*/

	public boolean isRunning()
	{
		return running;
	}

	//}
	//{ public String getStatusString()

	/**
		* Retrieve the status of this thread as a String
		*/

	public String getStatusString()
	{
		switch(thread.status()) {
			case ThreadReference.THREAD_STATUS_UNKNOWN:
				return "unknown";
			case ThreadReference.THREAD_STATUS_ZOMBIE:
				return "zombie";
			case ThreadReference.THREAD_STATUS_RUNNING:
				return "running";
			case ThreadReference.THREAD_STATUS_SLEEPING:
				return "sleeping";
			case ThreadReference.THREAD_STATUS_MONITOR:
				return "in-monitor";
			case ThreadReference.THREAD_STATUS_WAIT:
				return "waiting";

			default: return "*unknown*";
		}
	}

//}
	//{ public int getStartFrameDepth()

	/**
		* Retrieve the current start frame
		*/

	public int getStartFrameDepth()
	{
		return startFrame;
	}

	//}
	//{ public int getCurrentFrameDepth()

	/**
		* Retrieve the current frame
		*/

	public int getCurrentFrameDepth()
	{
		try {
			return thread.frameCount();
		} catch (IncompatibleThreadStateException e) {
			return 0;
		}
	}

	//}
	//{ public DebugRule getCurrentRule()

	/**
		* Retrieve the rule that is currently being fired
		*/

	public DebugRule getCurrentRule()
	{
		return currentRule;
	}

	//}
}



