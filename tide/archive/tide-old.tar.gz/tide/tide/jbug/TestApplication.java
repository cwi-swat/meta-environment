package tide.jbug;

public class TestApplication
{
	public static void abc(int arg)
	{
		System.out.println("abc: " + arg);
	}

	public static void main(String[] args)
	{
		System.out.println("Test application.");
		for(int i=0; i<args.length; i++) {
			System.out.println("argument " + i + " = " + args[i]);
		}
		for(int i=0; i<100000; i++) {
			abc(i);
		}
		System.out.println("Done!");
	}
}
