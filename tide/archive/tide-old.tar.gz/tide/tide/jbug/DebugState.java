package tide.jbug;

import aterm.*;

public interface DebugState
{
	public ATerm evaluate(DebugThread thread, ATerm expr);
	public void watchpoint(DebugThread thread, DebugRule rule, ATerm value);
}
