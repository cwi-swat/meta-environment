package tide.jbug;

import aterm.*;
import com.sun.jdi.*;
import com.sun.jdi.request.*;

public class DebugRule
{
	//{ Port types

	protected final static int PORT_INITIAL      = 0;
	protected final static int PORT_STEP         = 1;
	protected final static int PORT_LOCATION     = 2;
	protected final static int PORT_VAR_ACCESS   = 3;
	protected final static int PORT_EXPR_CHANGED = 4;
	protected final static int PORT_METHOD_ENTRY = 5;
	protected final static int PORT_METHOD_EXIT  = 6;
	protected final static int PORT_STOPPED      = 7;
	protected final static int PORT_STARTED      = 8;
	protected final static int PORT_EXCEPTION    = 9;
	protected final static int NR_PORT_TYPES     = 10;

	//}

	int id;
	String pid;
	ThreadReference thread;
	ATerm owner;
	ATerm type;
	ATerm port;
	int porttype;
	ATerm cond;
	ATerm act;
	boolean enabled;
	EventRequest request;

	//{ public DebugRule(id, pid, thread, owner, type, port, cond, act)

	public DebugRule(int id, String pid, ThreadReference thread,
									 ATerm owner, ATerm type, ATerm port, ATerm cond, ATerm act)
	{
		this.id     = id;
		this.pid    = pid;
		this.thread = thread;
		this.owner  = owner;
		this.type   = type;
		this.port   = port;
		this.cond   = cond;
		this.act    = act;

		if(port.match("step") != null)
			porttype = PORT_STEP;
		else if(port.match("location(<term>)") != null)
			porttype = PORT_LOCATION;
		else if(port.match("stopped") != null)
			porttype = PORT_STOPPED;
		else if(port.match("started") != null)
			porttype = PORT_STARTED;
	}

	//}
	//{ public int getID()
	
	/**
		* Retrieve this rule's ID
		*/

	public int getID()
	{
		return id;
	}

	//}
	//{ public ATerm getOwner()

	/**
		* Retrieve the owner of this rule
		*/

	public ATerm getOwner()
	{
		return owner;
	}

	//}

	//{ public boolean isEnabled()

	/**
		* Is this rule enabled?
		*/

	public boolean isEnabled()
	{
		return enabled;
	}

	//}
	//{ public void setEnabled(boolean on)

	/**
		* Change the enabling status of this rule
		*/

	public void setEnabled(boolean on)
	{
		enabled = on;
		if(request != null) {
			System.out.println("enabling request: " + request + " for rule " + getID());
			request.setEnabled(on);
		}
	}

	//}

	//{ public void setRequest(EventRequest request)

	/**
		* Set the request connected to this rule
		*/

	public void setRequest(EventRequest request)
	{
		this.request = request;
	}

	//}
	//{ public EventRequest getRequest()

	/**
		* Retrieve this rule's request
		*/

	public EventRequest getRequest()
	{
		return request;
	}

	//}
	//{ public int getPortType()

	/**
		* Retrieve the port type of this rule
		*/

	public int getPortType()
	{
		return porttype;
	}

	//}
	//{ public ATerm getPort()

	/**
		* Retrieve the port of this rule
		*/

	public ATerm getPort()
	{
		return port;
	}

	//}
	//{ public ATerm getCondition()

	/**
		* Retrieve the condition of this rule
		*/

	public ATerm getCondition()
	{
		return cond;
	}

	//}
	//{ public ATerm getAction()

	/**
		* Retrieve the action of this rule
		*/

	public ATerm getAction()
	{
		return act;
	}

	//}

	//{ public String toString()

	/**
		* Return a string representation of this rule
		*/

	public String toString()
	{
		return "" + id + " - " + port + "," + cond + "," + act;
	}

	//}
}
