package tide.debug;

import aterm.*;

public class DebugActionFactory
{
	public static DebugAction parse(String spec)
		throws ParseError
	{
		ATerm term = ATerm.parse(spec);
		return new DebugAction(term);
	}

	public static DebugAction createAction(ATerm act)
	{
		return new DebugAction(act);
	}
}
