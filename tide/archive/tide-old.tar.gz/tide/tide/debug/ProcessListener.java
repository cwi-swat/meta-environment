package tide.debug;

public interface ProcessListener
{
	public void processCreated(DebugProcess process, DebugProcessGroup parent);
	public void processDestroyed(DebugProcess process);
	public void processGroupCreated(DebugProcessGroup group, DebugProcessGroup parent);
	public void processGroupDestroyed(DebugProcessGroup group);
}
