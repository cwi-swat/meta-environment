package tide.debug;

import aterm.*;

import java.util.*;

public class Port
{
	//{ Port types

	public final static int PORT_INITIAL      = 0;
	public final static int PORT_STEP         = 1;
	public final static int PORT_LOCATION     = 2;
	public final static int PORT_VAR_ACCESS   = 3;
	public final static int PORT_EXPR_CHANGED = 4;
	public final static int PORT_METHOD_ENTRY = 5;
	public final static int PORT_METHOD_EXIT  = 6;
	public final static int PORT_STOPPED      = 7;
	public final static int PORT_STARTED      = 8;
	public final static int PORT_EXCEPTION    = 9;
	public final static int PORT_SEND         = 10;
	public final static int PORT_RECEIVE      = 11;
	public final static int NR_PORT_TYPES     = 12;

	//}

	ATerm spec;
	int type;

	//{ protected Port(ATerm spec)

	protected Port(ATerm spec)
	{
		this.spec = spec;

		String fun = ((ATermAppl)spec).getName();

		if(fun.equals("initial"))
			type = PORT_INITIAL;
		else if(fun.equals("step"))
			type = PORT_STEP;
		else if(fun.equals("location"))
			type = PORT_LOCATION;
		else if(fun.equals("var-access"))
			type = PORT_VAR_ACCESS;
		else if(fun.equals("expr-changed"))
			type = PORT_EXPR_CHANGED;
		else if(fun.equals("method-entry"))
			type = PORT_METHOD_ENTRY;
		else if(fun.equals("method-exit"))
			type = PORT_METHOD_EXIT;
		else if(fun.equals("stopped"))
			type = PORT_STOPPED;
		else if(fun.equals("started"))
			type = PORT_STARTED;
		else if(fun.equals("exception"))
			type = PORT_EXCEPTION;
		else if(fun.equals("send"))
			type = PORT_SEND;
		else if(fun.equals("receive"))
			type = PORT_RECEIVE;
		else
			throw new RuntimeException("strange port: " + spec);
	}

	//}
	//{ public ATerm toTerm()

	public ATerm toTerm()
	{
		return spec;
	}

	//}
	//{ public String toString()

	public String toString()
	{
		return spec.toString();
	}

	//}

	//{ public int getType()

	/**
		* Retrieve the porttype
		*/

	public int getType()
	{
		return type;
	}

	//}

	// Type specific methods
	//{ public String getLocationFileName()

	/**
		* Retrieve the filename of a location
		*/

	public String getLocationFileName()
	{
		if(type != PORT_LOCATION)
			throw new RuntimeException("not a location: " + spec);

		Vector result;

		result = spec.match("location(line(<str>,<int>))");
		if(result != null)
			return (String)result.elementAt(0);

		result = spec.match("location(pos(<str>,<int>,<int>))");
		if(result != null)
			return (String)result.elementAt(0);

		result = spec.match("location(area(<str>,<int>,<int>,<int>,<int>))");
		if(result != null)
			return (String)result.elementAt(0);
		
		throw new RuntimeException("unknown location spec: " + spec);
	}

	//}
	//{ public int getLocationLineNr()

	/**
		* Retrieve the line number of a location
		*/

	public int getLocationLineNr()
	{
		if(type != PORT_LOCATION)
			throw new RuntimeException("not a location: " + spec);

		Vector result;

		result = spec.match("location(pos(<str>,<int>,<int>))");
		if(result != null)
			return ((Integer)result.elementAt(1)).intValue();

		result = spec.match("location(line(<str>,<int>))");
		if(result != null)
			return ((Integer)result.elementAt(1)).intValue();

		result = spec.match("location(area(<str>,<int>,<int>,<int>,<int>))");
		if(result != null)
			return ((Integer)result.elementAt(1)).intValue();

		throw new RuntimeException("unknown location spec: " + spec);
	}

	//}	
	//{ public int getLocationColumn()

	/**
		* Retrieve the column of a location
		*/

	public int getLocationColumn()
	{
		if(type != PORT_LOCATION)
			throw new RuntimeException("not a location: " + spec);

		Vector result;

		result = spec.match("location(line(<str>,<int>))");
		if(result != null)
			return 0;

		result = spec.match("location(pos(<str>,<int>,<int>))");
		if(result != null)
			return ((Integer)result.elementAt(2)).intValue();

		result = spec.match("location(area(<str>,<int>,<int>,<int>,<int>))");
		if(result != null)
			return ((Integer)result.elementAt(2)).intValue();

		throw new RuntimeException("unknown location spec: " + spec);
	}

	//}	
	//{ public SourceArea getLocationArea()

	/**
		* Retrieve the source area of a location
		*/

	public SourceArea getLocationSourceArea()
	{
		if(type != PORT_LOCATION)
			throw new RuntimeException("not a location: " + spec);

		Vector result;

		result = spec.match("location(line(<str>,<int>))");
		if(result != null) {
			int line = ((Integer)result.elementAt(1)).intValue();
			return new SourceArea(line, 0, line, -1);
		}

		result = spec.match("location(area(<str>,<int>,<int>,<int>,<int>))");
		if(result != null) {
			int sl, sc, el, ec;
			sl = ((Integer)result.elementAt(1)).intValue();
			sc = ((Integer)result.elementAt(2)).intValue();
			el = ((Integer)result.elementAt(3)).intValue();
			ec = ((Integer)result.elementAt(4)).intValue();
			return new SourceArea(sl, sc, el, ec);
		}

		throw new RuntimeException("unknown location spec: " + spec);
	}

	//}	
}
