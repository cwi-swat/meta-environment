package tide.debug;

public class SourceArea
{
	public int start_line;
	public int start_col;
	public int end_line;
	public int end_col;

	public SourceArea(int sl, int sc, int el, int ec)
	{
		start_line = sl;
		start_col  = sc;
		end_line   = el;
		end_col    = ec;
	}

	public String toString()
	{
		return "" + start_line + "," + start_col + "-" + 
			end_line + "," + (end_col == -1 ? "eol" : "" + end_col);
	}
}
