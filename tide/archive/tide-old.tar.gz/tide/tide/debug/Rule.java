package tide.debug;

import tide.tools.*;

import java.util.*;

public class Rule
{
  DebugProcess process;
	String    type;
	int       ruleID;
	boolean   enabled;
	Port      port;
	Condition condition;
	DebugAction action;

	List watchpointListeners;

	//{ public Rule(process, ruleID, type, port, condition, action)

	/**
		* Construct a new rule
		*/

	public Rule(DebugProcess process, int ruleID, 
							String type, Port port, Condition condition, DebugAction action)
	{
		this.process   = process;
		this.ruleID    = ruleID;
		this.type      = type;
		this.port      = port;
		this.condition = condition;
		this.action    = action;
		watchpointListeners = new Vector();
	}

	//}
	//{ public Rule(String type)

	/**
		* Construct an empty rule
		*/

	public Rule(String type)
	{
		this.type = type;
	}

	//}

	//{ public void addWatchpointListener(WatchpointListener listener)

	/**
		* Add a debug listener
		*/

	public void addWatchpointListener(WatchpointListener listener)
	{
		watchpointListeners.add(listener);
	}

	//}
	//{ public void removeWatchpointListener(WatchpointListener listener)

	/**
		* Remove a debug listener
		*/

	public void removeWatchpointListener(WatchpointListener listener)
	{
		watchpointListeners.remove(listener);
	}

	//}
	//{ public void fireWatchpoint(Value value)

	/**
		* Fire a watchpoint-event
		*/

	public void fireWatchpoint(Value value)
	{
		Iterator iter = watchpointListeners.iterator();
		while(iter.hasNext()) {
			WatchpointListener listener = (WatchpointListener)iter.next();
			listener.watchpoint(this, value);
		}
	}

	//}

	//{ public void modify(Port port, Condition cond, DebugAction act)

	/**
		* Modify this rule
		*/

	public void modify(Port port, Condition cond, DebugAction act)
	{
		this.port = port;
		condition = cond;
		action    = act;
	}

	//}
	//{ public Object clone()

	/**
		* Clone this Rule object
		*/

	public Object clone()
	{
		Rule copy = new Rule(process, ruleID, type, port, 
												 condition, action);
		return copy;
	}

	//}

	//{ public String getType()

	/**
		* Retrieve the type of this rule
		*/

	public String getType()
	{
		return type;
	}

	//}
	//{ public int getID()

	/**
		* Retrieve the ID of this rule
		*/

	public int getID()
	{
		return ruleID;
	}

	//}
	//{ public DebugProcess getProcess()

	/**
		* Retrieve the process for this rule
		*/

	public DebugProcess getProcess()
	{
		return process;
	}

	//}
	//{ public boolean isEnabled()

	/**
		* Return enabled status
		*/

	public boolean isEnabled()
	{
		return enabled;
	}

	//}
	//{ public void setEnabled(boolean on)

	/**
		* Change the enabled status of this rule
		*/

	public void setEnabled(boolean on)
	{
		enabled = on;
	}

	//}
	//{ public Port getPort()

	/**
		* Retrieve the port of this rule
		*/

	public Port getPort()
	{
		return port;
	}

	//}
	//{ public Condition getCondition()

	/**
		* Retrieve the condition of this rule
		*/

	public Condition getCondition()
	{
		return condition;
	}

	//}
	//{ public boolean isConditional()

	/**
		* Check whether a rule is conditional
		*/

	public boolean isConditional()
	{
		if(condition.toTerm().match("true") != null)
			return false;

		return true;
	}

	//}
	//{ public boolean isBreak()

	/**
		* Check whether a rule is a breakpoint
		*/

	public boolean isBreak()
	{
		if(action.toTerm().match("break") != null)
			return true;

		return false;
	}

	//}
	//{ public DebugAction getAction()

	/**
		* Retrieve the action of this rule
		*/

	public DebugAction getAction()
	{
		return action;
	}

	//}

	//{ public void requestEnabling(boolean enabled)

	/**
		* Request rule enabling for this rule
		*/

	public void requestEnabling(boolean enabled)
	{
		process.requestRuleEnabling(this, enabled);
	}

	//}

	//{ public String toString()

	/**
		* Return a string represention of this rule for debugging purposes
		*/

	public String toString()
	{
		return "" + ruleID;
	}

	//}
}
