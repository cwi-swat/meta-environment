package tide.debug;

import java.util.*;
import javax.swing.tree.*;

public class DebugProcessGroup
  extends DefaultMutableTreeNode
{
	String ID;

	//{ public DebugProcessGroup(String ID)

	public DebugProcessGroup(String ID)
	{
		this.ID = ID;
	}

	//}
	//{ public String getID()

	/**
		* Retrieve the process-id of this process
		*/

	public String getID()
	{
		return ID;
	}

	//}
	//{ public String toString()

	/**
		* Retrieve the string representation of this object
		*/

	public String toString()
	{
		return ID;
	}

	//}
}

