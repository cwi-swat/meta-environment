package tide.debug;

import aterm.*;

public class PortFactory
{
	public static Port parse(String spec)
		throws ParseError
	{
		ATerm term = ATerm.parse(spec);
		return new Port(term);
	}

	public static Port createPort(ATerm port)
	{
		return new Port(port);
	}
}
