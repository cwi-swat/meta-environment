package tide.debug;

import tide.tools.*;

import java.util.*;

public abstract class DebugInterface
{
	List listeners;
	Map tools;

	//{ public DebugInterface()

	/**
		* Construct a new DebugInterface object
		*/

	public DebugInterface()
	{
		listeners = new Vector();
		tools = new HashMap();
	}

	//}

	abstract public DebugProcessGroup getRoot();

	//{ public void addProcessListener(ProcessListener listener)

	/**
		* Add a debug listener
		*/

	public void addProcessListener(ProcessListener listener)
	{
		listeners.add(listener);
	}

	//}
	//{ public void removeProcessListener(ProcessListener listener)

	/**
		* Remove a debug listener
		*/

	public void removeProcessListener(ProcessListener listener)
	{
		listeners.remove(listener);
	}

	//}

	//{ public void registerTool(TideTool tool)

	/**
		* Register a debug-tool
		*/

	public void registerTool(TideTool tool)
	{
		tools.put(tool.getName(), tool);
	}

	//}
	//{ public void unregisterTool(TideTool tool)

	/**
		* Unregister a specific tool
		*/

	public void unregisterTool(TideTool tool)
	{
		tools.remove(tool.getName());
	}

	//}
	//{ public TideTool getTool(String name)

	/**
		* Retrieve a specific tool
		*/

	public TideTool getTool(String name)
	{
		return (TideTool)tools.get(name);
	}

	//}

	//{ protected void processCreated(DebugProcess process, parent)

	/**
		* A DebugProcess has been created
		*/

	protected void processCreated(DebugProcess process, DebugProcessGroup parent)
	{
		Iterator iter = listeners.iterator();
		while(iter.hasNext()) {
			ProcessListener listener = (ProcessListener)iter.next();
			listener.processCreated(process, parent);
		}
	}

	//}
	//{ protected void processDestroyed(DebugProcess process)

	/**
		* A DebugProcess has been created
		*/

	protected void processDestroyed(DebugProcess process)
	{
		Iterator iter = listeners.iterator();
		while(iter.hasNext()) {
			ProcessListener listener = (ProcessListener)iter.next();
			listener.processDestroyed(process);
		}
	}

	//}
	//{ protected void processGroupCreated(DebugProcess processGroup, parent)

	/**
		* A DebugProcessGroup has been created
		*/

	protected void processGroupCreated(DebugProcessGroup group, 
																		 DebugProcessGroup parent)
	{
		System.out.println("pg = " + group);
		Iterator iter = listeners.iterator();
		while(iter.hasNext()) {
			ProcessListener listener = (ProcessListener)iter.next();
			listener.processGroupCreated(group, parent);
		}
	}

	//} 
	//{ protected void processGroupDestroyed(DebugProcessGroup processGroup)

	/**
		* A DebugProcessGroup has been created
		*/

	protected void processGroupDestroyed(DebugProcessGroup processGroup)
	{
		Iterator iter = listeners.iterator();
		while(iter.hasNext()) {
			ProcessListener listener = (ProcessListener)iter.next();
			listener.processGroupDestroyed(processGroup);
		}
	}

	//}
}

