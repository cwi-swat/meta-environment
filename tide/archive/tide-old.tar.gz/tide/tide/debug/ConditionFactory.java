package tide.debug;

import aterm.*;

public class ConditionFactory
{
	public static Condition parse(String spec)
		throws ParseError
	{
		ATerm term = ATerm.parse(spec);
		return new Condition(term);
	}

	public static Condition createCondition(ATerm cond)
	{
		return new Condition(cond);
	}
}
