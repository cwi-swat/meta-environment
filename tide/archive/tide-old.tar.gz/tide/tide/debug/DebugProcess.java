package tide.debug;

import tide.tools.*;

import java.util.*;

abstract public class DebugProcess
  extends DebugProcessGroup
{
	public static final int STATE_STOPPED = 0;
	public static final int STATE_RUNNING = 1;

	List   ruleListeners;
	Map    rules;
	int state;

	//{ public DebugProcess(String ID)

	/**
		* Construct a new DebugProcess object
		*/

	public DebugProcess(String ID)
	{
		super(ID);
		rules = new HashMap();
		ruleListeners = new Vector();
		state = STATE_STOPPED;
	}

	//}

	//{ public void setState(int state)

	/**
		* Change the state of this process
		*/

	public void setState(int state)
	{
		this.state = state;
	}

	//}
	//{ public int getState()

	/**
		* Retrieve the state of this process
		*/

	public int getState()
	{
		return state;
	}

	//}

	//{ public void addRuleListener(RuleListener listener)

	/**
		* Add a debug listener
		*/

	public void addRuleListener(RuleListener listener)
	{
		ruleListeners.add(listener);
	}

	//}
	//{ public void removeRuleListener(RuleListener listener)

	/**
		* Remove a debug listener
		*/

	public void removeRuleListener(RuleListener listener)
	{
		ruleListeners.remove(listener);
	}

	//}
	//{ pubic boolean isIdentifierChar(char c)

	/**
		* Retrieve a list of characters that make up identifiers
		*/

	public boolean isIdentifierChar(char c)
	{
		if((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
			 (c >= '0' && c <= '9') || (c == '_' || c == '\''))
			return true;

		return false;
	}

	//}

	//{ public Rule getRule(int id)

	/**
		* Retrieve a specific rule
		*/

	public Rule getRule(int id)
	{
		return (Rule)rules.get(new Integer(id));
	}

	//}
	//{ public Iterator getRules()

	/**
		* Retrieve all rules
		*/

	public Iterator getRules()
	{
		return rules.values().iterator();
	}

	//}

	//{ public void addRule(Rule rule)

	/**
		* Add a new rule
		*/

	public void addRule(Rule rule)
	{
		rules.put(new Integer(rule.getID()), rule);
	}

	//}
	//{ public void deleteRule(Rule rule)

	/**
		* Delete a specific rule
		*/

	public void deleteRule(Rule rule)
	{
		Integer id = new Integer(rule.getID());
		rules.remove(id);
	}

	//}

	//{ public void ruleCreated(int id, String type, port, cond, act)

	/**
		* Handle rule creations
		*/

	public void ruleCreated(int ruleID, String type, Port port, 
													Condition condition, DebugAction action)
	{
		System.err.println("ruleCreated: " + ruleID);
		Rule rule = new Rule(this, ruleID, type, port, condition, action);
		addRule(rule);
		Iterator iter = ruleListeners.iterator();
		while(iter.hasNext()) {
			RuleListener listener = (RuleListener)iter.next();
			listener.ruleCreated(rule);
		}
	}

	//}
	//{ public void ruleEnabled(int ruleID, boolean enabled)

	public void ruleEnabled(int ruleID, boolean enabled)
	{
		System.err.println("ruleEnabled: " + ruleID + "," + enabled);
		Rule rule = getRule(ruleID);
		rule.setEnabled(enabled);
		Iterator iter = ruleListeners.iterator();
		while(iter.hasNext()) {
			RuleListener listener = (RuleListener)iter.next();
			listener.ruleEnablingChanged(rule);
		}
	}

	//}
	//{ public void ruleDeleted(int ruleID)

	/**
		* Handle rule deletions
		*/

	public void ruleDeleted(int ruleID)
	{
		Rule rule = getRule(ruleID);
		deleteRule(rule);
		Iterator iter = ruleListeners.iterator();
		while(iter.hasNext()) {
			RuleListener listener = (RuleListener)iter.next();
			listener.ruleDeleted(rule);
		}
	}

	//}
	//{ public void ruleModified(int ruleID, port, condition, action)

	/**
		* Handle rule modifications
		*/

	public void ruleModified(int ruleID, Port port, Condition cond,
													 DebugAction act)
	{
		Rule rule = getRule(ruleID);
		rule.modify(port, cond, act);
		Iterator iter = ruleListeners.iterator();
		while(iter.hasNext()) {
			RuleListener listener = (RuleListener)iter.next();
			listener.ruleModified(rule);
		}
	}

	//}
	//{ public void evaluated(String type, DebugAction act, Value value)

	/**
		* An expression has been evaluated
		*/

	public void evaluated(String type, DebugAction act, Value value)
	{
		Iterator iter = ruleListeners.iterator();
		while(iter.hasNext()) {
			RuleListener listener = (RuleListener)iter.next();
			listener.evaluated(type, act, value);
		}
	}

	//}

	abstract public void requestRuleCreation(String type, Port port, 
																					 Condition cond, DebugAction act);
	abstract public void requestRuleDeletion(Rule rule);
	abstract public void requestRuleModification(Rule rule, Port port,
																							 Condition cond, DebugAction act);
	abstract public void requestRuleEnabling(Rule rule, boolean enabled);
	abstract public void requestEvaluation(String type, DebugAction act);

	// Visualization specific operations.
	abstract public void visualize(Rule r, String expr, String tmpl);

	//{ public String toString()

	/**
		* Return a string representation for debugging purposes
		*/

	public String toString()
	{
		return ID;
	}

	//}
}
