package tide.debug;

import aterm.*;

public class DebugAction
{
	ATerm action;

	public DebugAction(ATerm act)
	{
		action = act;
	}

	public String toString()
	{
		return action.toString();
	}

	public ATerm toTerm()
	{
		return action;
	}
}
