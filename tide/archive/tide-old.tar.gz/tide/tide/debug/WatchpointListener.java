package tide.debug;

public interface WatchpointListener
{
	public void watchpoint(Rule rule, Value value);
}
