package tide.debug;

import java.util.*;

public interface RuleListener
{
	public void ruleCreated(Rule rule);
	public void ruleDeleted(Rule rule);
	public void ruleModified(Rule rule);
	public void ruleEnablingChanged(Rule rule);
	public void evaluated(String type, DebugAction act, Value value);
}
