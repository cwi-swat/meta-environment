package tide.debug;

import aterm.*;

public class Condition
{
	ATerm condition;

	public Condition(ATerm cond)
	{
		condition = cond;
	}

	public String toString()
	{
		return condition.toString();
	}

	public ATerm toTerm()
	{
		return condition;
	}
}
