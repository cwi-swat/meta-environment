package tide.debug;

import java.util.*;

import aterm.*;

public class Value
{
	ATerm value;

	//{ public Value(ATerm val)

	/**
		* Construct a new value given an ATerm
		*/

	public Value(ATerm val)
	{
		value = val;
	}

	//}
	//{ public String toString()

	/**
		* Convert this value into a string
		*/

	public String toString()
	{
		String txt = null;

		if(value.getType() == ATerm.APPL) {
			ATermAppl appl = (ATermAppl)value;
			if(appl.getArity() == 0)
				txt = appl.getName();
		}
		if(txt == null)
			txt = value.toString();
				
		return txt;
	}

	//}
	//{ public ATerm toTerm()

	/**
		* Convert this value into an ATerm
		*/

	public ATerm toTerm()
	{
		return value;
	}

	//}

	//{ public boolean isLocation()

	/**
		* Check if this is a location value
		*/

	public boolean isLocation()
	{
		return value.match("cpe(<term>)") != null;
	}

	//}
	//{ public String getLocationFile()

	/**
		* Retrieve the file of this location.
		*/

	public String getLocationFile()
	{
		ATermAppl spec;
		Vector result;

		/* This code works for both forms of location specs:
       line(<str>,<int>) and area(<str>,<int>,<int>,<int>,<int>)
		*/
		spec = (ATermAppl)((ATermAppl)value).getArgument(0);
		return ((ATermAppl)spec.getArgument(0)).getName();
	}

	//}
}
