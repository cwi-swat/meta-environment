package tide.util;

import java.awt.*;
import javax.swing.*;

public class SlaveCanvas extends JComponent
{
	Painter painter;

	public SlaveCanvas(Painter painter)
	{
		this.painter = painter;
	}

	public void paint(Graphics g)
	{
		painter.doPaint(this, g);
	}
}
