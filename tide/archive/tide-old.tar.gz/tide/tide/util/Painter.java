package tide.util;

import java.awt.*;

public interface Painter
{
	public void doPaint(SlaveCanvas canvas, Graphics g);
}
