package tide.config;

import tide.debug.*;

import aterm.*;

import java.util.*;
import java.io.*;

public class SourceFile
{
	String relPath;
	String absPath;
	int nrLines;
	int[] lineOffsets;
	public byte[] text;

	//{ public SourceFile(String relPath, String absPath)

	/**
		* Construct a new SourceFile by loading a text file
		*/

	public SourceFile(String relPath, String absPath)
		throws IOException
	{
		this.relPath = relPath;
		this.absPath = absPath;
		StringBuffer all = new StringBuffer();
		Vector offsets = new Vector();
		
		offsets.add(new Integer(0));

		FileInputStream stream = new FileInputStream(absPath);
		text = new byte[100000];
		
		int count, pos = 0;
		nrLines = 0;
		do {
			count = stream.read(text, pos, 4096);
			if(count >= 0) {
				for(int j=0; j<count; j++) {
					if(text[pos] == '\n') {
						nrLines++;
						offsets.addElement(new Integer(pos+1));
					}
					pos++;
				}
			}
		} while(count != -1);

		lineOffsets = new int[nrLines+2];
		for(int i=0; i<=nrLines; i++) {
			lineOffsets[i] = ((Integer)offsets.elementAt(i)).intValue();
		}
		nrLines++;
		lineOffsets[nrLines] = pos+1;
	}

	//}

	//{ public String getRelativePath()

	/**
		* Retrieve the path of this file
		*/

	public String getRelativePath()
	{
		return relPath;
	}

	//}
	//{ public String getAbsolutePath()

	/**
		* Retrieve the path of this file
		*/

	public String getAbsolutePath()
	{
		return relPath;
	}

	//}
	//{ public int getNrLines()

	/**
		* Retrieve the number of lines in this source-file
		*/

	public int getNrLines()
	{
		return nrLines;
	}

	//}
	//{ public int getStart(int line)

	/**
		* Retrieve the start-offset of a specific line
		*/

	public int getStart(int line)
	{
		if(line == 0)
			return 0;
		return lineOffsets[line-1];
	}

	//}
	//{ public int getEnd(int line)

	/**
		* Retrieve the end-offset of a specific line
		*/

	public int getEnd(int line)
	{
		if(line == 0)
			return 0;
		return lineOffsets[line]-2; // Don't forget to skip newline!
	}

	//}
	//{ public int getLineNr(Value location)

	/**
		* Retrieve the line number of a source location
		*/

	public int getLineNr(Value location)
	{
		ATerm t = location.toTerm();
		
		Vector result = location.toTerm().match("cpe(line(<str>,<int>))");
		if(result != null) {
			int line    = ((Integer)result.elementAt(1)).intValue();
			return line;
		}
		return 0;
	}

	//}
	//{ public int getStart(Value location)

	/**
		* Retrieve the start offset of a source location
		*/

	public int getStart(Value location)
	{
		ATerm t = location.toTerm();
		
		Vector result = location.toTerm().match("cpe(line(<str>,<int>))");
		if(result != null) {
			String file = (String)result.elementAt(0);
			int line    = ((Integer)result.elementAt(1)).intValue();
			if(!file.equals(relPath))
				throw new IllegalArgumentException("location does not refer to this file!");

			return getStart(line);
		}
		return 0;
	}

	//}
	//{ public int getEnd(Value location)

	/**
		* Retrieve the end offset of a source location
		*/

	public int getEnd(Value location)
	{
		ATerm t = location.toTerm();
		
		Vector result = location.toTerm().match("cpe(line(<str>,<int>))");
		if(result != null) {
			String file = (String)result.elementAt(0);
			int line    = ((Integer)result.elementAt(1)).intValue();
			if(!file.equals(relPath))
				throw new IllegalArgumentException("location does not refer to this file!");

			return getEnd(line);
		}

		return 0;
	}

	//}
	//{ public SourceArea getArea(Value location)

	/**
		* Retrieve a source area
		*/

	public SourceArea getArea(Value location)
	{
		ATerm t = location.toTerm();
		Vector result;

		result = t.match("cpe(line(<str>,<int>))");
		if(result != null) {
			int line    = ((Integer)result.elementAt(1)).intValue();
			return new SourceArea(line, 0, line, -1);
		}

		result = t.match("cpe(area(<str>,<int>,<int>,<int>,<int>))");
		if(result != null) {
			int sl, sc, el, ec;

			sl = ((Integer)result.elementAt(1)).intValue();
			sc = ((Integer)result.elementAt(2)).intValue();
			el = ((Integer)result.elementAt(3)).intValue();
			ec = ((Integer)result.elementAt(4)).intValue();

			return new SourceArea(sl, sc, el, ec);
		}

		return null;
	}

	//}
	//{ public int getTabWidth()

	/**
		* Retrieve the width of one tab
		*/

	public int getTabWidth()
	{
		return 8;
	}

	//}
}
