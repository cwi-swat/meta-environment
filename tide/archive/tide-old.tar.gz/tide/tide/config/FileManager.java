package tide.config;

import java.util.*;
import java.beans.*;
import java.io.*;

public class FileManager
  implements PropertyChangeListener
{
	String category;
	TideConfig config;
	Map files;

	//{ public FileManager(String cat, TideConfig config)

	/**
		* Manage a collection of files
		*/

	public FileManager(String cat, TideConfig cfg)
	{
		category = cat;
		config   = cfg;
		files    = new HashMap();
		config.addPropertyChangeListener(cat + ".paths", this);
	}

	//}
	//{ public SourceFile getFile(String relPath)

	/**
		* Retrieve a file given its relative path
		*/

	public SourceFile getFile(String relPath)
		throws IOException
	{
		SourceFile file = (SourceFile)files.get(relPath);
		if(file == null) {
			String absPath = findAbsolutePath(relPath);
			if(absPath != null) {
				file = new SourceFile(relPath, absPath);
				files.put(relPath, file);
			}
		}
		return file;
	}

	//}
	//{ public String findAbsolutePath(String relPath)

	/**
		* Find the absolute path for a file
		*/

	public String findAbsolutePath(String relPath)
		throws IOException
	{
		List list = config.getSearchPaths(category);
		Iterator iter = list.iterator();

		System.out.println("looking for absolute path of: " + relPath);
		if(relPath.charAt(0) == '/') {
			File attempt = new File(relPath);
			if(attempt.isFile() && attempt.canRead())
				return attempt.getPath();
		} else {
			while(iter.hasNext()) {
				File attempt = new File(iter.next().toString(), relPath);
				if(attempt.isFile() && attempt.canRead()) {
					System.out.println("file found: " + attempt.getPath());
					return attempt.getPath();
				}
				System.out.println("no such file: " + attempt.getPath());
			}
		}
		
		return null;
	}

	//}

	//{ public void propertyChange(PropertyChangeEvent evt)

	/**
		* A property has changed
		*/

	public void propertyChange(PropertyChangeEvent evt)
	{
		// Invalidate all files
		files = new HashMap();
	}

	//}
}
