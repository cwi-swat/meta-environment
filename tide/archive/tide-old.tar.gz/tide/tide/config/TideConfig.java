package tide.config;

import java.util.*;
import java.io.*;
import java.beans.*;

public class TideConfig
  extends Properties
{
	String path;
	PropertyChangeSupport support;

	//{ public TideConfig()

	/**
		* Construct a new TideConfig object
		*/

	public TideConfig()
	{
		support = new PropertyChangeSupport(this);
	}

	//}
	//{ public TideConfig(String fileName)

	/**
		* Construct a new TideConfig object
		*/

	public TideConfig(String fileName)
	{
		this();
		try {
			FileInputStream stream = new FileInputStream(fileName);
			load(stream);
		} catch (IOException e) {
			System.err.println("warning: could not open .tiderc");
		}
	}

	//}

	//{ public void put(String prop, String val)

	/**
		* Fire a property change event!
		*/

	public void put(String prop, String val)
	{
		String old = getProperty(prop);

		super.put(prop, val);
		
		support.firePropertyChange(prop, old, val); 
	}

	//}

	//{ public List getSearchPaths(String category)

	/**
		* Retrieve the list of source 
		*/

	public List getSearchPaths(String category)
	{
		String pathSep = getProperty("path-sep");
		if(pathSep == null)
			pathSep = ";";

		Vector list = new Vector();
		String pathSpec = getProperty(category + ".paths");
		if(pathSpec == null)
			return list;

		StringTokenizer tokens = new StringTokenizer(pathSpec, pathSep);
		while(tokens.hasMoreTokens()) {
			list.addElement(tokens.nextToken());
		}

		return list;
	}

	//}
	//{ public void setSearchPaths(String category, List list)

	/**
		* Change a set of search-paths
		*/

	public void setSearchPaths(String category, List list)
	{
		Iterator iter = list.iterator();

		String pathSpec = "";

		String pathSep = getProperty("path-sep");
		if(pathSep == null)
			pathSep = ";";

		if(iter.hasNext())
			pathSpec += iter.next();

		while(iter.hasNext()) {
			pathSpec += pathSep;
			pathSpec += iter.next();
		}

		put(category + ".paths", pathSpec);
	}

	//}
	//{ public void addSearchPath(String category, String path)

	/**
		* Add a specific search path
		*/

	public void addSearchPath(String category, String path)
	{
		List list = getSearchPaths(category);
		list.add(path);
		setSearchPaths(category, list);
	}

	//}
	//{ public void removeSearchPath(String category, String path)

	/**
		* Remove a single search-path
		*/

	public void removeSearchPath(String category, String path)
	{
		List list = getSearchPaths(category);
		list.remove(path);
		setSearchPaths(category, list);
	}

	//}

	//{ public void addPropertyChangeListener(listener)

	public void addPropertyChangeListener(PropertyChangeListener listener)
	{
		support.addPropertyChangeListener(listener);
	}

	//}
	//{ public void removePropertyChangeListener(listener)

	public void removePropertyChangeListener(PropertyChangeListener listener)
	{
		support.removePropertyChangeListener(listener);
	}

	//}
	//{ public void addPropertyChangeListener(propertyName, listener)

	public void addPropertyChangeListener(String propertyName,
																				PropertyChangeListener listener)
	{
		support.addPropertyChangeListener(propertyName, listener);
	}

	//}
	//{ public void removePropertyChangeListener(propertyName, listener)

	public void removePropertyChangeListener(String propertyName,
																					 PropertyChangeListener listener)
	{
		support.removePropertyChangeListener(propertyName, listener);
	}

	//}
}
