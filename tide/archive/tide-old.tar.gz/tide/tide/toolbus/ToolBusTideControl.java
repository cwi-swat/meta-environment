package tide.toolbus;

//{ imports

import aterm.*;
import aterm.tool.*;
import tide.debug.*;
import tide.config.*;
import tide.tools.*;
import tide.tools.ruleviewer.*;
import tide.tools.sourceviewer.*;
import tide.tools.animviewer.*;

import java.util.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

//}

public class ToolBusTideControl 
	extends JFrame
{
	//{ Tools 

	private static final String TOOL_RULE_VIEWER   = "Rules";
	private static final String TOOL_RULE_TRACER   = "RuleTrace";
	private static final String TOOL_SOURCE_VIEWER = "Source";
	private static final String TOOL_VISUALIZER    = "Visualize";
	private static final String TOOL_PROCESS_VIEWER= "ProcessViewer";

	private static final String[] TOOLS = 
  { TOOL_RULE_VIEWER, 
		TOOL_RULE_TRACER,
		TOOL_SOURCE_VIEWER,
		TOOL_VISUALIZER,
		TOOL_PROCESS_VIEWER
	};

	//}
	//{ Preferences

	private static final String PREF_SOURCE_PATHS   = "Source Paths";

	private static final String[] PREFERENCES =
  { PREF_SOURCE_PATHS
	};

	//}
	//{ Actions

	TideAction actSavePreferences;

	//}

	ToolBusDebugInterface debugInterface;
	TideControlTool tideControl;
	PainterTool painterTool;

	TideConfig config;
	FileManager sources;
	String[] args;

	JMenu toolMenu;
	JDesktopPane desktop;

	ProcessList processList;

	// Only used for synchronization!
	protected static Integer sync = new Integer(0);
  
	//{ class TideAction extends AbstractAction

	class TideAction extends AbstractAction
	{
		String act;
		ToolBusTideControl control;

		public TideAction(ToolBusTideControl control, String act)
		{
			super(act);
			this.act = act;
			this.control = control;
		}

		public TideAction(ToolBusTideControl control, String act, Icon icon)
		{
			super(act, icon);
			this.act = act;
			this.control = control;
		}

		public void actionPerformed(ActionEvent evt)
		{
			control.tideAction(this, act);
		}
	}

	//}
	//{ class TideControlTool extends TideControlTif

	class TideControlTool extends TideControlTif
	{
		public TideControlTool(String[] args)
			throws UnknownHostException
		{
			super(args);
		}

		protected ATerm handler(ATerm term)
			throws ToolException
		{
			synchronized (ToolBusTideControl.sync) {
				return super.handler(term);
			}
		}

		void recTerminate(ATerm t)
		{
			System.err.println("ToolBusTideControl: joining subtool(s).");
			try {
				painterTool.join();
			} catch (InterruptedException e) {
				// Empty.
			}
			System.err.println("ToolBusTideControl: terminating.");
			System.exit(0);
		}
	}

	//}

	//{ public ToolBusTideControl(String[] args)

	public ToolBusTideControl(String[] args)
	{
		this.args = args;
		config    = new TideConfig(".tiderc");
		sources   = new FileManager("sources", config);

		//System.err.println("ToolBusTideControl constructor entered.");

		//{ Create TideControlTool and connect to ToolBus.

		try {
			tideControl = new TideControlTool(args);
			//System.err.println("before connect\n");
			tideControl.connect();
			//System.err.println("before new TBDebugInterface\n");
			debugInterface = new ToolBusDebugInterface();
			//System.err.println("before new ProcessList\n");
			processList = new ProcessList(debugInterface);
			//System.err.println("after new ProcessList\n");
		} catch (UnknownHostException e) {
			JOptionPane.showMessageDialog(this,
				"Cannot find ToolBus: unknown host",
				"Too Bad", JOptionPane.ERROR_MESSAGE);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this,
				"Cannot contact ToolBus: " + e.getMessage(),
				"Too Bad", JOptionPane.ERROR_MESSAGE);
			tideControl = null;
		} catch (ToolException e) {
			JOptionPane.showMessageDialog(this,
				"A Tool error occurred: " + e.getMessage(),
				"Too Bad", JOptionPane.ERROR_MESSAGE);
			tideControl = null;
		}

		//}

		//System.err.println("Creating GUI components");

		//{ Create GUI components
		//{ Setup basic environment

		setSize(800,600);
		desktop = new JDesktopPane();
		JMenuBar bar = new JMenuBar();

		//}
		//{ Setup "Tools" menu

		toolMenu = new JMenu("Tools");
		for(int i=0; i<TOOLS.length; i++)
			toolMenu.add(new TideAction(this, TOOLS[i]));
		bar.add(toolMenu);

		//}
		//{ Setup "Preferences" menu

		JMenu prefMenu = new JMenu("Preferences");
		for(int i=0; i<PREFERENCES.length; i++) 
			prefMenu.add(new TideAction(this, PREFERENCES[i]));

		actSavePreferences = new TideAction(this, "Save");
		prefMenu.addSeparator();
		prefMenu.add(actSavePreferences);
		bar.add(prefMenu);

		//}
		//}

		//System.err.println("Laying out GUI components");

		//{ Layout GUI components

		Container contentPane = getContentPane();
		contentPane.setLayout(new BorderLayout());

		contentPane.add(processList, "West");
		contentPane.add(desktop, "Center");

		setJMenuBar(bar);

		// Create and start the painter tool.
		try {
			painterTool	= new PainterTool(desktop, tideControl.getAddress(),
																		tideControl.getPort());
			painterTool.connect();
		} catch (UnknownHostException e) {
			JOptionPane.showMessageDialog(this,
				"Cannot find ToolBus: unknown host",
				"Too Bad", JOptionPane.ERROR_MESSAGE);
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this,
				"Cannot contact ToolBus: " + e.getMessage(),
				"Too Bad", JOptionPane.ERROR_MESSAGE);
		} catch (ToolException e) {
			JOptionPane.showMessageDialog(this,
				"A Tool error occurred: " + e.getMessage(),
				"Too Bad", JOptionPane.ERROR_MESSAGE);
		}

		//}

		//System.err.println("ToolBusTideControl constructor done.");
	}

	//}
	//{ public void tideAction(TideAction action, String act)

	/**
		* Start an action
		*/

	public void tideAction(TideAction action, String act)
	{
		TideTool tool;
		JInternalFrame frame;

		if(action == actSavePreferences) {
			//{ Save the preferences

			try {
				FileOutputStream stream = new FileOutputStream(".tiderc");
				config.store(stream, "Tide preferences");
			} catch (IOException e) {
				JOptionPane.showInternalMessageDialog(getContentPane(),
            "Could not save preferences: " + e.getMessage(),
						"Error saving preferences", JOptionPane.ERROR_MESSAGE);
			}

			//}
		} if(act.equals(PREF_SOURCE_PATHS)) {
			//{ Edit source paths

			tool = new SearchPathEditor(config, "sources");
			addTool(tool);

			//}
		} else {
			//{ Check for one of the tools

			for(int i=0; i<TOOLS.length; i++) {
				if(act.equals(TOOLS[i])) {
					//{ Create a new tool

					String toolName = act;

					if(toolName.equals(TOOL_PROCESS_VIEWER)) {
						DebugAdapter selectedAdapter = getSelectedAdapter();
						if(selectedAdapter == null) {
							JOptionPane.showInternalMessageDialog(getContentPane(),
											"Please select an adapter.", "No adapter selected",
											JOptionPane.ERROR_MESSAGE);
							return;

						}
						tool = new ProcessViewer(debugInterface, selectedAdapter);
					} else {
						DebugProcess selectedProc = getSelectedProcess();
						if(selectedProc == null) {
							JOptionPane.showInternalMessageDialog(getContentPane(),
										"Please select a process.", "No process selected",
										JOptionPane.ERROR_MESSAGE);
							return;
						}
						
						if (toolName.equals(TOOL_RULE_VIEWER)) {
							tool = new RuleViewer(selectedProc);
						} else if(toolName.equals(TOOL_RULE_TRACER)) {
							tool = new RuleTracer(selectedProc);
						} else if(toolName.equals(TOOL_SOURCE_VIEWER)) {
							tool = new SourceViewer(debugInterface, selectedProc, sources);
						} else if(toolName.equals(TOOL_VISUALIZER)) {
							tool = new AnimChooser(selectedProc);
						} else {
							throw new RuntimeException("Unknown Tool: " + toolName);
						}
					}

					addTool(tool);

					//}
				}
			}

			//}
		}
	}

	//}	
	//{ public void addTool(TideTool tool)

	/**
		* Add a new tool
		*/

	public void addTool(TideTool tool)
	{
		debugInterface.registerTool(tool);

		tool.addInternalFrameListener(new InternalFrameAdapter() {
			public void internalFrameClosed(InternalFrameEvent e) {
				TideTool t = (TideTool)e.getSource();
				System.out.println("tool removed from ToolBusTideControl: " +
													 t.getName());
				removeTool(t);
				t.cleanup();
			}
		});
		desktop.add(tool, new Integer(1));
		desktop.moveToFront(tool);
	}

	//}
	
	//{ public void removeTool(TideTool tool)

	/**
		* Remove an existing tool
		*/

	public void removeTool(TideTool tool)
	{
		debugInterface.unregisterTool(tool);
	}

	//}
	
	//{ public void run()

	/**
		* Run this tool
		*/

	public void run()
	{
		if(tideControl != null)
			tideControl.run();
	}

	//}
	//{ final static void main(String[] args)

	/**
		* Start ToolBusTideControl tool
		*/

	final static void main(String[] args)
	{
		ToolBusTideControl control = new ToolBusTideControl(args);
		control.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.out.println("disconnect() not yet implemented, so hit ^C ;-)");
			}
		});
		control.setVisible(true);
		control.run();
	}

	//}

	//{ public DebugProcess getSelectedProcess()

	/**
		* Retrieve the currently selected process
		*/

	public DebugProcess getSelectedProcess()
	{
		return processList.getSelectedProcess();
	}

	//}
	//{ public DebugAdapter getSelectedAdapter()

	/**
		* Retrieve the currently selected process
		*/

	public DebugAdapter getSelectedAdapter()
	{
		return processList.getSelectedAdapter();
	}

	//}
}

// vim:sw=2:ts=2
