package tide.toolbus;

import tide.debug.*;
import tide.tools.*;

import aterm.*;

import java.util.Vector;

public class TideProcess
  extends DebugProcess
{
	private ToolBusDebugInterface iface;
	private DebugAdapter adapter;

	//{ public TideProcess(ToolBusDebugInterface ifc, String id, DebugProcessGroup parent)

	/**
		* Create a new TideProcess
		*/

	public TideProcess(ToolBusDebugInterface ifc, String id, DebugAdapter adapter) 
	{
		super(id);
		iface   = ifc;
		this.adapter = adapter;
	}

	//}
	//{ public DebugAdapter getAdapter()

	/**
		* Retrieve the adapter
		*/

	public DebugAdapter getAdapter()
	{
		return adapter;
	}
	
	//}

	//{ public void requestRuleCreation(String type, Port port, cond, act)

	public void requestRuleCreation(String type, Port port, 
																	Condition cond, DebugAction act)
	{
		iface.requestRuleCreation(this, type, port, cond, act);
	}

	//}
	//{ public void requestRuleDeletion(Rule rule)

	public void requestRuleDeletion(Rule rule)
	{
		iface.requestRuleDeletion(rule);
	}

	//}
	//{ public void requestRuleModification(Rule rule, port, cond, act)

	public void requestRuleModification(Rule rule, Port port, 
																			Condition cond, DebugAction act)
	{
		iface.requestRuleModification(rule, port, cond, act);
	}

	//}
	//{ public void requestRuleEnabling(Rule rule, boolean enabled)

	public void requestRuleEnabling(Rule rule, boolean enabled)
	{
		iface.requestRuleEnabling(rule, enabled);
	}

	//}
	//{ public void requestEvaluation(String type, DebugAction act)

	/**
		* Request evaluation of a debug action
		*/

	public void requestEvaluation(String type, DebugAction act)
	{
		iface.requestEvaluation(this, type, act);
	}

	//}
	//{ public void visualize(String expr, String tmpl)

	/**
		* Request that an expression be inspected.
		*
		* @param expr the expression to be inspected.
		* @param rule the rule responsible for evaluating the expression.
		* @param tmpl the template that defines how expr will be visualized.
		*/

	public void visualize(Rule rule, String expr, String tmpl)
	{
		iface.visualize(this, rule, expr, tmpl);
	}

	//}

	//{ public ATerm toTerm()

	/**
		* Retrieve the term representation of this process
		*/

	public ATerm toTerm()
	{
		return ATerm.make("proc(<term>,<str>)", adapter.getDap(), getID());
	}

	//}
}
