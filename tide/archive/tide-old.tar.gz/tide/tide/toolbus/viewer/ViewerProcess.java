package tide.toolbus.viewer;

import aterm.*;
import aterm.tool.*;

import tide.adapter.*;

public class ViewerProcess
  extends DapProcess
{
	Tool client;

	int id;
	ATerm cpe;
	ATermList env;

	ATerm from;
	ATerm to;
	ATerm msg;

	//{ terms and patterns

	ATerm termCpeUnknown;

	//}

	//{ public ViewerProcess(ViewerDebugAdapter adapter, Tool client, name, id)

	/**
		* Construct a new ViewerProcess object
		*/

	public ViewerProcess(ViewerDebugAdapter adapter, Tool client, 
											 String name, int id)
	{
		super(adapter, name + "(" + id + ")");

		this.client = client;
		this.id = id;
		try {
			termCpeUnknown = ATerm.parse("cpe(unknown)");
		} catch (ParseError e) {
			throw new RuntimeException("internal parse error: " + e.getMessage());
		}
	}

	//}

	//{ void sendContinue()

	void sendContinue()
	{
		try {
			client.send(ATerm.parse("snd-continue(" + id + ")"));
		} catch (ToolException e) {
			e.printStackTrace();
			throw new RuntimeException("could not send to debugger bus!");
		}
	}

	//}
	//{ void setCpe(ATermList coords)

	/**
		* Set the current point of execution
		*/

	void setCpe(ATermList coords)
	{
		cpe = coords;
		
	}

	//}
	//{ void setEnv(ATermList env)

	/**
		* Set the current list of variables and their values
		*/

	void setEnv(ATermList env)
	{
		this.env = env;
	}

	//}
	//{ void setMsg(ATerm from, ATerm to, ATerm msg)

	/**
		* Set the message to be send
		*/

	void setMsg(ATerm from, ATerm to, ATerm msg)
	{
		this.from = from;
		this.to   = to;
		this.msg = msg;
	}

	//}
	//{ void clearMsg()

	/**
		* The current message is not valid anymore
		*/

	void clearMsg()
	{
		msg = null;
		from = null;
		to = null;
	}

	//}

	//{ void fireLocationRules()

	/**
		* Fire the location rules for the currept CPE position
		*/

	void fireLocationRules()
	{
		ATermList list = (ATermList)cpe;
		String file = ((ATermAppl)list.getFirst()).getName();
		list = list.getNext();
		int sl = ((ATermInt)list.getFirst()).getInt();
		list = list.getNext();
		int sc = ((ATermInt)list.getFirst()).getInt();
		list = list.getNext();
		int el = ((ATermInt)list.getFirst()).getInt();
		list = list.getNext();
		int ec = ((ATermInt)list.getFirst()).getInt();

		fireLocationRules(file, sl, sc, el, ec);
	}

	//}

	/**
		* Overridden effect functions
		*/

	//{ public void doResume()

	/**
		* Resume execution of this process
		*/

	public void doResume()
	{
		super.doResume();
		sendContinue();
		fireRules(DapRule.PORT_STARTED);
	}

	//}

	/**
		* Actions
		*/

	//{ public ATerm actionCpe()

	public ATerm actionCpe()
	{
		if(cpe == null)
			return termCpeUnknown;
		else
			return ATerm.make("cpe(area(<list>))", cpe);
	}

	//}
	//{ public ATerm actionVar(ATerm var)

	/**
		* Retrieve the value of a variable
		*/

	public ATerm actionVar(ATerm var)
	{
		ATermAppl appl;
		ATermList vars, pair;
		ATerm value;
		String name, vname, prefix;

		appl   = (ATermAppl)var;
		name   = appl.getName();
		prefix = name + "$";

		vars = env;
		while(!vars.isEmpty()) {
			pair  = (ATermList)vars.getFirst();
			vars  = vars.getNext();
			vname = ((ATermAppl)pair.getFirst()).getName();
			if(vname.startsWith(prefix))
				return pair.getNext().getFirst(); // Return value of this variable
		}
		
		return ATerm.parse("error(\"unknown variable: " + name + "\")");
	}

	//}
	//{ public ATerm actionMsg()

	/**
		* Return the last message that was sent/receveid
		*/

	public ATerm actionMsg()
	{
		return ATerm.make("msg(<term>,<term>,<term>)", from, to, msg);
	}

	//}

	//{ public int getStackLevel()

	public int getStackLevel()
	{
		return 0; // The ToolBus doesn't have a stack!
	}

	//}
}

