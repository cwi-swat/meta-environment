// Java tool interface class ViewerTif
// This file is generated automatically, please do not edit!
// generation time: Dec 16, 1999 1:19:12 PM

package tide.toolbus.viewer;
import aterm.*;
import aterm.tool.*;
import java.net.UnknownHostException;
import java.net.InetAddress;
import java.util.Vector;
import java.util.Hashtable;


abstract public class ViewerTif extends Tool
{
  // This table will hold the complete input signature
  private Hashtable sigTable = new Hashtable();

  // Declare the patterns that are used to match against incoming terms
  private ATerm PrecTerminate0;
  private ATerm PrecMonitor0;

  // Mimic the three constructors from the Tool class
  protected ViewerTif(String name) throws UnknownHostException { super(name); init(); }
  protected ViewerTif(String name, InetAddress address, int port) throws UnknownHostException  { super(name, address, port); init(); }
  protected ViewerTif(String[] args) throws UnknownHostException { super(args); init(); }

  // Initializations common to all constructors
  private void init() { initSigTable(); initPatterns(); }

  // This method initializes the table with input signatures
  private void initSigTable()
  {
    try {
      sigTable.put(world.parse("rec-terminate(<viewer>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<control>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<debug-adapter>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<debug-tool>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<painter>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-terminate(<visualizer>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<painter>,execute-command(<int>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<painter>,destroy-canvas(<int>))"), new Boolean(true));
      sigTable.put(world.parse("rec-eval(<painter>,create-canvas)"), new Boolean(true));
      sigTable.put(world.parse("rec-eval(<visualizer>,get-templates)"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<visualizer>,update(vis-key(<term>,<int>),<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-ack-event(<visualizer>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<visualizer>,visualize(vis-key(<term>,<int>),canvas-key(<painter>,<int>),<str>,<str>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-tool>,adapter-disconnected(<debug-adapter>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-tool>,event(<term>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-ack-event(<debug-tool>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-adapter>,delete-rule(<str>,<int>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-adapter>,modify-rule(<str>,<int>,<term>,<term>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-adapter>,disable-rule(<str>,<int>))"), new Boolean(true));
      sigTable.put(world.parse("rec-do(<debug-adapter>,enable-rule(<str>,<int>))"), new Boolean(true));
      sigTable.put(world.parse("rec-eval(<debug-adapter>,create-rule(<str>,<term>,<term>,<term>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-eval(<debug-adapter>,evaluate(<str>,<term>))"), new Boolean(true));
      sigTable.put(world.parse("rec-ack-event(<debug-adapter>,<term>)"), new Boolean(true));
      sigTable.put(world.parse("rec-monitor(<viewer>,<term>)"), new Boolean(true));
    } catch (ParseError e) { }
  }

  // Initialize the patterns that are used to match against incoming terms
  private void initPatterns()
  {
    try {
      PrecTerminate0 = world.parse("rec-terminate(<term>)");
      PrecMonitor0 = world.parse("rec-monitor(<term>)");
    } catch (ParseError e) {}
  }


  // Override these abstract methods to handle incoming ToolBus terms
  abstract void recTerminate(ATerm t0) throws ToolException;
  abstract void recMonitor(ATerm t0) throws ToolException;

  // The generic handler calls the specific handlers
  protected ATerm handler(ATerm term)
	throws ToolException
  {
    Vector result;
        result = term.match(PrecTerminate0);
    if(result != null) {
      recTerminate((ATerm)result.elementAt(0));
      return null;
    }

    result = term.match(PrecMonitor0);
    if(result != null) {
      recMonitor((ATerm)result.elementAt(0));
      return null;
    }


      notInInputSignature(term);
    return null;
  }

  // Check the input signature
  protected void checkInputSignature(ATermList sigs)
         throws ToolException
  {
    while(!sigs.isEmpty()) {
      ATermAppl sig = (ATermAppl)sigs.getFirst();
      sigs = sigs.getNext();
      if(!sigTable.containsKey(sig)) {
        // Sorry, but the term is not in the input signature!
        notInInputSignature(sig);
      }
    }
  }

  // This function is called when an input term
  // was not in the input signature.
  void notInInputSignature(ATerm t)
        throws ToolException
  {
    throw new ToolException(this, "term not in input signature", t);
  }
}

