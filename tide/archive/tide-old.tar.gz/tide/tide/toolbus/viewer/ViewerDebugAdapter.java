package tide.toolbus.viewer;

import java.util.*;
import java.io.*;
import java.net.*;

import aterm.*;
import aterm.tool.*;

import tide.adapter.*;

public class ViewerDebugAdapter
  extends DebugAdapter
{
	final static int MAX_PIDS = 256;

	Tool client;
  ViewerProcess[] processes = new ViewerProcess[MAX_PIDS];

	//{ protected ViewerDebugAdapter(Tool client, String host, int port)

	/**
		* Construct a new ViewerDebugAdapter object
		*/

  protected ViewerDebugAdapter(Tool client, String host, int port)
		throws UnknownHostException
	{
		super("debug-adapter", host == null ? InetAddress.getLocalHost() : InetAddress.getByName(host),
					port);
		this.client = client;
	}

	//}

	//{ void applicationEvent(ATerm event)

	/**
		* Received a monitor event from the application
		*/

	void applicationEvent(ATerm event)
	{
		Vector result;

		System.out.println("event: " + event);
		result = event.match("viewpoint(<int>,<fun>,<term>,<term>,<term>," +
												 "<term>,<term>,<int>,<term>)");
		if(result != null) {
			String act_fun;
			int pid, peer;
			ATerm subs, notes, pe;
			ATermList act_args, env, act_coords;

			pid        = ((Integer)result.elementAt(0)).intValue();
			act_fun    = (String)result.elementAt(1);
			act_args   = (ATermList)result.elementAt(2);
			act_coords = (ATermList)result.elementAt(3);
			env        = (ATermList)result.elementAt(4);
			subs       = (ATerm)result.elementAt(5);
			notes      = (ATerm)result.elementAt(6);
			peer       = ((Integer)result.elementAt(7)).intValue();
			pe         = (ATerm)result.elementAt(8);

			System.out.println("act_fun=" + act_fun);
			System.out.println("pid= " + pid + ", peer=" + peer);
			System.out.println("args= " + act_args + ", coords=" + act_coords +
												 ", env=" + env + ", subs=" + subs + 
												 ", notes=" + notes + ", pe=" + pe);

			if(processes[pid] != null) {
				processes[pid].setCpe(act_coords);
				processes[pid].setEnv(env);
				processes[pid].fireLocationRules();
				processes[pid].fireRules(DapRule.PORT_STEP);
			}
 
			if(act_fun.equals("create")) {
				//{ Propagate process creation

				String pname = ((ATermAppl)act_args.getFirst()).getName();
				String var = ((ATermAppl)act_args.getNext().getFirst()).getName();
				String val = getValue(var, env).toString();
				int newid = Integer.parseInt(val);
				ViewerProcess proc = new ViewerProcess(this, client, pname, newid);
				processes[newid] = proc;
				processCreated(proc);

				//}
			} else if(act_fun.equals("snd-msg")) {
				//{ Trigger PORT_SEND for process <-> process communication

				ATerm msg = substituteVariables(act_args, env);
				msg = ATerm.make("snd-msg(<list>)", msg);
				ATerm from = ATerm.parse(processes[pid].getPid());
				ATerm to   = ATerm.parse(processes[peer].getPid());
				processes[pid].setMsg(from, to, msg);
				processes[pid].fireRules(DapRule.PORT_SEND);
				processes[pid].clearMsg();

				//}
			} else if(act_fun.equals("rec-msg")) {
				//{ Trigger PORT_RECEIVE for process <-> process communication

				ATerm msg = substituteVariables(act_args, env);
				msg = ATerm.make("rec-msg(<list>)", msg);
				ATerm from = ATerm.parse(processes[pid].getPid());
				ATerm to   = ATerm.parse(processes[peer].getPid());
				processes[pid].setMsg(from, to, msg);
				processes[pid].fireRules(DapRule.PORT_RECEIVE);
				processes[pid].clearMsg();

				//}
			} else if(act_fun.equals("snd-eval")) {
				//{ Trigger PORT_SEND for process <-> tool communication

				ATerm msg  = substituteVariables(act_args.getNext(), env);
				msg = ATerm.make("snd-eval(<list>)", msg);
				String var = ((ATermAppl)act_args.getFirst()).getName();
				ATerm from = ATerm.parse(processes[pid].getPid());
			  ATerm to   = getValue(var, env);
				processes[pid].setMsg(from, to, msg);
				processes[pid].fireRules(DapRule.PORT_SEND);
				processes[pid].clearMsg();

				//}
			} else if(act_fun.equals("rec-value")) {
				//{ Trigger PORT_RECEIVE for process <-> tool communication

				ATerm msg  = substituteVariables(act_args.getNext(), env);
				msg = ATerm.make("rec-value(<list>)", msg);
				String var = ((ATermAppl)act_args.getFirst()).getName();
				ATerm to   = ATerm.parse(processes[pid].getPid());
			  ATerm from = getValue(var, env);
				processes[pid].setMsg(from, to, msg);
				processes[pid].fireRules(DapRule.PORT_RECEIVE);
				processes[pid].clearMsg();

				//}
			} else if(act_fun.equals("rec-event")) {
				//{ Trigger PORT_RECEIVE for process <-> tool communication

				ATerm msg  = substituteVariables(act_args.getNext(), env);
				msg = ATerm.make("rec-event(<list>)", msg);
				String var = ((ATermAppl)act_args.getFirst()).getName();
			  ATerm from = getValue(var, env);
				ATerm to   = ATerm.parse(processes[pid].getPid());
				processes[pid].setMsg(from, to, msg);
				processes[pid].fireRules(DapRule.PORT_RECEIVE);
				processes[pid].clearMsg();

				//}
			} else if(act_fun.equals("snd-ack-event")) {
				//{ Trigger PORT_SEND for process <-> tool communication

				ATerm msg  = substituteVariables(act_args.getNext(), env);
				msg = ATerm.make("snd-ack-event(<list>)", msg);
				String var = ((ATermAppl)act_args.getFirst()).getName();
				ATerm from = ATerm.parse(processes[pid].getPid());
			  ATerm to   = getValue(var, env);
				processes[pid].setMsg(from, to, msg);
				processes[pid].fireRules(DapRule.PORT_SEND);
				processes[pid].clearMsg();

				//}
			} else {

			}

			if(processes[pid] == null) {
				try {
					client.send(ATerm.parse("snd-continue(" + pid + ")"));
				} catch (ToolException e) {
					e.printStackTrace();
					throw new RuntimeException("could not send to debugger bus!");
				}
			} else if(processes[pid].isRunning()) {
				processes[pid].sendContinue();
			} else {
				processes[pid].fireRules(DapRule.PORT_STOPPED);
			}
		} else {
			throw new RuntimeException("strange monitor event: " + event);
		}
	}

	//}
	//{ void applicationTerminated()

	/**
		* The application terminated
		*/

	void applicationTerminated()
	{
	}

	//}

	//{ ATerm getValue(String var, ATermList env)

	/**
		* Retrieve the value of a variable from an environment
		*/

	ATerm getValue(String var, ATermList env)
	{
		while(!env.isEmpty()) {
			ATermList pair = (ATermList)env.getFirst();

			if(((ATermAppl)pair.getFirst()).getName().equals(var)) {
				return pair.getNext().getFirst();
			}

			env = env.getNext();
		}

		return null;
	}

	//}
	//{ ATerm substituteVariables(ATerm t, ATermList env)

	/**
		* Substitute all occurences of bound variables
		*/

	ATerm substituteVariables(ATerm t, ATermList env)
	{
		ATermList list;
		ATermAppl appl;
		Vector elems;
		int i;

		switch(t.getType()) {
			case ATerm.LIST:
				list = (ATermList)t;
				elems = new Vector();
				while(!list.isEmpty()) {
					elems.addElement(substituteVariables(list.getFirst(), env));
					list = list.getNext();
				}
				list = ATerm.the_world.empty;
				for(i=elems.size()-1; i>=0; i--) {
					list = list.insert((ATerm)elems.elementAt(i));
				}
				return list;

			case ATerm.APPL:
				appl = (ATermAppl)t;
				String name = appl.getName();
				if(Character.isUpperCase(name.charAt(0))) {
					// Must be a variable
					ATerm value = getValue(name, env);
					if(value == null)
						return t;
					else
						return value;
				} else {
					// A regular function application
					ATermList args = 
						(ATermList)substituteVariables(appl.getArguments(), env);
					return world.makeAppl(name, args, appl.isQuoted());
				}

			default:
				return t;
		}
	}

	//}

}

