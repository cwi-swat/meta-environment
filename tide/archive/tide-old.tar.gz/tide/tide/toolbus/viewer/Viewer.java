package tide.toolbus.viewer;

import java.io.*;
import java.net.*;

import aterm.*;
import aterm.tool.*;

public class Viewer
  extends ViewerTif
{
	int tideport = 9500;
	String tidehost = null;

	ViewerDebugAdapter debugAdapter;
	Thread             debugAdapterThread;

	//{ final static void main(String[] args)

	/**
		* Start the viewer and connect to both 
		* the application and the debugger.
		*/
	
	final static void main(String[] args)
		throws UnknownHostException, IOException, ToolException
	{
		Viewer viewer = new Viewer(args);
		viewer.connect();
		viewer.run();
	}

	//}

	//{ public Viewer(String[] args) 

	/**
		* Construct a new Viewer tool
		*/

  public Viewer(String[] args) 
		throws UnknownHostException 
	{ 
		super(args); 

		for(int i=0; i<args.length; i++) {
			if(args[i].equals("-tideport"))
				tideport = Integer.parseInt(args[++i]);
			else if(args[i].equals("-tidehost"))
				tidehost = args[++i];
		}

		debugAdapter = new ViewerDebugAdapter(this, tidehost, tideport);
	}

	//}

	//{ public void connect()

	/**
		* Connect to application and debugger busses
		*/

	public void connect()
		throws ToolException, IOException
	{
		super.connect();         // Connect to application bus
		debugAdapter.connect();  // Connect to debugger bus
	}

	//}
	//{ public void run()

	/**
		* Start receiving messages
		*/

	public void run()
	{
		// Receive messages from debugger bus
		debugAdapterThread = new Thread(debugAdapter);
		debugAdapterThread.start();

		// And from application bus
		super.run();
	}

	//}

	//{ void recTerminate(ATerm arg) 

	/**
		* Receive termination request
		*/

	void recTerminate(ATerm arg) 
	{
		debugAdapter.applicationTerminated();
	}

	//}
	//{ void recMonitor(ATerm t0)

	/**
		* Receive a monitor event
		*/

  void recMonitor(ATerm t0)
	{
		debugAdapter.applicationEvent(t0);
	}

	//}
}
