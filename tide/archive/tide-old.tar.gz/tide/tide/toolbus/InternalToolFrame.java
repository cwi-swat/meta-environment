package tide.toolbus;

import javax.swing.*;

public class InternalToolFrame
  extends JInternalFrame
{
	public InternalToolFrame(String name, TideTool tool)
	{
		super(name, true, true, true, true);
		Container contentPane = getContextPane();
		contentPane.add(tool, BorderLayout.CENTER);
	}
}
