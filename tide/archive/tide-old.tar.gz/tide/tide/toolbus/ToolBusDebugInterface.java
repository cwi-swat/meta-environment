package tide.toolbus;

import tide.debug.*;
import tide.tools.*;

import aterm.*;
import aterm.tool.*;

import java.util.*;
import java.io.*;
import java.net.*;

public class ToolBusDebugInterface
  extends DebugInterface
{
	private ToolBusDebugTool tool;
	private Map adapters;
	private Map processes;
	private DebugProcessGroup root;

	//{ public ToolBusDebugInterface()

	public ToolBusDebugInterface()
		throws UnknownHostException, IOException, ToolException
	{
		adapters = new HashMap();
		processes = new HashMap();
		root = new DebugProcessGroup("all");
		tool = new ToolBusDebugTool(this);
		tool.connect();
		Thread thread = new Thread(tool);
		thread.start();
	}


	//}

	//{ public DebugProcessGroup getRoot()

	/**
		* Retrieve the root process-group
		*/

	public DebugProcessGroup getRoot()
	{
		return root;
	}

	//}
	//{ public DebugAdapter getAdapter(ATerm dap)

	/**
		* Retrieve an adapter
		*/

	public DebugAdapter getAdapter(ATerm dap)
	{
		DebugAdapter adapter = (DebugAdapter)adapters.get(dap);
		if(adapter == null) {
			System.out.println("root = " + root);
			adapter = new DebugAdapter(dap);
			adapters.put(dap, adapter);
			super.processGroupCreated(adapter, root);
		}
		return adapter;
	}

	//}
	//{ public TideProcess getProcess(ATerm dap, String id)

	/**
		* Retrieve a specific process
		*/

	public TideProcess getProcess(ATerm dap, String id)
	{
		Map procs = (Map)processes.get(dap);

		if(procs == null)
			return null;

		return (TideProcess)procs.get(id);
	}

	//}

	//{ public void processCreated(DebugProcess process, DebugProcessGroup parent)

	/**
		* A new process has been created
		*/

	public void processCreated(DebugProcess process, DebugProcessGroup parent)
	{
		TideProcess proc = (TideProcess)process;
		ATerm adapter    = proc.getAdapter().getDap();
		String id        = proc.getID();

		Map procs = (Map)processes.get(adapter);
		if(procs == null) {
			procs = new HashMap();
			processes.put(adapter, procs);
		}

	  procs.put(id, process);

		super.processCreated(process, parent);
	}

	//}
	//{ public void processDestroyed(DebugProcess process)

	/**
		* A process has been destroyed
		*/

	public void processDestroyed(DebugProcess process)
	{
		TideProcess proc = (TideProcess)process;
		ATerm adapter    = proc.getAdapter().getDap();
		String id        = proc.getID();

		Map processes = (Map)adapters.get(adapter);
		if(processes == null) {
			System.err.println("warning: processDestroyed in non-existing " +
												 "adapter: " + adapter);
			return;
		}

		TideProcess proc2 = (TideProcess)processes.get(id);
		if(proc2 != proc) {
			System.err.println("warning: adapter " + adapter + " has two " +
												 "processes with the same ID (" + id + ")");
			return;
		}

	  processes.remove(id);

		super.processDestroyed(process);
	}

	//}
	//{ public void processGroupDestroyed(DebugProcessGroup group)

	/**
		* A group of processes has been destroyed
		*/

	public void processGroupDestroyed(DebugProcessGroup group)
	{
		adapters.remove(group);
		super.processGroupDestroyed(group);
	}

	//}

	//{ public void requestRuleCreation(creator, process, type, port, cond,act)

	public void requestRuleCreation(DebugProcess process, String type,
																	Port port, Condition cond, DebugAction act)
	{
		try {
			ATerm req = ATerm.make("create-rule(<term>,<term>,<term>,<term>,<term>)",
														 ((TideProcess)process).toTerm(), 
														 ATerm.make(type), port.toTerm(),
														 cond.toTerm(), act.toTerm());
			tool.post((ATermAppl)req);
		} catch (ToolException e) {
			System.err.println("ToolException occured: " + e.getMessage());
		}
	}

	//}
	//{ public void requestRuleDeletion(Rule rule)

	public void requestRuleDeletion(Rule rule)
	{
		try {
			tool.post((ATermAppl)ATerm.make("delete-rule(<term>,<int>)",
																			((TideProcess)rule.getProcess()).toTerm(),
																			new Integer(rule.getID())));
		} catch (ToolException e) {
			System.err.println("ToolException occured: " + e.getMessage());
		}
	}

	//}
	//{ public void requestRuleModification(rule, port, cond, act)

	public void requestRuleModification(Rule rule, Port port,
																			Condition cond, DebugAction act)
	{
		try {
			tool.post((ATermAppl)ATerm.make("modify-rule(<term>,<int>,<term>,<term>,<term>)",
																			((TideProcess)rule.getProcess()).toTerm(),
																			new Integer(rule.getID()),
																			port.toTerm(), cond.toTerm(), act.toTerm()));
		} catch (ToolException e) {
			System.err.println("ToolException occured: " + e.getMessage());
		}
	}

	//}
	//{ public void requestRuleEnabling(Rule rule, boolean enabling)

	/**
		* Request that a rule is enabled/disabled
		*/
	
	public void requestRuleEnabling(Rule rule, boolean enabling)
	{
		try {
			ATerm req;
			ATerm process = ((TideProcess)rule.getProcess()).toTerm();
			Integer id = new Integer(rule.getID());
			if(enabling)
				req = ATerm.make("enable-rule(<term>,<int>)", process, id);
			else
				req = ATerm.make("disable-rule(<term>,<int>)", process, id);
			tool.post((ATermAppl)req);
		} catch (ToolException e) {
			System.err.println("ToolException occured: " + e.getMessage());
		}
	}

	//}
	//{ public void requestEvaluation(DebugProcess process, type, act)

	/**
		* Request that a rule is enabled/disabled
		*/
	
	public void requestEvaluation(DebugProcess process, String type, DebugAction act)
	{
		try {
			ATerm proc = ((TideProcess)process).toTerm();
			ATerm acts = act.toTerm();
			ATerm req = ATerm.make("evaluate(<term>,<term>,<term>)", 
														 proc, ATerm.make(type), acts);
			tool.post((ATermAppl)req);
		} catch (ToolException e) {
			System.err.println("ToolException occured: " + e.getMessage());
		}
	}

	//}
	//{ public void visualize(DebugProcess process, expr, tmpl)

	/**
		* Request visualization of an expression.
		*
		* @param process process the expression lives in.
		* @param rule the watchpoint rule that updates the expression.
		* @param expr the expression to be visualized.
		* @param tmpl name of template defining visualization procedure.
		*/

	public void visualize(DebugProcess process, Rule rule, String expr,
												String tmpl)
	{
		try {
			ATerm proc = ((TideProcess)process).toTerm();
			Integer id = new Integer(rule.getID());
			ATerm req = ATerm.make("visualize(<term>,<int>,<str>,<str>)",
														 proc, id, expr, tmpl);
			tool.post((ATermAppl)req);
		} catch (ToolException e) {
			System.err.println("ToolException occured: " + e.getMessage());
		}
	}
	//}
}

// vim:ts=2:sw=2
