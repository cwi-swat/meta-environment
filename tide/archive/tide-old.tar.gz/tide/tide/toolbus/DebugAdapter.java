package tide.toolbus;

import tide.debug.*;

import aterm.*;

public class DebugAdapter
  extends DebugProcessGroup
{
	ATerm dap;

	public DebugAdapter(ATerm dap)
	{
		super(dap.toString());
		this.dap = dap;
	}

	public ATerm getDap()
	{
		return dap;
	}
}
