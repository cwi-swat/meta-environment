package tide.toolbus;

import tide.debug.*;

import aterm.*;
import aterm.tool.*;

import java.util.*;
import java.io.*;
import java.net.*;

class ToolBusDebugTool extends DebugToolTif
{
	private ToolBusDebugInterface iface;

	//{ public ToolBusDebugTool(ToolBusDebugInterface iface)

	/**
		* Create a new ToolBusDebugTool
		*/
	
	public ToolBusDebugTool(ToolBusDebugInterface iface)
		throws IOException, UnknownHostException
	{
		super("debug-tool", InetAddress.getLocalHost(), 9500);
		this.iface = iface;
	}

	//}

	//{ protected ATerm handler(ATerm term)

	/**
		* The handler needs to be synchronized
		*/
	
	protected ATerm handler(ATerm term)
		throws ToolException
	{
		synchronized (ToolBusTideControl.sync) {
			return super.handler(term);
		}
	}

	//}
	//{ void event(ATerm from, ATerm event)

	/**
		* Handle debugging events
		*/
	
	void event(ATerm from, ATerm event)
	{
		Vector result;

		result = from.match("proc(<term>,<str>)");
		if(result == null)
			throw new RuntimeException("Illegal process spec: " + from);

		ATerm  dap     = (ATerm)result.elementAt(0);
		String id      = (String)result.elementAt(1);

		System.out.println("adapter = " + dap);
		System.out.println("proc-id = " + id);

		DebugAdapter adapter = iface.getAdapter(dap);

		//{ watchpoint

		result = event.match("watchpoint(<int>,<term>)");
		if(result != null) {
			DebugProcess process = iface.getProcess(dap, id);
			int ruleID  = ((Integer)result.elementAt(0)).intValue();
			Value value = new Value((ATerm)result.elementAt(1));
			Rule rule   = process.getRule(ruleID);
			System.out.println("type = " + rule.getType());
			rule.fireWatchpoint(value);
			return;
		}

		//}
		//{ evaluated

		result = event.match("evaluated(<term>,<term>,<term>)");
		if(result != null) {
			DebugProcess process = iface.getProcess(dap, id);
			String type = result.elementAt(0).toString();
			DebugAction act = new DebugAction((ATerm)result.elementAt(1));
			Value value = new Value((ATerm)result.elementAt(2));
			process.evaluated(type, act, value);
			return;
		}

		//}
		//{ process-created

		result = event.match("process-created");
		if(result != null) {			
			DebugProcess process = new TideProcess(iface, id, adapter);
			iface.processCreated(process, adapter);
			return;
		}

		//}
		//{ process-destroyed

		result = event.match("process-destroyed");
		if(result != null) {
			DebugProcess process = iface.getProcess(dap, id);
			iface.processDestroyed(process);
			return;
		}

		//}
		//{ rule-created

		result = event.match("rule-created(<int>,<term>,<term>,<term>,<term>)");
		if(result != null) {
			DebugProcess process = iface.getProcess(dap, id);
			int ruleID = ((Integer)result.elementAt(0)).intValue();
			String type = result.elementAt(1).toString();
			Port port  = PortFactory.createPort((ATerm)result.elementAt(2));
			Condition cond = ConditionFactory.createCondition((ATerm)result.elementAt(3));
			DebugAction act = DebugActionFactory.createAction((ATerm)result.elementAt(4));
			process.ruleCreated(ruleID, type, port, cond, act);
			return;
		}

		//}
		//{ rule-enabled

		result = event.match("rule-enabled(<int>)");
		if(result != null) {
			DebugProcess process = iface.getProcess(dap, id);
			int ruleID = ((Integer)result.elementAt(0)).intValue();
			process.ruleEnabled(ruleID, true);
			return;
		}

		//}
		//{ rule-disabled

		result = event.match("rule-disabled(<int>)");
		if(result != null) {
			DebugProcess process = iface.getProcess(dap, id);
			int ruleID = ((Integer)result.elementAt(0)).intValue();
			process.ruleEnabled(ruleID, false);
			return;
		}

		//}
		//{ rule-modified

		result = event.match("rule-modified(<int>,<term>,<term>,<term>)");
		if(result != null) {
			DebugProcess process = iface.getProcess(dap, id);
			int ruleID = ((Integer)result.elementAt(0)).intValue();
			Port port  = PortFactory.createPort((ATerm)result.elementAt(1));
			Condition cond = ConditionFactory.createCondition((ATerm)result.elementAt(2));
			DebugAction act = DebugActionFactory.createAction((ATerm)result.elementAt(3));
			process.ruleModified(ruleID, port, cond, act);
			return;
		}

		//}
		//{ rule-destroyed

		result = event.match("rule-deleted(<int>)");
		if(result != null) {
			DebugProcess process = iface.getProcess(dap, id);
			int ruleID = ((Integer)result.elementAt(0)).intValue();
			process.ruleDeleted(ruleID);
			return;
		}

		//}

		System.err.println("ignoring event: " + event);
	}

	//}
	//{ void adapterDisconnected(ATermAppl dap)

	/**
		* An adapter has been disconnected
		*/

	void adapterDisconnected(ATermAppl dap)
	{
		DebugAdapter adapter = iface.getAdapter(dap);
		iface.processGroupDestroyed(adapter);
	}

	//}
	//{ void recTerminate(ATerm t)

	/**
		* Handle termination
		*/

	void recTerminate(ATerm t)
	{
	}

	//}
	//{ void reckAckEvent(ATerm event)

	/**
		* Handle event acknowledgements
		*/

	void recAckEvent(ATerm event)
	{
	}

	//}
}

// vim:ts=2:sw=2
