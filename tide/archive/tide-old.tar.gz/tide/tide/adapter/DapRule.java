package tide.adapter;

import aterm.*;

public class DapRule
{
	//{ Port types

	public final static int PORT_INITIAL      = 0;
	public final static int PORT_STEP         = 1;
	public final static int PORT_LOCATION     = 2;
	public final static int PORT_VAR_ACCESS   = 3;
	public final static int PORT_EXPR_CHANGED = 4;
	public final static int PORT_METHOD_ENTRY = 5;
	public final static int PORT_METHOD_EXIT  = 6;
	public final static int PORT_STOPPED      = 7;
	public final static int PORT_STARTED      = 8;
	public final static int PORT_EXCEPTION    = 9;
	public final static int PORT_SEND         = 10;
	public final static int PORT_RECEIVE      = 11;
	public final static int NR_PORT_TYPES     = 12;

	//}

	boolean enabled;

	int   id;
	int   porttype;
	ATerm type;
	ATerm port;
	ATerm cond;
	ATerm act;

	//{ static int portType(ATerm port)

	static int portType(ATerm port)
	{
		String fun = ((ATermAppl)port).getName();

		int type;

		if(fun.equals("initial"))
			type = PORT_INITIAL;
		else if(fun.equals("step"))
			type = PORT_STEP;
		else if(fun.equals("location"))
			type = PORT_LOCATION;
		else if(fun.equals("var-access"))
			type = PORT_VAR_ACCESS;
		else if(fun.equals("expr-changed"))
			type = PORT_EXPR_CHANGED;
		else if(fun.equals("method-entry"))
			type = PORT_METHOD_ENTRY;
		else if(fun.equals("method-exit"))
			type = PORT_METHOD_EXIT;
		else if(fun.equals("stopped"))
			type = PORT_STOPPED;
		else if(fun.equals("started"))
			type = PORT_STARTED;
		else if(fun.equals("exception"))
			type = PORT_EXCEPTION;
		else if(fun.equals("send"))
			type = PORT_SEND;
		else if(fun.equals("receive"))
			type = PORT_RECEIVE;
		else
			throw new RuntimeException("strange port: " + port);

		return type;
	}

	//}

	//{ public DapRule(int i, ATerm t, ATerm p, ATerm c, ATerm a)

	public DapRule(int i, ATerm t, ATerm p, ATerm c, ATerm a)
	{
		id = i;
		type = t;
		port = p;
		cond = c;
		act  = a;

		porttype = portType(port);
	}

	//}

	//{ public boolean isEnabled()

	/**
		* Check if a rule is currently enabled
		*/

	public boolean isEnabled()
	{
		return enabled;
	}

	//}
	//{ public void setEnabled(boolean on)

	/**
		* Check if a rule is currently enabled
		*/

	public void setEnabled(boolean on)
	{
		enabled = on;
	}

	//}

	//{ public int getId()

	/**
		* Return rule Id
		*/

	public int getId()
	{
		return id;
	}

	//}
	//{ public int getPortType()

	/**
		* Retrieve the type of this port
		*/

	public int getPortType()
	{
		return porttype;
	}

	//}
	//{ public ATerm getPort()

	public ATerm getPort()
	{
		return port;
	}

	//}
	//{ public ATerm getCondition()

	public ATerm getCondition()
	{
		return cond;
	}

	//}
	//{ public ATerm getAction()

	public ATerm getAction()
	{
		return act;
	}

	//}

	//{ public void modify(ATerm port, ATerm cond, ATerm act)

	/**
		* This rule has been modified
		*/

	public void modify(ATerm port, ATerm cond, ATerm act)
	{
		this.port = port;
		this.cond = cond;
		this.act  = act;

		porttype = portType(port);
	}

	//}

	//{ public boolean isStepOver()

	/**
		* Check if this rule is a pure 'step-over' rule
		*/

	public boolean isStepOver()
	{
		return cond.match("higher-equal(start-level,stack-level)") != null;
	}

	//}
}
