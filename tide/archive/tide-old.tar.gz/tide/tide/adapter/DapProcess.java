package tide.adapter;

import java.lang.reflect.*;
import java.util.*;

import aterm.*;
import aterm.tool.*;

abstract public class DapProcess
{
	public final static int STATE_STOPPED = 0;
	public final static int STATE_RUNNING = 1;

	final static int MAX_RULES = 256;
	Class[][] protos = new Class[8][];

	public DebugAdapter adapter;

	protected String pid;
	public DapRule[] rules = new DapRule[MAX_RULES];
	public List[]    rulesPerPort = new List[DapRule.NR_PORT_TYPES];
	public DapRule   current_rule = null;

	int exec_state  = STATE_STOPPED;
	int start_level = 0;

	//{ Patterns and terms

	ATerm termTrue;
	ATerm termFalse;
	ATerm termRunning;
	ATerm termStopped;
	ATerm termUnknown;

	//}

 	//{ public DapProcess(DebugAdapter adapter, String pid)

	/**
		* Construct a new DapProcess
		*/

	public DapProcess(DebugAdapter adapter, String pid)
	{
		this.adapter = adapter;
		this.pid = pid;

		for(int i=0; i<DapRule.NR_PORT_TYPES; i++) {
			rulesPerPort[i] = new Vector();
		}

		try {
			Class aterm = Class.forName("aterm.ATerm");
			for(int i=0; i<8; i++) {
				protos[i] = new Class[i];
				for(int j=0; j<i; j++)
					protos[i][j] = aterm;
			}
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("could not find class: aterm.ATerm");
		}

		try {
			termTrue    = ATerm.parse("true");
			termFalse   = ATerm.parse("false");
			termRunning = ATerm.parse("running");
			termStopped = ATerm.parse("stopped");
			termUnknown = ATerm.parse("unknown");
		} catch (ParseError e) {
			throw new RuntimeException("internal error, malformed term: " +
																 e.getMessage());
		}
	}

	//}
	//{ public String getPid()

	/**
		* Retrieve the process-id of this process
		*/

	public String getPid()
	{
		return pid;
	}

	//}
	//{ public int getExecState()

	/**
		* Return the current state of execution
		*/

	public int getExecState()
	{
		return exec_state;
	}

	//}
	//{ public void changeExecState(int newstate)

	/**
		* Change the current state of execution
		*/

	public void changeExecState(int newstate)
	{
		if(exec_state != newstate) {
			exec_state = newstate;
			switch(exec_state) {
				case STATE_STOPPED:
					fireRules(DapRule.PORT_STOPPED);
					break;
				case STATE_RUNNING:
					fireRules(DapRule.PORT_STARTED);
					break;
			}
		}
	}

	//}
	//{ public boolean isRunning()

	/**
		* Check if this process is currently running
		*/

	public boolean isRunning()
	{
		return exec_state == STATE_RUNNING;
	}

	//}

	//{ public void fireLocationRules(String file, int sl, sc, el, ec)

	public void fireLocationRules(String filename, 
																int sl, int sc, int el, int ec)
	{
		Vector result;
		Object[] elems;
		String file;
		int line, col;

		elems = rulesPerPort[DapRule.PORT_LOCATION].toArray();
		for(int i=0; i<elems.length; i++) {
			DapRule rule = (DapRule)elems[i];
			ATerm port   = rule.getPort();
			
			result = port.match("location(pos(<str>,<int>,<int>))");
			if(result != null) {
				file = (String)result.elementAt(0);
				line = ((Integer)result.elementAt(1)).intValue();
				col  = ((Integer)result.elementAt(2)).intValue();
			} else {
				result = port.match("location(line(<str>,<int>))");
				if(result != null) {
					file = (String)result.elementAt(0);
					line = ((Integer)result.elementAt(1)).intValue();
					col  = 0;
				} else {
					throw new RuntimeException("strange port spec: " + port);
				}
			}

			System.out.println("port = " + port);
			System.out.println("filename=" + filename + ",sl=" + sl + ",sc=" + sc +
												 ",el=" + el + ",ec=" + ec + ",file=" + file + 
												 ",line=" + line + ",col=" + col);

			if(filename.equals(file)) {
				if(line > sl || (line == sl && col >= sc)) {
					// Start is ok
					if(line < el || (line == el && (col <= ec || ec == -1))) {
						// End is also ok
						fireRule(rule);
					}
				}
			}
		}
	}

	//}
	//{ public void fireRules(int porttype)

	/**
		* Fire all enabled rules for a certain porttype
		*/

	public void fireRules(int porttype)
	{
		Object[] elems = rulesPerPort[porttype].toArray();
		for(int i=0; i<elems.length; i++) {
			DapRule rule = (DapRule)elems[i];
			fireRule(rule);
		}
	}

	//}
	//{ public void fireRule(DapRule rule)

	/**
		* Fire a rule provided its condition evaluates to true
		*/

	public void fireRule(DapRule rule)
	{
		DapRule old_rule = current_rule;
		current_rule = rule;

		ATerm cond = rule.getCondition();
		ATerm result = evaluate(cond);
		if(result.isEqual(termTrue)) {
			result = evaluate(rule.getAction());
			adapter.watchpoint(pid, current_rule, result);
		}

		current_rule = old_rule;
	}

	//}

	//{ public DapRule createRule(ATerm type, ATerm port, ATerm cond, ATerm act)

	/**
		* Create a new rule
		*/

	public DapRule createRule(ATerm type, ATerm port, ATerm cond, ATerm act)
	{
		int id;

		/* Find a free rule */
		for(id=0; id<MAX_RULES; id++)
			if(rules[id] == null)
				break;

		if(id >= MAX_RULES)
			throw new RuntimeException("too many rules: " + id);

		DapRule rule = new DapRule(id, type, port, cond, act);

		rules[rule.getId()] = rule;
		handleRuleCreation(rule);
		
		return rule;
	}

	//}
	//{ public void enableRule(int rid)

	/**
		* Enable an existing rule
		*/

	public void enableRule(int rid)
	{
		DapRule rule = rules[rid];
		int porttype = rule.getPortType();

		rule.setEnabled(true);
		synchronized (rulesPerPort[porttype]) {
			rulesPerPort[porttype].add(rule);
		}
		handleRuleEnabling(rule);
	}

	//}
	//{ public void disableRule(int rid)

	/**
		* Disable an existing rule
		*/

	public void disableRule(int rid)
	{
		DapRule rule = rules[rid];
		int porttype = rule.getPortType();

		rule.setEnabled(false);
		synchronized (rulesPerPort[porttype]) {
			rulesPerPort[rule.getPortType()].remove(rule);
		}
		handleRuleDisabling(rule);
	}

	//}
	//{ public void modifyRule(int rid, ATerm port, ATerm cond, ATerm act)

	/**
		* Modify an existing rule
		*/

	public void modifyRule(int rid, ATerm port, ATerm cond, ATerm act)
	{
		int oldtype, newtype;

		DapRule rule = rules[rid];
		oldtype = rule.getPortType();
		rule.modify(port, cond, act);
		newtype = rule.getPortType();

		synchronized (rulesPerPort[oldtype]) {
			synchronized (rulesPerPort[newtype]) {
				if(rule.isEnabled() && newtype != oldtype) {
					rulesPerPort[oldtype].remove(rule);
					rulesPerPort[newtype].add(rule);
				}
			}
		}
	}

	//}
	//{ public void deleteRule(int rid)

	/**
		* Delete an existing rule
		*/

	public void deleteRule(int rid)
	{
		DapRule rule = rules[rid];
		int porttype = rule.getPortType();
		synchronized (rulesPerPort[porttype]) {
			rulesPerPort[porttype].remove(rule);
		}
		rules[rid] = null;
		handleRuleDestruction(rule);
	}

	//}
	//{ public ATerm evaluate(ATerm act)

	/**
		* Evaluate a debug action
		*/ 

	public ATerm evaluate(ATerm act)
	{
		int i;

		switch(act.getType()) {
			case ATerm.LIST:
				//{ Evaluate all elements in a list

				ATermList list = (ATermList)act;
				List result = new LinkedList();
				while(!list.isEmpty()) {
					ATerm elem = list.getFirst();
					ATerm val  = evaluate(elem);
					list = list.getNext();
					if(!val.equals(termTrue))
						result.add(elem);
				}
				if(result.isEmpty())
					return termTrue;
				list = ATerm.the_world.empty;
				for(int idx=result.size()-1; idx>=0; idx--)
					list = ATerm.the_world.makeList((ATerm)result.get(idx), list);
				return list;

				//}

			case ATerm.APPL:
				//{ Evaluate a function

				ATermAppl appl = (ATermAppl)act;
				if(appl.isQuoted()) {
					return act;
				} else {
					String action  = appl.getName();
					Class myclass = getClass();
					String name = "action" + capitalize(action, true);
					int arity   = appl.getArity();
					
					boolean found = false;

					do {
						try {
							Method method = myclass.getDeclaredMethod(name, protos[arity]);
							found = true;
							Object[] args = new Object[arity];
							for(i=0; i<arity; i++)
								args[i] = evaluate(appl.getArgument(i));
							System.out.println("invoking method: " + name);
							return (ATerm)method.invoke(this, args);
						} catch (NoSuchMethodException e) {
							found = false;
						} catch (InvocationTargetException e) {
							e.printStackTrace();
							throw new RuntimeException("error invoking method: " + 
																				 e.getMessage());
						} catch (IllegalAccessException e) {
							e.printStackTrace();
							throw new RuntimeException("access error invoking method: " + 
																				 e.getMessage());
						}
						myclass = myclass.getSuperclass();
					} while(!found && myclass.getSuperclass() != null);
					
					if(!found)
						return ATerm.make("error(\"unknown function: " + action + "/" +
															arity + "\")");
				}
					
				//}

			default:
				return act;
		} 
	}

	//}

  //{ static public String capitalize(String str, boolean firstCap)

  static public String capitalize(String str, boolean firstCap)
  {
    StringBuffer name = new StringBuffer();
    for(int i=0; i<str.length(); i++) {
       if(str.charAt(i) == '-')
     firstCap = true;
       else {
     if(firstCap) {
       name.append(Character.toUpperCase(str.charAt(i)));
       firstCap = false;
     } else
       name.append(str.charAt(i));
       }
    }
    return name.toString();
  }

  //}

	//{ public void handleRuleCreation(DapRule rule)

	/**
		* Create a new rule
		*/

	public void handleRuleCreation(DapRule rule)
	{
	}

	//}
	//{ public void handleRuleDestruction(DapRule rule)

	/**
		* Handle destruction of rules
		*/

	public void handleRuleDestruction(DapRule rule)
	{
	}

	//}
	//{ public void handleRuleEnabling(DapRule rule)

	/**
		* Enable a rule
		*/

	public void handleRuleEnabling(DapRule rule)
	{
	}

	//}
	//{ public void handleRuleDisabling(DapRule rule)

	/**
		* Disable a rule
		*/

	public void handleRuleDisabling(DapRule rule)
	{
	}

	//}

	/**
		* Effect functions that can be overridden by more complicated process
		* implementations
		*/

	//{ public void doBreak()

	/**
		* Stop execution of this process
		*/

	public void doBreak()
	{
		exec_state = STATE_STOPPED;
	}

	//}
	//{ public void doResume()

	/**
		* Stop execution of this process
		*/

	public void doResume()
	{
		exec_state  = STATE_RUNNING;
		start_level = getStackLevel();
	}

	//}
	//{ public void doDisable(DapRule rule)

	/**
		* Disable a rule
		*/

	public void doDisable(DapRule rule)
	{
		disableRule(rule.getId());
		try {
			System.out.println("posting rule-disabled: " + rule.getId());
			adapter.post((ATermAppl)ATerm.make("rule-disabled(proc(<str>),<int>)", 
																				 pid, new Integer(rule.getId())));
		} catch (ToolException e) {
			System.err.println("could not notify tide of rule disabling: " +
												 e.getMessage());
		}
	}

	//}

	/**
		* Standard actions
		*/

	//{ public ATerm actionTrue() 

	/**
		* Return the term "true"
		*/

	public ATerm actionTrue() 
	{ 
		return termTrue;
	}

	//}
	//{ public ATerm actionFalse()

	/**
		* Return the term "false"
		*/

	public ATerm actionFalse()
	{
		return termFalse;
	}

	//}
	//{ public ATerm actionBreak()

	/**
		* Halt the execution of this process
		*/

	public ATerm actionBreak()
	{
		doBreak();
		return termTrue;
	}

	//}
	//{ public ATerm actionResume()

	/**
		* Resume execution of this process
		*/

	public ATerm actionResume()
	{
		doResume();
		return termTrue;
	}

	//}
	//{ public ATerm actionState()

	/**
		* Retrieve the current state of execution (either 'running' or 'stopped')
		*/

	public ATerm actionState()
	{
		switch(exec_state) {
			case STATE_RUNNING:
				return termRunning;
			case STATE_STOPPED:
				return termStopped;
			default:
				return termUnknown;
		}
	}

	//}
	//{ public ATerm actionDisable()

	/**
		* Disable the current rule
		*/

	public ATerm actionDisable()
	{
		doDisable(current_rule);
		return termTrue;
	}

	//}
	//{ public ATerm actionHigherEqual(ATerm t1, ATerm t2)

	/**
		* Compare two integer terms
		*/

	public ATerm actionHigherEqual(ATerm t1, ATerm t2)
	{
		if(t1.getType() == ATerm.INT && t2.getType() == ATerm.INT) {
			ATermInt i1 = (ATermInt)t1;
			ATermInt i2 = (ATermInt)t2;
			if(i1.getInt() >= i2.getInt())
				return termTrue;
		}
		return termFalse;
	}

	//}
	//{ public ATerm actionEqual(ATerm t1, ATerm t2)

	/**
		* Compare two terms
		*/

	public ATerm actionEqual(ATerm t1, ATerm t2)
	{
		return t1.isEqual(t2) ? termTrue : termFalse;
	}

	//}
	//{ public ATerm actionStartLevel()

	/**
		* Retrieve the stack-level of the last resume
		*/

	public ATerm actionStartLevel()
	{
		return ATerm.parse("" + start_level);
	}

	//}
	//{ public ATerm actionStackLevel()

	/**
		* Retrieve the current stack-level
		*/

	public ATerm actionStackLevel()
	{
		return ATerm.parse("" + getStackLevel());
	}

	//}

	public abstract ATerm actionCpe();
	public abstract ATerm actionVar(ATerm var);

	public abstract int getStackLevel();
}

