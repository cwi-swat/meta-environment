package tide.adapter;

import java.util.*;
import java.io.*;
import java.net.*;

import aterm.*;
import aterm.tool.*;

public class DebugAdapter
  extends DebugAdapterTif
{
	Map processes;

	//{ protected DebugAdapter(String name) 

	/**
		* Construct a new DebugAdapter object
		*/

	protected DebugAdapter(String name) 
		throws UnknownHostException 
	{ 
		super(name);
		initDebugAdapter();
	}

	//}
	//{ protected DebugAdapter(String name, InetAddress address, int port)

	/**
		* Construct a new DebugAdapter object
		*/

  protected DebugAdapter(String name, InetAddress address, int port)
		throws UnknownHostException  
	{ 
		super(name, address, port);
		initDebugAdapter();
	}

	//}
	//{ protected DebugAdapter(String[] args)

	/**
		* Construct a new DebugAdapter object
		*/

  protected DebugAdapter(String[] args)
		throws UnknownHostException 
	{ 
		super(args); 
		initDebugAdapter();
	}

	//}
	//{ void initDebugAdapter()

	/**
		* Initialize this DebugAdapter object
		*/

	void initDebugAdapter()
	{
		processes = new HashMap();
	}

	//}

	//{ protected void processCreated(DapProcess process)

	/**
		* A new process has been created
		*/

	protected void processCreated(DapProcess process)
	{
		processes.put(process.getPid(), process);
		try {
			post((ATermAppl)ATerm.make("process-created(<str>)", process.getPid()));
		} catch (ToolException e) {
			System.err.println("could not notify tide of process creation: " +
												 e.getMessage());
		}
	}

	//}
	//{ public DapProcess getProcess(String id)

	/**
		* Retrieve a specific process
		*/

	public DapProcess getProcess(String id)
	{
		return (DapProcess)processes.get(id);
	}

	//}
	//{ public void watchpoint(String pid, DapRule rule, ATerm value)

	/**
		* Generate a watchpoint event
		*/
	
	public void watchpoint(String pid, DapRule rule, ATerm value)
	{
		try {
			post((ATermAppl)ATerm.make("watchpoint(<str>,<int>,<term>)",
																 pid, new Integer(rule.getId()), value));
		} catch (ToolException e) {
			System.err.println("ToolException: " + e.getMessage());
		}
	}

	//}

	//{ ATerm createRule(String pid, ATerm type, port, cond, act)

	/**
		* Create a new rule
		*/

  ATerm createRule(String pid, ATerm type, ATerm port, ATerm cond, ATerm act)
	{
		DapProcess proc = getProcess(pid);
		DapRule rule = proc.createRule(type, port, cond, act);
        
		Vector args = new Vector(6);
		args.addElement(pid);
		args.addElement(new Integer(rule.getId()));
		args.addElement(type);
		args.addElement(port);
		args.addElement(cond);
		args.addElement(act);

		return ATerm.make("snd-value(rule-created(<str>,<int>,<term>," +
											"<term>,<term>,<term>))", args.elements());
	}

	//}
	//{ void enableRule(String pid, int rid)

	/**
		* Enable a rule
		*/

  void enableRule(String pid, int rid)
	{
		DapProcess proc = getProcess(pid);
		proc.enableRule(rid);
	}

	//}
	//{ void disableRule(String pid, int rid)

	/**
		* Disable a rule
		*/

  void disableRule(String pid, int rid)
	{
		DapProcess proc = getProcess(pid);
		proc.disableRule(rid);
	}

	//}
	//{ void modifyRule(String pid, int rid, ATerm port, ATerm cond, ATerm act)

	/**
		* Modify an existing rule
		*/

	void modifyRule(String pid, int rid, ATerm port, ATerm cond, ATerm act)
	{
		DapProcess proc = getProcess(pid);
		proc.modifyRule(rid, port, cond, act);
	}

	//}
	//{ void deleteRule(String pid, int rid)

	/**
		* Delete an existing rule
		*/

  void deleteRule(String pid, int rid)
	{
		DapProcess proc = getProcess(pid);
		proc.deleteRule(rid);
	}

	//}
	//{ ATerm evaluate(String pid, ATerm act)

	/**
		* Evaluate a list of actions
		*/

  ATerm evaluate(String pid, ATerm act)
	{
		DapProcess proc = getProcess(pid);
		ATerm result = proc.evaluate(act);

		return ATerm.make("snd-value(evaluated(<str>,<term>,<term>))",
											pid, act, result);
	}

	//}
	//{ void recTerminate(ATerm arg)

	/**
		* Received a termination notification from the debugger bus
		*/

  void recTerminate(ATerm arg)
	{
	}

	//}
	//{ void recAckEvent(ATerm event)

	/**
		* Received an event acknowledgement from the debugger bus.
		*/

	void recAckEvent(ATerm event)
	{
	}

	//}
}
