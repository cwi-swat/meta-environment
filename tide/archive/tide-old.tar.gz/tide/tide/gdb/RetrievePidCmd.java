package tide.gdb;

import com.oroinc.text.regex.*;

public class RetrievePidCmd extends Command
{
	static Pattern patternInfo;
	GdbProcess process;

	//{ public RetrievePidCmd(GdbAdapter adapter, GdbProcess process)

	/**
		* Continue execution
		*/

	public RetrievePidCmd(GdbAdapter adapter, GdbProcess process)
	{
		super(adapter);
		this.process = process;
	}

	//}
	//{ public void initPatterns(PatternCompiler comp)

	public void initPatterns(PatternCompiler comp)
		throws MalformedPatternException
	{
		super.initPatterns(comp);
		patternInfo = comp.compile("Information for /proc/([0-9]+):");
		// Example:
		// "Information for /proc/54321:"
	}

	//}

	//{ public String command()

	/**
		* Retrieve the command needed to continue running
		*/

	public String command()
	{
		return "info proc\n";
	}

	//}
	//{ public boolean response(String line)

	/**
		* Handle all kinds of reactions on the 'run' command
		*/

	public boolean response(String line)
	{
		if(line.startsWith("Process status flags:")) {
			return false;
		} else if(line.startsWith("Reason for stopping:")) {
			return false;
		} else if(line.startsWith("Additional signal/fault info:")) {
			return true;
		} else if(matcher.matches(line, patternInfo)) {
			MatchResult result = matcher.getMatch();
			int pid = Integer.parseInt(result.group(1));
			System.out.println("*** PID: " + pid);
			process.setPid(pid);
			return false;
		} else {
			System.out.println("line '" + line + 
												 "' does not match with patternInfo");
			return false;
		}
	}

	//}
}
