package tide.gdb;

import com.oroinc.text.regex.*;

/**
	* Objects of this class represent commands for gdb
	*/

public abstract class Command
{
	static PatternMatcher matcher = new Perl5Matcher();
	static String PATTERN_FILE    = "[a-zA-Z_\\-\\.]+";

	GdbAdapter adapter;
	boolean completed;

	//{ public Command(GdbAdapter adapter)

	/**
		* Construct a new command object
		*/

	public Command(GdbAdapter adapter)
	{
		this.adapter = adapter;

		matcher = new Perl5Matcher();
		try {
			initPatterns(new Perl5Compiler());
		} catch (MalformedPatternException e) {
			e.printStackTrace();
			throw new RuntimeException("internal error, malformed pattern: " +
																	 e.getMessage());
		}
	}

	//}
	//{ public void initPatterns(PatternCompiler comp)

	/**
		* Most commands need one or more patterns. Override this method
		* in sub-classes to initialize these patterns.
		*/

	public void initPatterns(PatternCompiler comp)
		throws MalformedPatternException
	{
	}

	//}
	
	abstract public String command();
	abstract public boolean response(String line);

	//{ public boolean isCompleted()

	/**
		* Check if this command has been completed (processed by gdb)
		*/

	public boolean isCompleted()
	{
		return completed;
	}

	//}
	//{ public void setCompleted(boolean on)

	/**
		* Check if this command has been completed (processed by gdb)
		*/

	public void setCompleted(boolean on)
	{
		completed = on;
	}

	//}

	//{ public String toString()

	public String toString()
	{
		return command();
	}

	//}
}
