package tide.gdb;

import com.oroinc.text.regex.*;

import aterm.*;

public class RetrieveCpeCmd extends Command
{
	static Pattern patternCpe;
	String file;
	int    linenr;

	//{ public RetrieveCpeCmd(GdbAdapter adapter)

	/**
		* Retrieve the current point of execution
		*/

	public RetrieveCpeCmd(GdbAdapter adapter)
	{
		super(adapter);
	}

	//}
	//{ public void initPatterns(PatternCompiler comp)

	public void initPatterns(PatternCompiler comp)
		throws MalformedPatternException
	{
		super.initPatterns(comp);
		patternCpe = comp.compile("#0\\s+[a-zA-Z_][a-zA-Z_0-9]*\\s+" +
															"\\([^\\)]*\\)\\s+at\\s+" +
															"(" + PATTERN_FILE + "):([0-9]+)");
		// Example:
		// #0  main (argc=1, argv=0xefffe7d4) at stress.c:772
	}

	//}
	//{ public String command()

	public String command()
	{
		return "where 1\n";
	}

	//}
	//{ public boolean response(String line)

	synchronized public boolean response(String line)
	{
		if(matcher.matches(line, patternCpe)) {
			MatchResult result = matcher.getMatch();
			file = result.group(1);
			linenr = Integer.parseInt(result.group(2));
			System.err.println("CPE found: " + file + "," + linenr);
			return true;
		} else {
			System.err.println("line '" + line + "' does not match with CPE pattern");
			return false;
		}
	}

	//}
	//{ public ATerm getCpe()

	/**
		* Retrieve the current point of execution
		*/

	public ATerm getCpe()
	{
		if(file == null)
			return null;

		return ATerm.make("cpe(line(<str>,<int>))", file, new Integer(linenr));
	}

	//}
}
