package tide.gdb;

import java.util.*;
import java.io.*;
import java.net.*;

import aterm.tool.*;

import tide.adapter.*;


public class GdbAdapter 
	extends DebugAdapter
{
	static final int MODE_STEP_INTO = 0;
	static final int MODE_STEP_OVER = 1;
	static final int MODE_RUN       = 2;

	String name;
	Process gdb;
	GdbProcess process;
	int pid;

	BufferedReader input;
	BufferedReader error;
	Writer output;

	//{ static final void main(String[] args)

	/**
		* Start the gdb adapter
		*/

	static final void main(String[] args)
		throws IOException, ToolException
	{
		int pid = -1;
		String program = null;
		String arguments = "";

		for(int i=0; i<args.length; i++) {
			if(args[i].equals("-attach"))
				pid = Integer.parseInt(args[++i]);
			else if(args[i].equals("-program"))
				program = args[++i];
			else if(args[i].equals("-help"))
				usage();
			else if(args[i].equals("-args")) {
				if(i < args.length) {
					arguments = args[i++];
					for(; i<args.length; i++)
						arguments += " " + args[i];
				}
			}
		}

		if(program == null)
			usage();

		String cmd = "gdb -f -q " + program;
		if(pid >= 0)
			cmd += " " + pid;

		Process process = Runtime.getRuntime().exec(cmd);
		GdbAdapter adapter = new GdbAdapter(program, arguments, process, null, 9500);

		adapter.run();
	}

	//}
	//{ static void usage()

	/**
		* Print usage information and exit
		*/

	static void usage()
	{
		System.err.println("usage: gdb-adapter -program <prg> [-attach <pid>]");
		System.exit(1);
	}

	//}

	//{ public GdbAdapter(String name, args, Process process, host, port)

	/**
		* Construct a new GdbAdapter object
		*/

	public GdbAdapter(String filename, String args, Process proc, 
										String host, int port)
		throws IOException, ToolException
	{
		super("debug-adapter", host == null ? InetAddress.getLocalHost() : 
					InetAddress.getByName(host), port);

		File file = new File(filename);
		String name = file.getName();
		this.name = name;
		gdb    = proc;

		// Create GDB input/error readers
		input = new BufferedReader(new InputStreamReader(proc.getInputStream()));
		error = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
		output = new OutputStreamWriter(proc.getOutputStream());

		// Connect to TIDE
		connect();

		// Build connection with GDB
		process = new GdbProcess(this, name);
		System.err.println("set args " + args);
		writeln("set args " + args);
		writeln("set prompt (gdb)\\n");
		writeln("define hook-stop");
		writeln("bt -1");
		writeln("end");
		evaluate(new SetBreakpointCmd(this, "main"));
		evaluate(new ContinueCmd(this, process) {
			public String command() { return "run\n"; }
		});
		evaluate(new RetrievePidCmd(this, process));
		System.out.println("Started!");
		processCreated(process);
	}

	//}
	//{ public void writeln(String line)

	/**
		* Write a line to the gdb instance
		*/

	public void writeln(String line)
	{
		try {
			output.write(line);
			output.write("\n");
			output.flush();
		} catch (IOException e) {
			System.err.println("connection with gdb broken!");
			
		}
	}

	//}

	//{ public void evaluate(Command cmd)

	/**
		* Evaluate a gdb command 
		*/

	public void evaluate(Command cmd)
	{
		try {
			String string = cmd.command();
			System.out.println("entering poll mode with gdb command: " + string);
			output.write(string);
			output.flush();
			String line;
			do {
				line = input.readLine();
				System.out.println("processing line in poll mode: " + line);
				if(line.length() == 0)
					continue; // Ignore empty lines
				else if(line.startsWith("(gdb)"))
					continue; // Ignore prompt
				else if(line.startsWith("Starting program:"))
					continue; // Ignore 'Starting program:' line
			} while(!cmd.response(line));
			System.out.println("poll mode done!");
		} catch (IOException e) {
			System.err.println("connection with GDB broken.");
			System.exit(1);
		}
	}

	//}

	//{ public int calcRunMode()

	/**
		* Calculate the run mode depending on the active rules
		*/

	public int calcRunMode()
	{
		if(process.rulesPerPort[DapRule.PORT_STEP].size() == 0)
			return MODE_RUN;

		// Look for any 'non step-over' rules
		Iterator iter = process.rulesPerPort[DapRule.PORT_STEP].iterator();
		while(iter.hasNext()) {
			DapRule rule = (DapRule)iter.next();
			if(!rule.isStepOver())
				return MODE_STEP_INTO;
		}

		return MODE_STEP_OVER;
	}

	//}
}

