package tide.gdb;

import java.util.*;
import java.io.*;

import aterm.*;

import tide.adapter.*;

public class GdbProcess 
	extends DapProcess
	implements Runnable
{
	GdbAdapter adapter;
	Thread thread;

	String name;
	int    pid;
	String file;
	int    line;
	int    stackLevel;
	Map    rulesByBreak;
	Map    breaksByRule;

	//{ public GdbProcess(GdbAdapter adapter, String name)

	/**
		* Construct a new GdbProcess object
		*/

	public GdbProcess(GdbAdapter adapter, String name)
	{
		super(adapter, name);
		this.adapter = adapter;
		this.name    = name;

		rulesByBreak = new HashMap();
		breaksByRule = new HashMap();
	}

	//}
	//{ public void setPid(int pid)

	/**
		* Set the process-id
		*/

	public void setPid(int pid)
	{
		this.pid = pid;
		super.pid = name + "-" + pid;
	}

	//}
	//{ public void setCpe(String file, int line)

	/**
		* Change the current point of execution
		*/

	public void setCpe(String file, int line)
	{
		this.file = file;
		this.line = line;
	}

	//}
	//{ public void setStackLevel(int level)

	/**
		* Change the current stack level
		*/

	public void setStackLevel(int level)
	{
		stackLevel = level;
	}

	//}

	//{ public void handleRuleCreation(DapRule rule)

	/**
		* Create a new rule
		*/

	public void handleRuleCreation(DapRule rule)
	{
		super.handleRuleCreation(rule);
		Vector result;

		result = rule.getPort().match("location(pos(<str>,<int>,<int>))");
		if(result != null) {
			String file = (String)result.elementAt(0);
			int  linenr = ((Integer)result.elementAt(1)).intValue();
			SetBreakpointCmd cmd = new SetBreakpointCmd(adapter, file, linenr);
			adapter.evaluate(cmd);
			Integer brk = new Integer(cmd.getBreakpoint());
			breaksByRule.put(rule, brk);
			rulesByBreak.put(brk, rule);
			adapter.writeln("disable " + brk);
		}
	}

	//}
	//{ public void handleRuleDestruction(DapRule rule)

	/**
		* Handle destruction of rules
		*/

	public void handleRuleDestruction(DapRule rule)
	{
		super.handleRuleDestruction(rule);
		Integer brk = (Integer)breaksByRule.get(rule);
		if(brk != null) {
			adapter.writeln("delete " + brk);
			breaksByRule.remove(rule);
			rulesByBreak.remove(brk);
		}
	}

	//}
	//{ public void handleRuleEnabling(DapRule rule)

	/**
		* Enable a rule
		*/

	public void handleRuleEnabling(DapRule rule)
	{
		super.handleRuleEnabling(rule);
		Integer brk = (Integer)breaksByRule.get(rule);
		if(brk != null)
			adapter.writeln("enable " + brk);
	}

	//}
	//{ public void handleRuleDisabling(DapRule rule)

	/**
		* Disable a rule
		*/

	public void handleRuleDisabling(DapRule rule)
	{
		super.handleRuleDisabling(rule);
		Integer brk = (Integer)breaksByRule.get(rule);
		if(brk != null)
			adapter.writeln("disable " + brk);
	}

	//}

	//{ public void doResume()

	/**
		* Stop execution of this process
		*/

	public void doResume()
	{
		System.out.println("doResume called");
		fireRules(DapRule.PORT_STARTED);
		super.doResume();
		
		thread = new Thread(this);
		thread.start();
	}

	//}
	//{ public void doBreak()

	/**
		* Stop execution of this process
		*/

	public void doBreak()
	{
		System.err.println("break not supported (yet!)");
		super.doBreak();
		try {
			Runtime.getRuntime().exec("/usr/bin/kill -INT " + pid);
		} catch (IOException e) {
			System.err.println("could not execute '/usr/bin/kill' to kill program: " +
												 e.getMessage());
		}
	}

	//}

	//{ public ATerm actionCpe()

	/**
		* Retrieve the current point of exection
		*/

	public ATerm actionCpe()
	{
		if(file == null)
			return ATerm.make("cpe(unknown)");
		else
			return ATerm.make("cpe(line(<str>,<int>))", file, new Integer(line));
	}

	//}
	//{ public ATerm actionVar(ATerm var)

	/**
		* Retrieve the value of a variable
		*/

	public ATerm actionVar(ATerm var)
	{
		ATerm cpe = null;
		ATermAppl appl = (ATermAppl)var;

		RetrieveVarCmd cmd = new RetrieveVarCmd(adapter, appl.getName());
		adapter.evaluate(cmd);
		return cmd.getValue();
	}

	//}

	//{ public int getStackLevel()

	/**
		* Retrieve the current stack level
		*/

	public int getStackLevel()
	{
		return stackLevel;
	}

	//}

	//{ public void run()

	/**
		* Run the program
		*/

	public void run()
	{
		fireRules(DapRule.PORT_STARTED);
		while(getExecState() == STATE_RUNNING) {
			ContinueCmd cmd = new ContinueCmd(adapter, this);
			adapter.evaluate(cmd);
			fireRules(DapRule.PORT_STEP);
			fireLocationRules(file, line, 0, line, -1);
		}
		fireRules(DapRule.PORT_STOPPED);
	}


	//}
}
