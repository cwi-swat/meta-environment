package tide.gdb;

import com.oroinc.text.regex.*;

public class ContinueCmd extends Command
{
	static Pattern patternStoppedKnown;
	static Pattern patternStoppedUnknown;
	static Pattern patternFrame;
	GdbProcess process;

	//{ public ContinueCmd(GdbAdapter adapter, GdbProcess process)

	/**
		* Continue execution
		*/

	public ContinueCmd(GdbAdapter adapter, GdbProcess process)
	{
		super(adapter);
		this.process = process;
	}

	//}
	//{ public void initPatterns(PatternCompiler comp)

	public void initPatterns(PatternCompiler comp)
		throws MalformedPatternException
	{
		super.initPatterns(comp);
		if(patternStoppedKnown == null) {
			patternStoppedKnown   = comp.compile("\032\032([^:]+):([0-9]+):.*");
			patternStoppedUnknown = comp.compile("0x[0-9a-f]+\\sin\\s.+()");
			patternFrame          = comp.compile("#([0-9]+)\\s+.*");
		}
	}

	//}

	//{ public String command()

	/**
		* Retrieve the command needed to continue running
		*/

	public String command()
	{
		switch(adapter.calcRunMode()) {
			case GdbAdapter.MODE_STEP_INTO:
				System.err.println("single stepping...");
				return "step\n";
			case GdbAdapter.MODE_STEP_OVER:
				System.err.println("stepping over...");
				return "next\n";
			case GdbAdapter.MODE_RUN:
				System.err.println("running...");
				return "cont\n";
			default:
				throw new RuntimeException("illegal run-mode!");
		}
	}

	//}
	//{ public boolean response(String line)

	/**
		* Handle all kinds of reactions on the 'run' command
		*/

	public boolean response(String line)
	{
		if(line.startsWith("Breakpoint")) {
			// We hit a breakpoint!
			return false;
		} else if(matcher.matches(line, patternFrame)) {
			MatchResult result = matcher.getMatch();
			int level = Integer.parseInt(result.group(1));
			process.setStackLevel(level);
			System.out.println("*** stack level: " + level);
			return false;
		} else if(matcher.matches(line, patternStoppedKnown)) {
			MatchResult result = matcher.getMatch();
			String file   = result.group(1);
			int linenr = Integer.parseInt(result.group(2));
			System.out.println("execution stopped: file=" + file + 
												 ",line=" + linenr);
			process.setCpe(file, linenr);
			return true;
		} else if(matcher.matches(line, patternStoppedUnknown)) {
			System.out.println("execution stopped at unknown: " + line);
			process.setCpe(null, 0);
			return true;
		} else {
			System.out.println("line '" + line + "' does not match with patternStopped");
			return false;
		}
	}

	//}
}
