package tide.gdb;

import com.oroinc.text.regex.*;

import aterm.*;

public class RetrieveVarCmd extends Command
{
	static Pattern patternVar;

	String var;
	ATerm  value;
 
	//{ public RetrieveVarCmd(GdbAdapter adapter, String var)

	/**
		* Retrieve the value of a variable
		*/

	public RetrieveVarCmd(GdbAdapter adapter, String var)
	{
		super(adapter);
		this.var = var;
	}

	//}
	//{ public void initPatterns(PatternCompiler comp)

	public void initPatterns(PatternCompiler comp)
		throws MalformedPatternException
	{
		super.initPatterns(comp);
		patternVar = comp.compile("\\$[0-9]*\\s+=\\s+(.+)");
		// Example:
		// $1 = 334
	}

	//}
	//{ public String command()

	public String command()
	{
		return "print " + var + "\n";
	}

	//}
	//{ public boolean response(String line)

	synchronized public boolean response(String line)
	{
		if(matcher.matches(line, patternVar)) {
			MatchResult result = matcher.getMatch();
			value = ATerm.make("<str>", result.group(1));
			System.err.println("VAR found: " + value);
			notify();
			return true;
		} else if(line.startsWith("No symbol")) {
			value = ATerm.make("error(\"unknown variable: " + var + "\")"); 
			return true;
		} else {
			System.err.println("line '" + line + "' does not match with VAR pattern");
			return false;
		}
	}

	//}
	//{ public ATerm getValue()

	/**
		* Retrieve the current point of execution
		*/

	public ATerm getValue()
	{
		if(value == null)
			return null;

		return value;
	}

	//}
}
