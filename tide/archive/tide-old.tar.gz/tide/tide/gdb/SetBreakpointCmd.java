package tide.gdb;

import java.io.*;
import com.oroinc.text.regex.*;

public class SetBreakpointCmd
  extends Command
{
	static Pattern breakPattern;

	int breakpoint;
	String method;
	String file;
	int    linenr;

	//{ public SetBreakpointCmd(GdbAdapter adapter, String method)

	/**
		* Set a breakpoint at the specified method 
		*/

	public SetBreakpointCmd(GdbAdapter adapter, String method)
	{
		super(adapter);
		this.method = method;
	}

	//}
	//{ public SetBreakpointCmd(GdbAdapter adapter, String file, int line)

	/**
		* Set a breakpoint at specied source-file/line combination
		*/

	public SetBreakpointCmd(GdbAdapter adapter, String file, int line)
	{
		super(adapter);
		this.file   = file;
		this.linenr = line;
	}

	//}
	//{ public void initPatterns()

	public void initPatterns(PatternCompiler comp)
		throws MalformedPatternException
	{
		super.initPatterns(comp);
		breakPattern = comp.compile("Breakpoint ([0-9]+) at 0x[0-9a-f]+: " +
																"file ([a-zA-Z\\.]+), line ([0-9]+)\\.");
	}

	//}
	//{ public String command()

	/**
		* Issue the actual command
		*/

	public String command()
	{
		if(method != null)
			return "break " + method + "\n";
		else {
			File f = new File(file);
			return "break " + f.getName() + ":" + linenr + "\n";
		}
	}

	//}
	//{ public boolean response(String line)

	/**
		* Handle response lines
		*/

	public boolean response(String line)
	{
		if(matcher.matches(line, breakPattern)) {
			MatchResult result = matcher.getMatch();
			breakpoint = Integer.parseInt(result.group(1));
			file       = result.group(2);
			linenr     = Integer.parseInt(result.group(3));
			return true;
		} else {
			System.out.println("line '" + line + 
												 "' does not match with break pattern");
			return false;
		}
	}

	//}

	//{ public int getBreakpoint()

	/**
		* Retrieve the actual breakpoint number associated with this command
		*/

	public int getBreakpoint()
	{
		return breakpoint;
	}

	//}
	//{ public String getFileName()

	/**
		* Retrieve the filename of the breakpoint
		*/

	public String getFileName()
	{
		return file;
	}

	//}
	//{ public int getLineNr()

	/**
		* Retrieve the line nr of this breakpoint
		*/

	public int getLineNr()
	{
		return linenr;
	}

	//}
}
