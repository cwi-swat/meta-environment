package tide.tools;

import javax.swing.*;

abstract public class TideTool
  extends JInternalFrame
{
	public TideTool(String title, boolean resizeable, boolean closable,
									boolean maximizable, boolean iconifiable) {
		super(title, resizeable, closable, maximizable, iconifiable);
	}

	abstract public String getName();
	abstract public void cleanup();
}
