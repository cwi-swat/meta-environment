package tide.tools.ruleviewer;

import tide.tools.*;
import tide.debug.*;

import aterm.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

public class RuleViewer
  extends TideTool
  implements RuleListener, ActionListener, 
						 ListSelectionListener, ChangeListener
{
	DebugProcess process;

	DefaultListModel rules;
	JList ruleList;
	JCheckBox enabled;
	JLabel type;
	JLabel port;
	JLabel condition;
	JTextArea action;

	JButton edit;
	JButton add;
	JButton del;

	TitledBorder ruleBorder;
	boolean selectionChanging = false;
	boolean changeGuard       = false;

	//{ public RuleViewer(DebugProcess process)

	/**
		* Construct a new RuleViewer
		*/

	public RuleViewer(DebugProcess process)
	{
		super("Rule Viewer: " + process.getID(), true, true, true, true);
		setSize(500, 350);

		this.process = process;

		//{ Create UI components

		add       = new JButton("Add");
		edit      = new JButton("Edit");
		del       = new JButton("Delete");
		
		rules     = new DefaultListModel();
		ruleList  = new JList(rules);
		enabled   = new JCheckBox("enabled");
		type      = new JLabel();
		port      = new JLabel();
		condition = new JLabel();
		action    = new JTextArea();

		action.setEditable(false);
		edit.setEnabled(false);
		del.setEnabled(false);
		enabled.setEnabled(false);

		ruleList.addListSelectionListener(this);
		enabled.addChangeListener(this);

		add.addActionListener(this);
		edit.addActionListener(this);
		del.addActionListener(this);

		type.setOpaque(true);
		type.setForeground(Color.black);
		type.setBackground(Color.white);
		port.setOpaque(true);
		port.setForeground(Color.black);
		port.setBackground(Color.white);
		condition.setOpaque(true);
		condition.setForeground(Color.black);
		condition.setBackground(Color.white);

		//}
		//{ Construct user interface

		Container container = getContentPane();

		container.setLayout(new BorderLayout());
		
		ruleList.setPreferredSize(new Dimension(46, 80));

		JPanel left   = new JPanel();
		JPanel center = new JPanel();
		JPanel top    = new JPanel();

		left.setBorder(new TitledBorder(new LineBorder(Color.darkGray), "Rules"));
		ruleBorder = new TitledBorder(new LineBorder(Color.darkGray), "Rule: <none>");
		center.setBorder(ruleBorder);

		JPanel buttons = new JPanel();
		buttons.setLayout(new GridLayout(1,3));
		buttons.add(add);
		buttons.add(edit);
		buttons.add(del);

		left.setLayout(new BorderLayout());
		left.add(ruleList, BorderLayout.CENTER);
		
		center.setLayout(new BorderLayout());
		top.setLayout(new GridBagLayout());

		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;

		c.gridx = 0;
		c.gridy = 0;

		top.add(new JLabel("Type:"), c);
		c.gridy++;
		top.add(new JLabel("Port:"), c);
		c.gridy++;
		top.add(new JLabel("Cond:"), c);
		c.gridy++;
		top.add(new JLabel("Acts:"), c);

		c.gridy = 0;
		c.gridx++;
		c.weightx = 1.0;

		top.add(type, c);
		c.gridy++;
		top.add(port, c);
		c.gridy++;
		top.add(condition, c);
		c.gridy++;
		c.anchor = GridBagConstraints.EAST;
		c.fill = GridBagConstraints.NONE;
		top.add(enabled, c);

		center.add(top,    BorderLayout.NORTH);
		center.add(action, BorderLayout.CENTER);

		container.add(left, BorderLayout.WEST);
		container.add(center, BorderLayout.CENTER);
		container.add(buttons, BorderLayout.SOUTH);

		//}

		Iterator iter = process.getRules();
		while(iter.hasNext()) {
			Rule rule = (Rule)iter.next();
			rules.addElement(rule);
		}

		process.addRuleListener(this);
	}

	//}
	//{ public String getName()

	/**
		* Retrieve the name of this tool
		*/

	public String getName()
	{
		return "ruleviewer(" + process.getID() + ")";
	}

	//}
	//{ public void cleanup()

	/**
		* The RuleViewer does not remove created rules when destroyed!
		*/

	public void cleanup()
	{
	}

	//}
	//{ public String toString()

	/**
		* Retrieve a string representation of this tool
		*/

	public String toString()
	{
		return getName();
	}

	//}

	//{ Rule getSelectedRule()

	/**
		* Retrieve the currently selected rule
		*/

	Rule getSelectedRule()
	{
		return (Rule)ruleList.getSelectedValue();
	}

	//}
	//{ void ruleSelected(Rule rule)

	/**
		* Show the currently selected rule
		*/

	void ruleSelected(Rule rule)
	{
		selectionChanging = true;

		if(rule == null) {
			ruleBorder.setTitle("Rule: <none>");
			type.setText("");
			port.setText("");
			condition.setText("");
			action.setText("");
			enabled.setSelected(false);
			enabled.setEnabled(false);
			repaint();
		} else {
			ruleBorder.setTitle("Rule: " + rule.getID());
			type.setText(rule.getType());
			port.setText(rule.getPort().toString());
			condition.setText(rule.getCondition().toString());

			action.setText(rule.getAction().toString());
			
			enabled.setEnabled(true);
			enabled.setSelected(rule.isEnabled());
			repaint();
		}

		changeGuard = false;
		selectionChanging = false;
	}

	//}

	//{ public void ruleCreated(Rule rule)

	/**
		* A new rule has been created
		*/

	public void ruleCreated(Rule rule)
	{
		rules.addElement(rule);
	}

	//}
	//{ public void ruleDeleted(Rule rule)

	/**
		* An existing rule has been removed
		*/

	public void ruleDeleted(Rule rule)
	{
		rules.removeElement(rule);
	}

	//}
	//{ public void ruleModified(Rule rule)

	/**
		* A rule has been modified
		*/

	public void ruleModified(Rule rule)
	{
		Rule selected = getSelectedRule();
		if(selected == rule)
			ruleSelected(rule);
	}

	//}
	//{ public void ruleEnablingChanged(Rule rule)

	/**
		* The enabled status of a rule has changed
		*/
	
	public void ruleEnablingChanged(Rule rule)
	{
		if(rule == getSelectedRule()) {
			enabled.setSelected(rule.isEnabled());
			changeGuard = false;
		}
	}

	//}
	//{ public void evaluated(String type, DebugAction act, Value val)

	/**
		* An expression has been evaluated
		*/

	public void evaluated(String type, DebugAction act, Value val)
	{
	}

	//}

	//{ private boolean editRule(Rule rule)

	/**
		* Edit a rule
		*/

	private boolean editRule(Rule rule, String title)
	{
		while(true) {
			//{ Build UI

			Port port        = rule.getPort();
			Condition cond   = rule.getCondition();
			DebugAction acts = rule.getAction();

			JTextField portField = new JTextField();
			JTextField condField = new JTextField();
			JTextArea  actsArea  = new JTextArea();

			if(port != null)
				portField.setText(port.toString());

			if(cond != null)
				condField.setText(cond.toString());

			if(acts != null)
				actsArea.setText(acts.toString());

			JPanel panel = new JPanel();
			panel.setLayout(new GridBagLayout());
			GridBagConstraints c = new GridBagConstraints();
			c.fill = GridBagConstraints.BOTH;
			
			c.gridx = 0;
			c.gridy = 0;
			
			panel.add(new JLabel("Port:"), c);
			c.gridy++;
			panel.add(new JLabel("Cond:"), c);
			c.gridy++;
			panel.add(new JLabel("Acts:"), c);
			
			c.gridy = 0;
			c.gridx++;
			c.weightx = 1.0;
			panel.add(portField, c);
			c.gridy++;
			panel.add(condField, c);

			c.gridx = 0;
			c.gridy += 2;
			c.gridwidth = 2;
			actsArea.setPreferredSize(new Dimension(120, 60));

			panel.add(actsArea, c);

			//}
			//{ Show dialog

			int result = JOptionPane.showInternalConfirmDialog(this, panel, title, 
									JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

			//}
			//{ Parse port, condition, and action

			if(result == JOptionPane.OK_OPTION) {
				try {
					port = PortFactory.parse(portField.getText());
					cond = ConditionFactory.parse(condField.getText());
					acts = DebugActionFactory.parse(actsArea.getText());
					rule.modify(port, cond, acts);
				
					return true;
				} catch (ParseError e) {
					JOptionPane.showMessageDialog(this, "Parse error: "+e.getMessage(),
	  																"Parse Error", JOptionPane.ERROR_MESSAGE);
				}
			} else {
				return false;
			}

			//}
		}
	}

	//}

	//{ public void actionPerformed(ActionEvent evt)

	/**
		* The user might have pressed a button
		*/

	public void actionPerformed(ActionEvent evt)
	{
		if(evt.getSource() == add) {
			Rule rule = new Rule("rule-viewer(manual)");
			if(editRule(rule, "Add a new rule")) {
				System.out.println("adding a new rule.");
				process.requestRuleCreation(rule.getType(), rule.getPort(), 
																		rule.getCondition(), rule.getAction());
			} else {
				System.out.println("adding canceled");
			}
		} else if(evt.getSource() == del) {
			process.requestRuleDeletion(getSelectedRule());
		} else if(evt.getSource() == edit) {
			Rule selected = getSelectedRule();
			if(selected != null) {
				Rule rule = (Rule)selected.clone();
				if(editRule(rule, "Edit rule " + rule.getID())) {
					process.requestRuleModification(selected, rule.getPort(),
																					rule.getCondition(), rule.getAction());
				}
			}
		}
	}

	//}
	//{ public void valueChanged(ListSelectionEvent evt)

	public void valueChanged(ListSelectionEvent evt)
	{
		if(evt.getSource() == ruleList) {
			Rule selected = getSelectedRule();
			ruleSelected(selected);
			if(selected == null) {
				edit.setEnabled(false);
				del.setEnabled(false);
			} else {
				edit.setEnabled(true);
				del.setEnabled(true);
			}
		}
	}

	//}
	//{ public void stateChanged(ChangeEvent evt)

	/**
		* The state has changed
		*/

	public void stateChanged(ChangeEvent evt)
	{
		if(evt.getSource() == enabled) {
			Rule rule = getSelectedRule();
			if(!selectionChanging) {
				if(rule != null && rule.isEnabled() != enabled.isSelected() &&
					 !changeGuard) {
					process.requestRuleEnabling(rule, enabled.isSelected());
					changeGuard = true;
				}
			}
		}
	}

	//}
}
