package tide.tools;

//{ imports

import tide.debug.*;
import tide.config.*;
import tide.toolbus.DebugAdapter;
import tide.adapter.*;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

//}

public class ProcessList
	extends JPanel
  implements ProcessListener, RuleListener, WatchpointListener,
						 TreeSelectionListener
{
	private final static String TYPE_STEP      = "process-list(step)";
	private final static String TYPE_STEP_OVER = "process-list(step-over)";
	private final static String TYPE_RESUME    = "process-list(resume)";
	private final static String TYPE_BREAK     = "process-list(break)";
	private final static String TYPE_STOPPED   = "process-list(stopped)";
	private final static String TYPE_STARTED   = "process-list(started)";

	Map stepIntoRules;
	Map stepOverRules;
	DefaultTreeModel processes;

	DebugAction resumeAction;
	DebugAction breakAction;

	JTree procTree;
	DebugInterface debugInterface;
	ProcessAction breakAct;
	ProcessAction stepInto;
	ProcessAction stepOver;
	ProcessAction run;

	//{ class ProcessAction extends AbstractAction

	class ProcessAction extends AbstractAction
	{
		String act;
		ProcessList list;

		public ProcessAction(ProcessList list, String act, Icon icon)
		{
			super(act, icon);
			this.act = act;
			this.list = list;
		}

		public void actionPerformed(ActionEvent evt)
		{
			list.processAction(this, act);
		}
	}

	//}

	//{ public ProcessList(DebugInterface dbgInterface)

	/**
		* Construct a new process list
		*/

	public ProcessList(DebugInterface iface)
	{
		stepIntoRules = new HashMap();
		stepOverRules = new HashMap();

		resumeAction = DebugActionFactory.parse("resume");
		breakAction  = DebugActionFactory.parse("break");

		debugInterface = iface;
		debugInterface.addProcessListener(this);		

		processes = new DefaultTreeModel(debugInterface.getRoot());
		procTree = new JTree(processes);
		procTree.addTreeSelectionListener(this);

		procTree.setPreferredSize(new Dimension(180, 50));

		//{ Add process tools

		JToolBar processTools = new JToolBar();
		
		breakAct = new ProcessAction(this, "Break", 
																 new ImageIcon("images/break.gif"));
		processTools.add(breakAct).setText(null);
		
		stepInto = new ProcessAction(this, "Step Into",
																 new ImageIcon("images/step-in.gif"));
		processTools.add(stepInto).setText(null);
		
		stepOver = new ProcessAction(this, "Step Over",
																 new ImageIcon("images/step-over.gif"));
		processTools.add(stepOver).setText(null);
		
		run = new ProcessAction(this, "Run", 
														new ImageIcon("images/run.gif"));
		processTools.add(run).setText(null);

		//}

		setLayout(new BorderLayout());
		add(processTools, "North");
		add(procTree, "Center");		
	}

	//}

	//{ public DebugProcess getSelectedProcess()

	/**
		* Retrieve the currently selected process
		*/

	public DebugProcess getSelectedProcess()
	{
		TreePath path = procTree.getSelectionPath();
		if(path != null) {
			DebugProcessGroup last = (DebugProcessGroup)path.getLastPathComponent();
			if(last instanceof DebugProcess)
				return (DebugProcess)last;
		}

		return null;
	}

	//}
	//{ public DebugAdapter getSelectedAdapter()

	/**
		* Retrieve the currently selected debug adapter
		*/

	public DebugAdapter getSelectedAdapter()
	{
		TreePath path = procTree.getSelectionPath();
		if(path != null) {
			DebugProcessGroup last = (DebugProcessGroup)path.getLastPathComponent();
			if(last instanceof DebugAdapter)
				return (DebugAdapter)last;
			path = path.getParentPath();
			if(path != null) {
				last = (DebugProcessGroup)path.getLastPathComponent();
				if(last instanceof DebugAdapter)
					return (DebugAdapter)last;
			}
		}

		return null;
	}

	//}
	//{ public void updateButtons()

	/**
		* Update the buttons
		*/

	public void updateButtons()
	{
		DebugProcess sel = getSelectedProcess();
		if(sel == null) {	
			breakAct.setEnabled(false);
			stepInto.setEnabled(false);
			stepOver.setEnabled(false);
			run.setEnabled(false);
		} else if(sel.getState() == DebugProcess.STATE_STOPPED) {
			breakAct.setEnabled(false);
			stepInto.setEnabled(true);
			stepOver.setEnabled(true);
			run.setEnabled(true);
		} else {
			// Must be running!
			breakAct.setEnabled(true);
			stepInto.setEnabled(false);
			stepOver.setEnabled(false);
			run.setEnabled(false);
		}
	}

	//}
	
	//{ public void valueChanged(TreeSelectionEvent evt)

	/**
		* The current selection in the tree has changed
		*/

	public void valueChanged(TreeSelectionEvent evt)
	{
		updateButtons();
	}

	//}
	//{ void processAction(ProcessAction action, String act)

	/**
		* Execute an action
		*/

	void processAction(ProcessAction action, String act)
	{
		DebugProcess process = getSelectedProcess();
		if(process != null) {
			if(action == breakAct) {
				process.requestEvaluation(TYPE_BREAK, breakAction);
			} else if(action == stepInto) {
				Rule rule = (Rule)stepIntoRules.get(process);
				rule.requestEnabling(true);
				process.requestEvaluation(TYPE_RESUME, resumeAction);
			} else if(action == stepOver) {
				Rule rule = (Rule)stepOverRules.get(process);
				rule.requestEnabling(true);
				process.requestEvaluation(TYPE_RESUME, resumeAction);
			} else if(action == run) {
				process.requestEvaluation(TYPE_RESUME, resumeAction);
			}
		}
	}

	//}

	//{ public void processCreated(DebugProcess process, DebugProcessGroup parent)

	public void processCreated(DebugProcess process, DebugProcessGroup parent)
	{
		Port port;
		Condition cond;
		DebugAction acts;

		System.out.println("ProcessList: processCreated: " + process);
		processes.insertNodeInto(process, parent, parent.getChildCount());
		TreeNode[] treeNodes = processes.getPathToRoot(process);
		TreePath path = new TreePath(treeNodes);
		procTree.makeVisible(path);
		procTree.setSelectionPath(path);

		process.addRuleListener(this);

		port = PortFactory.parse("step");
		cond = ConditionFactory.parse("true");
		acts = DebugActionFactory.parse("[break,disable]");
		process.requestRuleCreation(TYPE_STEP, port, cond, acts);

		cond = ConditionFactory.parse("higher-equal(start-level,stack-level)");
		process.requestRuleCreation(TYPE_STEP_OVER, port, cond, acts);

		port = PortFactory.parse("stopped");
		cond = ConditionFactory.parse("true");
		acts = DebugActionFactory.parse("state");
		process.requestRuleCreation(TYPE_STOPPED, port, cond, acts);

		port = PortFactory.parse("started");
		process.requestRuleCreation(TYPE_STARTED, port, cond, acts);
	}

	//}
	//{ public void processDestroyed(DebugProcess process)

	public void processDestroyed(DebugProcess process)
	{
		processes.removeNodeFromParent(process);

		stepIntoRules.remove(process);
		stepOverRules.remove(process);
	}

	//}
	//{ public void processGroupCreated(DebugProcessGroup group, parent)

	public void processGroupCreated(DebugProcessGroup group, DebugProcessGroup parent)
	{
		System.out.println("processGroupCreated: " + group);
		processes.insertNodeInto(group, parent, parent.getChildCount());
	}

	//}
	//{ public void processGroupDestroyed(DebugProcessGroup group)

	public void processGroupDestroyed(DebugProcessGroup group)
	{
		processes.removeNodeFromParent(group);
	}

	//}
	//{ public void processStarted(DebugProcess process)

	/**
		* A process has been started
		*/

	public void processStarted(DebugProcess process)
	{
		process.setState(DebugProcess.STATE_RUNNING);
		if(process == getSelectedProcess())
			updateButtons();
	}

	//}
	//{ public void processStopped(DebugProcess process)

	/**
		* A process has been stopped
		*/

	public void processStopped(DebugProcess process)
	{
		process.setState(DebugProcess.STATE_STOPPED);
		if(process == getSelectedProcess())
			updateButtons();
	}

	//}

	//{ public void ruleCreated(Rule rule)

	/**
		* A new rule has been created
		*/

	public void ruleCreated(Rule rule)
	{
		if(rule.getType().equals(TYPE_STEP)) {
			stepIntoRules.put(rule.getProcess(), rule);
			rule.addWatchpointListener(this);
		} else if(rule.getType().equals(TYPE_STEP_OVER)) {
			stepOverRules.put(rule.getProcess(), rule);
			rule.addWatchpointListener(this);
		} else if(rule.getType().equals(TYPE_STOPPED)) {
			rule.requestEnabling(true);
			rule.addWatchpointListener(this);
		} else if(rule.getType().equals(TYPE_STARTED)) {
			rule.requestEnabling(true);
			rule.addWatchpointListener(this);
		}
	}

	//}
	//{ public void ruleDeleted(Rule rule)

	/**
		* An existing rule has been removed
		*/

	public void ruleDeleted(Rule rule)
	{
	}

	//}
	//{ public void ruleModified(Rule rule)

	/**
		* A rule has been modified
		*/

	public void ruleModified(Rule rule)
	{
	}

	//}
	//{ public void ruleEnablingChanged(Rule rule)

	/**
		* The enabled status of a rule has changed
		*/
	
	public void ruleEnablingChanged(Rule rule)
	{
	}

	//}
	//{ public void evaluated(String type, DebugAction act, Value value)

	public void evaluated(String type, DebugAction act, Value value)
	{
	}

	//}

	//{ public void watchpoint(Rule rule, Value value)

	/**
		* A watchpoint was triggered
		*/

	public void watchpoint(Rule rule, Value value)
	{
		System.out.println("watchpoint: " + rule.getType());
		if(rule.getType().equals(TYPE_STEP)) {
			System.out.println("*** disabling STEP_INTO rule.");
			rule.requestEnabling(false);
		} else if(rule.getType().equals(TYPE_STEP_OVER)) {
			System.out.println("*** disabling STEP_OVER rule.");
			rule.requestEnabling(false);
		} else if(rule.getType().equals(TYPE_STOPPED)) {
			processStopped(rule.getProcess());
		} else if(rule.getType().equals(TYPE_STARTED)) {
			processStarted(rule.getProcess());
		} else {
			System.out.println("*** not a step rule: " + rule);
		}
	}

	//}	
}
