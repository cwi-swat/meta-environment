package tide.tools;

import tide.config.*;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;
import javax.swing.event.*;

public class SearchPathEditor
  extends TideTool
  implements ActionListener, PropertyChangeListener, ListSelectionListener
{
	String category;
	TideConfig config;

	JList paths;
	DefaultListModel pathModel;
	JButton add;
	JButton del;

	//{ public SearchPathEditor(TideConfig config, String cat)

	/**
		* Construct a new SourcePathEditor
		*/

	public SearchPathEditor(TideConfig config, String cat)
	{
		super("Paths: " + cat, true, true, true, true);
		setSize(400, 160);

		this.config = config;
		this.category = cat;
		config.addPropertyChangeListener(cat + ".paths", this);

		pathModel = new DefaultListModel();
		paths = new JList(pathModel);
		add = new JButton("Add");
		del = new JButton("Delete");

		paths.addListSelectionListener(this);
		add.addActionListener(this);
		del.addActionListener(this);
		del.setEnabled(false);

		JPanel buttons = new JPanel();
		buttons.setLayout(new GridLayout(1,2));
		buttons.add(add);
		buttons.add(del);

		Container content = getContentPane();
		content.setLayout(new BorderLayout());
		content.add(paths, BorderLayout.CENTER);
		content.add(buttons, BorderLayout.SOUTH);
		
		updatePaths();
	}

	//}
	//{ void updatePaths()

	/**
		* Update the list of paths
		*/

	public void updatePaths()
	{
		pathModel.removeAllElements();
		java.util.List list = config.getSearchPaths(category);
		Iterator iter = list.iterator();
		while(iter.hasNext())
			pathModel.addElement(iter.next());
	}

	//}

	//{ public String getName()

	/**
		* Retrieve the name of this tool
		*/

	public String getName()
	{
		return "searchpath-editor(" + category + ")";
	}

	//}
	//{ public void cleanup()

	/**
		* Remove all rules created by this tool
		*/

	public void cleanup()
	{
	}

	//}
	//{ public void actionPerformed(ActionEvent evt)

	/**
		* The user probably pressed on of the buttons
		*/

	public void actionPerformed(ActionEvent evt)
	{
		if(evt.getSource() == add) {
			JFileChooser chooser = new JFileChooser();
			chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			int option = chooser.showDialog(this, "Add Path");
			if(option == JFileChooser.APPROVE_OPTION) {
				String path = chooser.getSelectedFile().getPath();
				if(path != null)
					config.addSearchPath(category, path);
			}
		} else if(evt.getSource() == del) {
			String path = (String)paths.getSelectedValue();
			config.removeSearchPath(category, path);
		}
	}

	//}
	//{ public void valueChanged(ListSelectionEvent evt)

	/**
		* The user selected a list item
		*/

	public void valueChanged(ListSelectionEvent evt)
	{
		del.setEnabled(paths.getSelectedIndex() >= 0);
	}

	//}
	//{ public void propertyChange(PropertyChangeEvent evt)

	/**
		* Handle property changes
		*/

	public void propertyChange(PropertyChangeEvent evt)
	{
		String prop = evt.getPropertyName();
		if(prop == null || prop.equals(category + ".paths"))
			updatePaths();
	}

	//}
}
