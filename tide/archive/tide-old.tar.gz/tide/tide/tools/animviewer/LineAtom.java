package tide.tools.animviewer;
/**
 *
 * @author Hayco de Jong
 *
 */


import java.awt.*;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import javax.swing.*;

public class LineAtom extends AbstractAtom
{
	public static final String END_X = "LINE_END_X";
	public static final String END_Y = "LINE_END_Y";
	public static final String COLOR = "LINE_COLOR";

	private Line2D line;

	private int endX;
	private int endY;

	public LineAtom()
	{
		this(0, 0, 0, 0);
	}
	
	public LineAtom(int x, int y)
	{
		this(x, y, 0, 0);
	}
	
	public LineAtom(int x1, int y1, int x2, int y2)
	{
		super(x1, y1);
		endX = x2;
		endY = y2;
	}
	
	public int getEndX()
	{
		return endX;
	}
	
	public int getEndY()
	{
		return endY;
	}
	
	public void draw(Graphics2D g2d, JComponent component, Color color)
	{
		super.draw(g2d, component, color);

		if (line == null)
			line = new Line2D.Double();

		line.setLine(getX(), getY(), endX, endY);

		// Orthogonality - test for solidness, even though filling
	   	// a line yields an (infinitely thin?) invisible object.
		if (isSolid())
			g2d.fill(line);
		else
			g2d.draw(line);
	}

	public String toString()
	{
		return "LineAtom[X="+getX()+",Y="+getY()+
			",endX="+endX+",endY="+endY+"]";
	}

	public Object getAnimProperty(String propertyName)
	{
		if (propertyName.equals(END_X))
			return new Double(endX);

		if (propertyName.equals(END_Y))
			return new Double(endY);

		throw new IllegalArgumentException("unknown property: "+ propertyName);
	}

	public void setAnimProperty(String propertyName, Object newValue)
	{
		if (propertyName.equals(END_X) && newValue instanceof Number)
		{
			int oldValue = endX;
			endX = ((Number)newValue).intValue();
			firePropertyChange(propertyName, oldValue, endX);
		}
		else if (propertyName.equals(END_Y) && newValue instanceof Number)
		{
			int oldValue = endY;
			endY = ((Number)newValue).intValue();
			firePropertyChange(propertyName, oldValue, endY);
		}
		else
		{
			String msg = "illegal property/value for line: " +
				"name="+propertyName+", value="+newValue;
			throw new IllegalArgumentException(msg);
		}
	}
}

// vim:ts=4:sw=4
