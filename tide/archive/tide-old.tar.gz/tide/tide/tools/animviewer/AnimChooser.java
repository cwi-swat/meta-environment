/**
 *
 * @author Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports

import tide.tools.*;
import tide.debug.*;
import tide.config.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

//}

public class AnimChooser
	extends TideTool
	implements ActionListener, InternalFrameListener, RuleListener
{
	//{ Private fields.
	
	private final static String TYPE_VISUALIZE = "visualize(expr)";
	private List rules;

	//}
	//{ Public fields.

	public static final Dimension hpad5 = new Dimension(5,1);
	public static final Dimension hpad10 = new Dimension(10,1);
	public static final Dimension hpad20 = new Dimension(20,1);
	public static final Dimension hpad25 = new Dimension(25,1);
	public static final Dimension hpad30 = new Dimension(30,1);
	public static final Dimension hpad40 = new Dimension(40,1);
	public static final Dimension hpad80 = new Dimension(80,1);

	public static final Dimension vpad5 = new Dimension(1,5);
	public static final Dimension vpad10 = new Dimension(1,10);
	public static final Dimension vpad20 = new Dimension(1,20);
	public static final Dimension vpad25 = new Dimension(1,25);
	public static final Dimension vpad30 = new Dimension(1,30);
	public static final Dimension vpad40 = new Dimension(1,40);
	public static final Dimension vpad80 = new Dimension(1,80);
	
	public static final Insets insets0 = new Insets(0,0,0,0);
	public static final Insets insets5 = new Insets(5,5,5,5);
	public static final Insets insets10 = new Insets(10,10,10,10);
	public static final Insets insets15 = new Insets(15,15,15,15);
	public static final Insets insets20 = new Insets(20,20,20,20);

	public static final Border emptyBorder0 = new EmptyBorder(0,0,0,0);
	public static final Border emptyBorder5 = new EmptyBorder(5,5,5,5);
	public static final Border emptyBorder10 = new EmptyBorder(10,10,10,10);
	public static final Border emptyBorder15 = new EmptyBorder(15,15,15,15);
	public static final Border emptyBorder20 = new EmptyBorder(20,20,20,20);
	
	public static final Border etchedBorder10 =
		new CompoundBorder(new EtchedBorder(), emptyBorder10);

	public static final Border loweredBorder =
		new SoftBevelBorder(BevelBorder.LOWERED);
	
	/**
	  * The process this chooser will select an visualization for.
	  * @serial
	  */
	private DebugProcess process;

	/**
	  * The names of the available visualization templates.
	  *
	  * @serial
	  */
	private String[] visualizationTemplates =
	{
		"Generic", "Counter", "String", "ATerm"
	};
	
	/**
	 * @serial
	 */
	private JInternalFrame frame;

	/**
	 * @serial
	 */
	private JTextField exprField;
	
	/**
	 * @serial
	 */
	private JComboBox templateSelector;
	
	/**
	 * @serial
	 */
	private JButton ok;
	
	//}
	
	public static JPanel createHorizontalPanel(boolean threeD)
	{
		JPanel p = new JPanel();
		p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
		if (threeD) {
			p.setBorder(loweredBorder);
		}
		return p;
	}
	
	public static JPanel createVerticalPanel(boolean threeD)
	{
		JPanel p = new JPanel();
		p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
		if (threeD) {
			p.setBorder(loweredBorder);
		}
		return p;
	}

	public AnimChooser(DebugProcess proc)
	{
		super("Expression Visualizer: " + proc.getID(), true, true, true, true);
		setSize(500, 350);

		rules   = new LinkedList();
		process = proc;
		process.addRuleListener(this);
		frame.addInternalFrameListener(this);

		setBorder(emptyBorder5);
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		setOpaque(false);
		
		JPanel[] rows = new JPanel[4];
		rows[0] = createHorizontalPanel(false);
		rows[1] = createHorizontalPanel(false);
		rows[2] = createHorizontalPanel(false);
		rows[3] = createHorizontalPanel(false);
		
		JLabel label = new JLabel("Expr: ");
		label.setHorizontalTextPosition(label.RIGHT);
		label.setDisplayedMnemonic('E');
		label.setToolTipText("Expression to be visualized.");
		exprField = new JTextField("") {
			public Dimension getMaximumSize() {
				return new Dimension(super.getMaximumSize().width,
									 super.getPreferredSize().height);
			}
		};
		label.setLabelFor(exprField);
		rows[0].setBorder(etchedBorder10);
		rows[0].add(label);
		rows[0].add(exprField);
		
		label = new JLabel("Template: ");
		label.setHorizontalTextPosition(label.RIGHT);
		label.setDisplayedMnemonic('T');
		label.setToolTipText("Select template for visualization.");
		templateSelector = new JComboBox(visualizationTemplates);
		label.setLabelFor(templateSelector);
		rows[1].setBorder(etchedBorder10);
		rows[1].add(label);
		rows[1].add(templateSelector);

		ImageIcon previewIcon = new ImageIcon("preview.gif", "Preview");
		if (previewIcon.getIconWidth() > 96) {
			previewIcon = new ImageIcon(
				previewIcon.getImage().getScaledInstance(96, -1,
														 Image.SCALE_DEFAULT));
		}
		JPanel previewPanel = createVerticalPanel(false);
		previewPanel.setBorder(new TitledBorder("Preview"));
		previewPanel.add(new JLabel(previewIcon));

		String text = "" +
			"Sample explanation of a template.\n"+
			"This is where specific notes and\n" +
			"hints about the template should go.";
		JPanel textWrapper = new JPanel(new BorderLayout());
		textWrapper.setAlignmentX(LEFT_ALIGNMENT);

		rows[2].setBorder(etchedBorder10);
		rows[2].add(previewPanel);
		rows[2].add(Box.createRigidArea(hpad10));
		rows[2].add(textWrapper);

		JTextArea textArea = new JTextArea(text);
		textArea.setEditable(false);
		JScrollPane scroller = new JScrollPane() {
			public Dimension getPreferredSize() {
				return new Dimension(300,100);
			}
			public float getAlignmentX() {
				return LEFT_ALIGNMENT;
			}
		};
		scroller.getViewport().add(textArea);
		textWrapper.add(scroller, BorderLayout.CENTER);
		
		ok = new JButton("Ok");
		ok.addActionListener(this);

		rows[3].add(ok);
		rows[3].add(Box.createRigidArea(hpad5));
		
		JPanel contentPanel = createVerticalPanel(true);
		contentPanel.setAlignmentX(LEFT_ALIGNMENT);
		contentPanel.setAlignmentY(TOP_ALIGNMENT);
		
		contentPanel.add(Box.createRigidArea(vpad5));
		for(int i=0; i<4; i++) {
			contentPanel.add(rows[i]);
			contentPanel.add(Box.createRigidArea(vpad5));
		}
		
		getContentPane().add(contentPanel);
	}
	
	//{ Implementation of interface: ActionListener

	public void actionPerformed(ActionEvent evt)
	{
		if (evt.getSource() == ok)
		{
			if (exprField.getText().trim().equals(""))
			{
				JOptionPane.showInternalMessageDialog(frame,
					"Please enter an expression.", "Empty expression",
					JOptionPane.ERROR_MESSAGE);
				return;
			}
			String expr = "eval(\"" + exprField.getText() + "\")";
			Port port = PortFactory.parse("step");
			Condition cond = ConditionFactory.parse("true");
			DebugAction acts = DebugActionFactory.parse(expr);

			process.requestRuleCreation(TYPE_VISUALIZE, port, cond, acts);
		}
	}

	//}
	//{ Implementation of interface: InternalFrameListener

	public void internalFrameClosing(InternalFrameEvent e)
	{
		process.removeRuleListener(this);
	}

	// The following internal frame callbacks are not (yet) needed.
	public void internalFrameActivated(InternalFrameEvent e)   { /* empty */ }
	public void internalFrameClosed(InternalFrameEvent e)      { /* empty */ }
	public void internalFrameDeactivated(InternalFrameEvent e) { /* empty */ }
	public void internalFrameDeiconified(InternalFrameEvent e) { /* empty */ }
	public void internalFrameIconified(InternalFrameEvent e)   { /* empty */ }
	public void internalFrameOpened(InternalFrameEvent e)      { /* empty */ }

	//}
	//{ Implementation of interface: RuleListener
	
	public void ruleCreated(Rule rule)
	{
		if (rule.getType().equals(TYPE_VISUALIZE)) {
			rules.add(rule);
			rule.requestEnabling(true);

			// Now that we have finally the <rule>, we can setup
			// the visualization process.
			String expr = exprField.getText();
			String tmpl = (String)templateSelector.getSelectedItem();
			process.visualize(rule, expr, tmpl);
		}
	}
	
	// The following rule callbacks are not (yet) needed.
	public void ruleDeleted(Rule rule)            { /* empty */ }
	public void ruleModified(Rule rule)           { /* empty */ }
	public void ruleEnablingChanged(Rule rule)    { /* empty */ }
	public void evaluated(String type, DebugAction act, Value val) 
	                                              { /* empty */ }

	//}
	//{ Implementation of interface: TideTool

	public String getName()
	{
		return "expr-visualizer(" + process.getID() + ")";
	}

	//{ public void cleanup()

	/**
		* Remove all rules created by this tool
		*/

	public void cleanup()
	{
		Iterator iter = rules.iterator();
		while(iter.hasNext()) {
			Rule rule = (Rule)iter.next();
			process.requestRuleDeletion(rule);
		}
	}

	//}
	
	//}
}

// vim:ts=4:sw=4
