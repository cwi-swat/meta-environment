/**
 * $Id: ATermCommand.java,v 1.1 1999/09/02 11:35:32 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports.

import aterm.*;

//}

public class ATermCommand
	implements AnimCommand
{
	//{ Private fields.

	/**
	 * ATermAppl representation of an AnimCommand.
	 *
	 * @serial
	 */
	private ATerm command;

	//}

	//{ Constructor(s)
	//{ public ATermCommand(ATerm term)

	public ATermCommand(ATerm term)
	{
		this.command = term;
	}

	//}
	//}
	//{ public String toString()

	public String toString()
	{
		return command.toString();
	}

	//}
	//{ Implementation of interface: AnimCommand
	//{ public ATerm toTerm()

	public ATerm toTerm()
	{
		return command;
	}

	//}
	//}
}

// vim:ts=4:sw=4
