/**
 * $Id: GenericAnimator.java,v 1.1 1999/09/02 11:35:35 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports

import aterm.*;

import tide.debug.*;
import tide.tools.*;

import java.awt.Color;

import java.util.*;

//}

public class GenericAnimator
	implements AnimatorTemplate
{
	//{ Private fields.

	/** Unique ID of each animation object we create. */
	private int animID;

	/** The AnimCommandHandlers interested in our animation commands. */
	private List acHandlers;

	/** The expression this animator is visualizing. */
	private String expr;

	/** The current state this expression is in. */
	private String state;

	/** The current value of the expression. */
	private String value;

	/** The colors used throughout the different states. */
	private Map colorMap;

	/** The ID of the label we use to display the expression and its value. */
	private int labelID;

	//}

	//{ Constructor(s)
	//{ public GenericAnimator(String expr)

	public GenericAnimator(String expr)
	{
		this(expr, null);
	}

	//}
	//{ public GenericAnimator(String expr, AnimCommandHandler acHandler)

	public GenericAnimator(String expr, AnimCommandHandler acHandler)
	{
		//{ Initialize private fields.
		this.animID     = 0;				// first ID to dispense is 0.
		this.acHandlers = null;
		this.expr       = expr;
		this.state      = STATE_UNKNOWN;
		this.value      = null;
		//}

		// If a valid handler was passed, add it to our list.
		if (acHandler != null)
		{
			addAnimCommandHandler(acHandler);
			initAnimator();
		}
	}

	//}
	//}

	//{ public String getState()

	/**
	 * Get the current state of this GenericAnimator.
	 */

	public String getState()
	{
		return state;
	}

	//}

	//{ protected synchronized int dispenseID()

	/**
	 * Internal function to dispense unique ID's.
	 * This way, there is only *one* method that updates animID.
	 */
	protected synchronized final int dispenseID()
	{
		return animID++;
	}

	//}

	//{ protected void fireCommand(AnimCommand cmd)

	/**
	 * Tell acHandlers to execute an animation command.
	 */

	protected void fireCommand(AnimCommand cmd)
	{
		// Early exit if there are no acHandlers.
		if (acHandlers == null)
			return;

		//{ Iterate over all handlers, issuing AnimCommand.
		Iterator iter = acHandlers.iterator();
		while (iter.hasNext())
			((AnimCommandHandler)iter.next()).issueAnimCommand(cmd);
		//}
	}

	//}
	//{ private void registerColors()

	private void registerColors()
	{
		String path = "tide.generic";
		Iterator iter = colorMap.keySet().iterator();
		while (iter.hasNext())
		{
			String key = (String) iter.next();
			Color value = (Color) colorMap.get(key);
			fireCommand(CommandFactory.cmdRegisterColor(path, key, value));
		}
	}

	//}
	//{ protected void initAnimator()

	/**
	 * Initialize the Animator.
	 * This means issuing any creation commands that have to be
	 * executed before updating of the expression is possible.
	 */
	protected void initAnimator()
	{
		fireCommand(CommandFactory.cmdSetConfigPath("tide.generic."+expr));

		//{ Setup the default colors we will be using.
		colorMap = new HashMap();
		colorMap.put(STATE_UNKNOWN, new Color(100, 100, 255));
		colorMap.put(STATE_VALUE,   new Color(  0, 255,   0));
		colorMap.put(STATE_ERROR,   new Color(255,   0,   0));
		registerColors();
		//}

		//{ Setup X- and Y-ranges.
		fireCommand(CommandFactory.cmdRangeX(0, 500));
		fireCommand(CommandFactory.cmdRangeY(0,  30));
		//}

		//{ Setup label to display the expression and value.
		labelID = dispenseID();
		fireCommand(CommandFactory.cmdCreate(labelID, "ATOM_TEXT"));
		fireCommand(CommandFactory.cmdSetLocation(labelID, 10, 20));
		fireCommand(CommandFactory.cmdSetColor(labelID, STATE_UNKNOWN));
		fireCommand(CommandFactory.cmdSetProperty(labelID,
					TextAtom.MESSAGE, expr + ": <unknown>"));
		fireCommand(CommandFactory.cmdSetVisible(labelID, true));
		//}

		fireCommand(CommandFactory.cmdRepaint());

		// Done with initialization, state of expr is unknown.
		state = STATE_UNKNOWN;
	}

	//}

	//{ Implementation of interface: AnimatorTemplate

	//{ public void setValue(String newValue)

	/**
	 *
	 */
	public void setValue(String newValue)
	{
		boolean needRepaint = false;

		if (state != STATE_VALUE)
		{
			state = STATE_VALUE;
			fireCommand(CommandFactory.cmdSetColor(labelID, STATE_VALUE));
			needRepaint = true;
		}

		if (newValue != value)
		{
			value = newValue;
			fireCommand(CommandFactory.cmdSetProperty(
						labelID, TextAtom.MESSAGE, expr + ": " + value));
			needRepaint = true;
		}

		if (needRepaint)
			fireCommand(CommandFactory.cmdRepaint());
	}

	//}
	//{ public void setError(String newValue)

	/**
	 *
	 */
	public void setError(String newValue)
	{
		boolean needRepaint = false;

		if (state != STATE_ERROR)
		{
			state = STATE_ERROR;
			fireCommand(CommandFactory.cmdSetColor(labelID, STATE_ERROR));
			needRepaint = true;
		}

		if (newValue != value)
		{
			value = newValue;
			fireCommand(CommandFactory.cmdSetProperty(
						labelID, TextAtom.MESSAGE, expr + ": " + value));
			needRepaint = true;
		}

		if (needRepaint)
			fireCommand(CommandFactory.cmdRepaint());
	}

	//}
	//{ public void addAnimCommandHandler(AnimCommandHandler handler)

	/**
	 * Add an AnimCommandHandler.
	 * @param handler the handler to be added.
	 * @exception NullPointerException when <code>handler</code> is null.
	 */
	public void addAnimCommandHandler(AnimCommandHandler handler)
	{
		// We don't deal with invalid handlers.
		if (handler == null)
			throw new NullPointerException(
				"addAnimCommandHandler got null handler");

		// If there are no acHandlers yet, create a new Vector.
		if (acHandlers == null)
			acHandlers = new Vector();

		// Add the handler to our administration.
		acHandlers.add(handler);
	}

	//}
	//{ public void removeAnimCommandHandler(AnimCommandHandler handler)

	/**
	 * Remove an AnimCommandHandler.
	 * @param handler the handler to be removed.
	 * @exception NullPointerException when <code>handler</code> is null.
	 */

	public void removeAnimCommandHandler(AnimCommandHandler handler)
	{
		// We don't deal with invalid handlers.
		if (handler == null)
			throw new NullPointerException(
				"removeAnimCommandHandler got null handler");

		// Early exit if there are no acHandlers.
		if (acHandlers == null)
			return;

		// Remove the handler from our administration.
		acHandlers.remove(handler);

		// If no handlers remain, remove reference to the vector.
		if (acHandlers.isEmpty())
			acHandlers = null;
	}

	//}

	//}
}

// vim:ts=4:sw=4
