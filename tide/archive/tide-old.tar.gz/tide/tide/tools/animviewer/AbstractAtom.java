package tide.tools.animviewer;

import java.awt.Color;
import java.awt.Graphics2D;

import java.awt.geom.Rectangle2D;

import java.beans.*;

import javax.swing.*;

public abstract class AbstractAtom
	implements AnimAtom
{
	private int X;
	private int Y;
	
	private boolean isSolid;
	private boolean isVisible;
	
	private String colorKey;
	
	private PropertyChangeSupport pcs = new PropertyChangeSupport(this);

	public AbstractAtom()
	{
		this(0, 0);
	}

	public AbstractAtom(int x, int y)
	{
		setLocation(x, y);
		setSolid(false);
		setVisible(false);
	}

	public void setLocation(int x, int y)
	{
		X = x;
		Y = y;
	}
	
	public int getX()
	{
		return X;
	}
	
	public int getY()
	{
		return Y;
	}
	
	public void setColorKey(String key)
	{
		colorKey = key;
	}
	
	public String getColorKey()
	{
		return colorKey;
	}
	
	public void draw(Graphics2D g2d, JComponent c, Color color)
	{
		g2d.setColor(color);
	}
	
	public boolean isSolid()
	{
		return isSolid;
	}
	
	public void setSolid(boolean isSolid)
	{
		this.isSolid = isSolid;
	}

	public boolean isVisible()
	{
		return isVisible;
	}
	
	public void setVisible(boolean isVisible)
	{
		this.isVisible = isVisible;
	}

	public Rectangle2D getBounds(Graphics2D g2d)
	{
		return new Rectangle2D.Double((double)getX(), (double)getY(), 0.0, 0.0);
	}
	
	protected void addPropertyChangeListener(PropertyChangeListener listener)
	{
		pcs.addPropertyChangeListener(listener);
	}
	
	protected void addPropertyChangeListener(String propertyName,
										  PropertyChangeListener listener)
	{
		pcs.addPropertyChangeListener(propertyName, listener);
	}
	
	protected void removePropertyChangeListener(PropertyChangeListener listener)
	{
		pcs.removePropertyChangeListener(listener);
	}
	
	protected void removePropertyChangeListener(String propertyName,
											 PropertyChangeListener listener)
	{
		pcs.removePropertyChangeListener(propertyName, listener);
	}
	
	protected void firePropertyChange(String propertyName,
								   Object oldValue,
								   Object newValue)
	{
		pcs.firePropertyChange(propertyName, oldValue, newValue);
	}
	
	protected void firePropertyChange(String propertyName,
								   double oldValue,
								   double newValue)
	{
		pcs.firePropertyChange(propertyName,
							   new Double(oldValue),
							   new Double(newValue));
	}
	
	protected void firePropertyChange(String propertyName,
								   int oldValue,
								   int newValue)
	{
		pcs.firePropertyChange(propertyName, oldValue, newValue);
	}
	
	protected void firePropertyChange(String propertyName,
								   boolean oldValue,
								   boolean newValue)
	{
		pcs.firePropertyChange(propertyName, oldValue, newValue);
	}

	protected void firePropertyChange(PropertyChangeEvent evt)
	{
		pcs.firePropertyChange(evt);
	}
	
	protected boolean hasListeners(String propertyName)
	{
		return pcs.hasListeners(propertyName);
	}
}

// vim:ts=4:sw=4
