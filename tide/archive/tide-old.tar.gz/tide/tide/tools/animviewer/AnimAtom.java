/**
 *
 * @author Hayco de Jong
 *
 */


package tide.tools.animviewer;

//{ Imports.

import java.awt.Color;
import java.awt.Graphics2D;

import java.awt.geom.Rectangle2D;

import javax.swing.JComponent;

//}

public interface AnimAtom
{
	public void draw(Graphics2D g2d, JComponent component, Color color);

	public void setLocation(int x, int y);
	public int getX();
	public int getY();
	
	public void setColorKey(String key);
	public String getColorKey();
	
	public void setSolid(boolean b);
	public boolean isSolid();
	
	public void setVisible(boolean b);
	public boolean isVisible();
	
	public Object getAnimProperty(String propertyName);
	public void setAnimProperty(String propertyName, Object newValue);

	public Rectangle2D getBounds(Graphics2D g2d);
}

// vim:ts=4:sw=4
