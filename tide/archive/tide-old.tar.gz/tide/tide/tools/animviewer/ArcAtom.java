package tide.tools.animviewer;
/**
 *
 * @author Hayco de Jong
 *
 */


import java.awt.*;
import java.awt.geom.Arc2D;

import javax.swing.*;

public class ArcAtom extends AbstractAtom
{
	public static final String WIDTH  = "ARC_WIDTH";
	public static final String HEIGHT = "ARC_HEIGHT";
	public static final String START  = "ARC_START";
	public static final String EXTENT = "ARC_EXTENT";
	public static final String TYPE   = "ARC_TYPE";
	public static final String SOLID  = "ARC_SOLID";

	private Arc2D arc;

	private double width;	// overall width of the full ellipse.
	private double height;	// overall height of the full ellipse.

	private double start;	// starting angle of the arc in degrees.
	private double extent;	// angular extent in degrees.
	
	private int type;		// as defined in java.awt.geom.Arc2D.
	
	public ArcAtom()
	{
		this(0, 0, 0, 0, 0.0, 0.0, Arc2D.OPEN);
	}
	
	public ArcAtom(int x, int y)
	{
		this(x, y, 0.0, 0.0, 0.0, 0.0, Arc2D.OPEN);
	}
	
	public ArcAtom(int x, int y, double w, double h,
				   double start, double extent,
				   int type)
	{
		super(x, y);
		this.width  = w;
		this.height = h;
		this.start  = start;
		this.extent = extent;
		this.type   = type;
	}
	
	public double getWidth()
	{
		return width;
	}
	
	public void setWidth(double width)
	{
		this.width = width;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public void setHeight(double height)
	{
		this.height = height;
	}
	
	public double getAngleStart()
	{
		return start;
	}
	
	public void setAngleStart(double start)
	{
		this.start = start;
	}
	
	public double getAngleExtent()
	{
		return extent;
	}

	
	public void setAngleExtent(double extent)
	{
		this.extent = extent;
	}

	public void draw(Graphics2D g2d, JComponent component, Color color)
	{
		super.draw(g2d, component, color);
		
		if (arc == null)
			arc = new Arc2D.Double();

		arc.setArc(getX(), getY(), width, height,
				   start, extent, type);
		
		if (isSolid())
			g2d.fill(arc);
		else
			g2d.draw(arc);
	}
	
	public String toString()
	{
		String strRep = "ArcAtom[";

		strRep += "x=" + getX() + ",";
		strRep += "y=" + getY() + ",";
		strRep += "w=" + getWidth() + ",";
		strRep += "h=" + getHeight() + ",";
		strRep += "s=" + getAngleStart() + ",";
		strRep += "e=" + getAngleExtent() + ",";
		strRep += "type=" + type + "]";
		
		return strRep;
	}

	public Object getAnimProperty(String propertyName)
	{
		if (propertyName.equals(WIDTH))
			return new Double(width);

		if (propertyName.equals(HEIGHT))
			return new Double(HEIGHT);
		
		if (propertyName.equals(START))
			return new Double(start);
		
		if (propertyName.equals(EXTENT))
			return new Double(extent);
		
		if (propertyName.equals(TYPE))
			return new Integer(type);
		
		if (propertyName.equals(SOLID))
			return new Boolean(isSolid());
		
		throw new IllegalArgumentException("unknown property: "+ propertyName);
	}
	
	public void setAnimProperty(String propertyName, Object newValue)
	{
		if (propertyName.equals(WIDTH) && newValue instanceof Number)
		{
			double oldValue = width;
			width = ((Number)newValue).doubleValue();
			firePropertyChange(propertyName, oldValue, width);
		}
		else if (propertyName.equals(HEIGHT) && newValue instanceof Number)
		{
			double oldValue = height;
			height = ((Number)newValue).doubleValue();
			firePropertyChange(propertyName, oldValue, height);
		}
		else if (propertyName.equals(START) && newValue instanceof Number)
		{
			double oldValue = start;
			start = ((Number)newValue).doubleValue();
			firePropertyChange(propertyName, oldValue, start);
		}
		else if (propertyName.equals(EXTENT) && newValue instanceof Number)
		{
			double oldValue = extent;
			extent = ((Number)newValue).doubleValue();
			firePropertyChange(propertyName, oldValue, extent);
		}
		else if (propertyName.equals(TYPE) && newValue instanceof Number)
		{
			int oldValue = type;
			type = ((Number)newValue).intValue();
			firePropertyChange(propertyName, oldValue, type);
		}
		else if (propertyName.equals(SOLID) && newValue instanceof Boolean)
		{
			boolean oldValue = isSolid();
			setSolid(((Boolean)newValue).booleanValue());
			firePropertyChange(propertyName, oldValue, isSolid());
		}
		else
		{
			String msg = "illegal property/value for arc: " +
				"name="+propertyName+", value="+newValue;
			throw new IllegalArgumentException(msg);
		}
	}
}

// vim:ts=4:sw=4
