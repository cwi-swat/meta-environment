/**
 * $Id: AnimatorTemplate.java,v 1.1 1999/09/02 11:35:34 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports.

import tide.tools.*;
import tide.debug.*;

//}

public interface AnimatorTemplate
{
	/**
	 * Indicates this expression is in an unkown state.
	 */
	public static final String STATE_UNKNOWN = "unknown";

	/**
	 * Indicates this expression currently has a valid value.
	 */
	public static final String STATE_VALUE = "value";

	/**
	 * Indicates this expression is currently in an error state.
	 * This could be the case if part of the expression is out of scope.
	 */
	public static final String STATE_ERROR = "error";

	/**
	 * Get the current state of the Animator.
	 * @return the current state of the Animator.
	 */
	public String getState();

	public void setValue(String value);
	public void setError(String value);

	public void addAnimCommandHandler(AnimCommandHandler handler);
	public void removeAnimCommandHandler(AnimCommandHandler handler);
}

// vim:ts=4:sw=4
