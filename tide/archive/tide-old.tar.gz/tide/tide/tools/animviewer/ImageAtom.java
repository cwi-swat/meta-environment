package tide.tools.animviewer;
/**
 *
 * @author Hayco de Jong
 *
 */


import java.awt.*;
import java.awt.geom.Point2D;
import javax.swing.*;

public class ImageAtom extends AbstractAtom
{
	public static final String FILE = "IMAGE_FILE";

	private String file;
	private Image img;
	
	//{ public ImageAtom()

	public ImageAtom()
	{
		this(0, 0, "");
	}

	//}
	//{ public ImageAtom(int x, int y)

	public ImageAtom(int x, int y)
	{
		this(x, y, "");
	}

	//}
	//{ public ImageAtom(int x, int y, String file)

	public ImageAtom(int x, int y, String file)
	{
		super(x, y);
		this.file = file;
	}

	//}
	//{ public void draw(Graphics2D g2d, JComponent component, Color color)

	public void draw(Graphics2D g2d, JComponent component, Color color)
	{
		super.draw(g2d, component, color);

		if (img == null)
		{
			if (file == null)
				return;
			else
				img = component.getToolkit().getImage(file);
		}

		g2d.drawImage(img, (int)getX(), (int)getY(), component);
	}

	//}
	//{ public String toString()

	public String toString()
	{
		return "ImageAtom[file="+file+",x="+getX()+",y="+getY()+"]";
	}

	//}
	//{ public Object getAnimProperty(String propertyName)

	public Object getAnimProperty(String propertyName)
	{
		if (propertyName.equals(FILE))
			return new String(file);

		throw new IllegalArgumentException("unknown property: "+ propertyName);
	}

	//}
	//{ public void setAnimProperty(String propertyName, Object newValue)

	public void setAnimProperty(String propertyName, Object newValue)
	{
		if (propertyName.equals(FILE) && newValue instanceof String)
		{
			String oldValue = file;
			file = (String) newValue;
			img  = null;
			firePropertyChange(propertyName, oldValue, file);
		}
		else
		{
			String msg = "illegal property/value for image: " +
				"name="+propertyName+", value="+newValue;
			throw new IllegalArgumentException(msg);
		}
	}

	//}
}
