/**
 * $Id: AnimCommandHandler.java,v 1.1 1999/09/02 11:35:34 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

import java.util.*;

public interface AnimCommandHandler
{
	public void issueAnimCommand(AnimCommand cmd);
}

// vim:ts=4:sw=4
