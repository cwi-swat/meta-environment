/**
 *
 * @author Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports.

import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.awt.font.TextLayout;
import java.awt.font.FontRenderContext;

import javax.swing.*;

//}

public class TextAtom extends AbstractAtom
{
	public static final String MESSAGE = "TEXT_MESSAGE";

	private String s;

	private Font font;

	public TextAtom()
	{
		this(0, 0, "Test");
	}
	
	public TextAtom(int x, int y)
	{
		this(x, y, "Test");
	}

	public TextAtom(int x, int y, String s)
	{
		super(x, y);
		this.s = s;
	}

	public Font getFont()
	{
		return font;
	}

	public void setFont(Font font)
	{
		this.font = font;
	}

	public void draw(Graphics2D g2d, JComponent component, Color color)
	{
		super.draw(g2d, component, color);

		// Early exit in case of invalid String.
		if (s == null || s.length() <= 0)
			return;

		FontRenderContext frc = g2d.getFontRenderContext();
		Font f = (font == null ? g2d.getFont() : font);
		TextLayout layout = new TextLayout(s, f, frc);
		layout.draw(g2d, (float)getX(), (float)getY());
	}

	public Rectangle2D getBounds(Graphics2D g2d)
	{
		FontRenderContext frc = g2d.getFontRenderContext();
		Font f = (font == null ? g2d.getFont() : font);
		TextLayout layout = new TextLayout(s, f, frc);
		Rectangle2D bounds = layout.getBounds();
		return bounds;
	}

	public String toString()
	{
		return "TextAtom["+s+",x="+getX()+",y="+getY()+"]";
	}

	public Object getAnimProperty(String propertyName)
	{
		if (propertyName.equals(MESSAGE))
			return new String(s);

		throw new IllegalArgumentException("unknown property: "+ propertyName);
	}

	public void setAnimProperty(String propertyName, Object newValue)
	{
		if (propertyName.equals(MESSAGE) && newValue instanceof String)
		{
			String oldValue = s;
			s = (String)newValue;
			firePropertyChange(propertyName, oldValue, s);
		}
		else
		{
			String msg = "illegal property/value for text: " +
				"name="+propertyName+", value="+newValue;
			throw new IllegalArgumentException(msg);
		}
	}
}
