/**
 * $Id: CustomizeTree.java,v 1.1 1999/09/02 11:35:35 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports.

import java.awt.Dimension;

import java.util.*;

import javax.swing.JTree;
import javax.swing.tree.*;

//}

public class CustomizeTree
	extends JTree
{
	private MutableTreeNode root;
	private DefaultTreeModel model;

	public CustomizeTree()
	{
		super();
		//{
		this.root  = new DefaultMutableTreeNode();
		this.model = new DefaultTreeModel(root);
		//}
		getSelectionModel().setSelectionMode(
			TreeSelectionModel.SINGLE_TREE_SELECTION);
		setModel(model);
		setRootVisible(false);
		putClientProperty("JTree.lineStyle", "Angled");
	}

	public Dimension getPreferredSize()
	{
		return new Dimension(200, 200);
	}

	public void addCustomPath(String path)
	{
		StringTokenizer st = new StringTokenizer(path, ".");

		MutableTreeNode node = root;
		while (st.hasMoreTokens())
		{
			MutableTreeNode next = new DefaultMutableTreeNode(st.nextToken());
			model.insertNodeInto(next, node, 0);
			node = next;
		}
		TreePath pathToRoot = new TreePath(model.getPathToRoot(node));
		expandPath(pathToRoot);
		setSelectionPath(pathToRoot);
	}
}

// vim:ts=4:sw=4
