package tide.tools.animviewer;
/**
 *
 * @author Hayco de Jong
 *
 */


import java.awt.*;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.swing.*;

public class RectangleAtom extends AbstractAtom
{
	public static final String WIDTH  = "RECTANGLE_WIDTH";
	public static final String HEIGHT = "RECTANGLE_HEIGHT";
	public static final String SOLID  = "RECTANGLE_SOLID";
	public static final String COLOR  = "RECTANGLE_COLOR";

	private Rectangle2D rectangle;

	private int width;
	private int height;
	
	public RectangleAtom()
	{
		this(0, 0, 0, 0);
	}
	
	public RectangleAtom(int x, int y)
	{
		this(x, y, 0, 0);
	}
	
	public RectangleAtom(int x, int y, int w, int h)
	{
		super(x, y);
		this.width  = w;
		this.height = h;
	}
	
	public int getWidth()
	{
		return width;
	}
	
	public int getHeight()
	{
		return height;
	}
	
	public void draw(Graphics2D g2d, JComponent component, Color color)
	{
		super.draw(g2d, component, color);
		
		if (rectangle == null)
			rectangle = new Rectangle2D.Double();

		rectangle.setRect(getX(), getY(), width, height);

		if (isSolid())
			g2d.fill(rectangle);
		else
			g2d.draw(rectangle);
	}
	
	public String toString()
	{
		return "RectangleAtom[x="+getX()+",y="+getY()+
			",width="+width+",height="+height+"]";
	}

	public Object getAnimProperty(String propertyName)
	{
		if (propertyName.equals(WIDTH))
			return new Double(width);

		if (propertyName.equals(HEIGHT))
			return new Double(height);
		
		if (propertyName.equals(SOLID))
			return new Boolean(isSolid());
		
		throw new IllegalArgumentException("unknown property: "+ propertyName);
	}

	public void setAnimProperty(String propertyName, Object newValue)
	{
		if (propertyName.equals(WIDTH) && newValue instanceof Number)
		{
			int oldValue = width;
			width = ((Number)newValue).intValue();
			firePropertyChange(propertyName, oldValue, width);
		}
		else if (propertyName.equals(HEIGHT) && newValue instanceof Number)
		{
			int oldValue = height;
			height = ((Number)newValue).intValue();
			firePropertyChange(propertyName, oldValue, height);
		}
		else if (propertyName.equals(SOLID) && newValue instanceof Boolean)
		{
			boolean oldValue = isSolid();
			setSolid(((Boolean)newValue).booleanValue());
			firePropertyChange(propertyName, oldValue, isSolid());
		}
		else
		{
			String msg = "illegal property/value for rectangle: " +
				"name="+propertyName+", value="+newValue;
			throw new IllegalArgumentException(msg);
		}
	}
}

// vim:ts=4:sw=4
