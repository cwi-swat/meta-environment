/**
 * $Id: PainterTool.java,v 1.1 1999/09/02 11:35:36 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports

import aterm.*;
import aterm.tool.*;

import java.awt.*;
import java.awt.event.*;

import java.io.*;
import java.net.*;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;

import tide.tools.*;
import tide.debug.*;

//}

public class PainterTool
	extends PainterTif
{
	//{ Private fields

	/**
	 * Name of the painter used in ToolBus communication.
	 *
	 * @serial
	 */
	private static String PAINTER_NAME = "painter";

	/**
	 * Used to generate unique identification numbers.
	 *
	 * @serial
	 */
	private int canvasID;

	/**
	 * Mapping to hold all canvases this painter knows about.
	 */
	private Map canvasMap;

	/**
	 * Desktop the canvases should be created on.
	 */
	private JDesktopPane desktop;

	/**
	 * State of the tool, is it running?
	 */
	private boolean isRunning;

	/**
	 * Thread that runs this tool
	 */
	private Thread thread;

	//}
	//{ Constructor(s)
	//{ public PainterTool(JDesktopPane desktop, InetAddress addr, int port)

	/**
	 * Create a new PainterTool object.
	 *
	 * @param desktop JDesktopPane that holds created canvases.
	 * @param addr Address of the ToolBus to connect to.
	 * @param port Port of the ToolBus to connect to.
	 */
	public PainterTool(JDesktopPane desktop, InetAddress addr, int port)
		throws UnknownHostException
	{
		// Let parent setup the name, address and port.
		super(PAINTER_NAME, addr, port);

		//{ Initialize private fields.
		this.canvasID  = 0;
		this.canvasMap = new HashMap();
		this.desktop   = desktop;
		this.isRunning = true;
		this.thread    = new Thread(this);
		//}

		// Start the thread running this painter.
		thread.start();
	}

	//}
	//}

	//{ public void join()

	/**
	 * Allow another thread to join our thread.
	 * The parent that created us may wish to wait for us to terminate
	 * gracefully. This can be done by <code>join</code>ing us.
	 *
	 * @exception InterruptedException
	 * @see Thread#join
	 */
	public void join()
		throws InterruptedException
	{
		thread.join();
	}

	//}
	//{ public void run()

	/**
	 * Run method is called from our thread.
	 *
	 * While we are in the running state, let our parent do its work.
	 */
	public void run()
	{
		while (isRunning)
			   super.run();
	}

	//}
	//{ private synchronized int dispenseCanvasID()

	/**
	 * Dispense unique canvas identifiers.
	 *
	 * Implemented to give the next (unused) <code>int</code> in the
	 * ascending range <code>0 through Integer.MAX_VALUE</code>.
	 *
	 * @exception RuntimeException when the next canvas ID would
	 * exceed <code>Integer.MAX_VALUE</code>.
	 */
	private synchronized int dispenseCanvasID()
	{
		if (canvasID < Integer.MAX_VALUE)
			return canvasID++;
		else
			throw new RuntimeException("PainterTool: ID-pool exhausted!");
	}

	//}

	//{ Implementation of abstract methods from PainterTif

	//{ ATerm createCanvas()

	/**
	 * Handle request to create a new canvas.
	 */
	ATerm createCanvas()
	{
		// Get a unique ID for this canvas.
		int cid = dispenseCanvasID();

		// Create the frame and the canvas.
		PainterFrame frame = new PainterFrame(cid);
		AnimCanvas canvas = new AnimCanvas(frame);

		// Put the canvas in our administration.
		canvasMap.put(new Integer(cid), canvas);

		// Pack and install the canvas.
		frame.pack();
		desktop.add(frame, new Integer(1));
		desktop.moveToFront(frame);

		// Return the ID.
		return ATerm.make("snd-value(canvas-created(<int>))", new Integer(cid));
	}

	//}
	//{ void destroyCanvas(int cid)

	/**
	 * Handle request to destroy a canvas
	 *
	 * @param cid ID of canvas to be destroyed.
	 */
	void destroyCanvas(int cid)
	{
		System.err.println("#P# destroyCanvas(" + cid + ")");
	}

	//}
	//{ void executeCommand(int cid, ATerm command)

	void executeCommand(int cid, ATerm command)
	{
		Vector matchResult;

		System.err.println("#P# executing " + command);

		AnimCanvas canvas = (AnimCanvas) canvasMap.get(new Integer(cid));
		if (canvas == null)
			throw new RuntimeException("No such canvas: " + cid);

		//{ match("create(<term>,<str>)")

		matchResult = command.match("create(<int>,<str>)");
		if (matchResult != null)
		{
			int id = ((Integer)matchResult.elementAt(0)).intValue();
			String type = (String)matchResult.elementAt(1);
			canvas.createAnimAtom(id, type);
			return;
		}

		//}
		//{ match("range-x(<int>,<int>)")

		matchResult = command.match("range-x(<int>,<int>)");
		if (matchResult != null)
		{
			int lowX  = ((Integer)matchResult.elementAt(0)).intValue();
			int highX = ((Integer)matchResult.elementAt(1)).intValue();
			canvas.setRangeX(lowX, highX);
			return;
		}

		//}
		//{ match("range-y(<int>,<int>)")

		matchResult = command.match("range-y(<int>,<int>)");
		if (matchResult != null)
		{
			int lowX  = ((Integer)matchResult.elementAt(0)).intValue();
			int highX = ((Integer)matchResult.elementAt(1)).intValue();
			canvas.setRangeY(lowX, highX);
			return;
		}

		//}
		//{ match("repaint")

		if (command.match("repaint") != null)
		{
			canvas.repaint();
			return;
		}

		//}
		//{ match("set-location(<int>,<int>,<int>)")

		matchResult = command.match("set-location(<int>,<int>,<int>)");
		if (matchResult != null)
		{
			int id = ((Integer)matchResult.elementAt(0)).intValue();
			int x  = ((Integer)matchResult.elementAt(1)).intValue();
			int y  = ((Integer)matchResult.elementAt(2)).intValue();
			canvas.setAtomLocation(id, x, y);
			return;
		}

		//}
		//{ match("set-color(<int>,<str>)")

		matchResult = command.match("set-color(<int>,<str>)");
		if (matchResult != null)
		{
			int id = ((Integer)matchResult.elementAt(0)).intValue();
			String colorKey = (String) matchResult.elementAt(1);
			canvas.setAtomColor(id, colorKey);
			return;
		}

		//}
		//{ match("set-solid(<int>,<bool>)")

		matchResult = command.match("set-solid(<int>,<bool>)");
		if (matchResult != null)
		{
			int id = ((Integer)matchResult.elementAt(0)).intValue();
			boolean vis = ((Boolean)matchResult.elementAt(1)).booleanValue();
			canvas.setAtomSolidness(id, vis);
			return;
		}

		//}
		//{ match("set-property(<int>,<str>,<str>)")

		matchResult = command.match("set-property(<int>,<str>,<str>)");
		if (matchResult != null)
		{
			int id = ((Integer)matchResult.elementAt(0)).intValue();
			String key = (String)matchResult.elementAt(1);
			String value = (String)matchResult.elementAt(2);
			canvas.setAtomProperty(id, key, value);
			return;
		}

		//}
		//{ match("set-visible(<int>,<bool>)")

		matchResult = command.match("set-visible(<int>,<bool>)");
		if (matchResult != null)
		{
			int id = ((Integer)matchResult.elementAt(0)).intValue();
			boolean vis = ((Boolean)matchResult.elementAt(1)).booleanValue();
			canvas.setAtomVisibility(id, vis);
			return;
		}

		//}
		//{ match("register-color(<str>,<str>,<int>,<int>,<int>)")

		matchResult = command.match("register-color(<str>,<str>,<int>,<int>,<int>)");
		if (matchResult != null)
		{
			String path = (String) matchResult.elementAt(0);
			String key  = (String) matchResult.elementAt(1);
			int r  = ((Integer)matchResult.elementAt(2)).intValue();
			int g  = ((Integer)matchResult.elementAt(3)).intValue();
			int b  = ((Integer)matchResult.elementAt(4)).intValue();
			canvas.registerColor(path, key, new Color(r, g, b));
			return;
		}

		//}
		matchResult = command.match("config-path(<str>)");
		if (matchResult != null)
		{
			String configPath = (String) matchResult.elementAt(0);
			canvas.setConfigPath(configPath);
			return;
		}

		throw new RuntimeException("Unknown command: " + command);
	}

	//}
	//{ void recTerminate(ATerm desc)

	/**
	 * Handle request to terminate this tool.
	 *
	 * As this tool is run by a thread, we don't do a System.exit,
	 * but deactivate the responsible thread instead.
	 *
	 * @param desc describes nature of termination request.
	 */
	void recTerminate(ATerm desc)
	{
		System.err.println("PainterTool terminating.");
		// Stop the thread running this tool.
		isRunning = false;
	}

	//}

	//}

	//{ class PainterFrame extends JInternalFrame
	class PainterFrame extends JInternalFrame
	{
		PainterFrame(final int cid)
		{
			super("Canvas-"+cid, true, true, true, true);
			addInternalFrameListener(new InternalFrameAdapter() {
				public void internalFrameClosing(InternalFrameEvent e) {
					destroyCanvas(cid);
				}});
		}
		
		public Dimension getPreferredSize()
		{
			return new Dimension(200, 110);
		}
	}
	//}
}

// vim:ts=4:sw=4
