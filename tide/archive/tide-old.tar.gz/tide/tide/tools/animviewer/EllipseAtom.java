package tide.tools.animviewer;
/**
 *
 * @author Hayco de Jong
 *
 */


import java.awt.*;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;

import javax.swing.*;

public class EllipseAtom extends AbstractAtom
{
	public static final String WIDTH  = "ELLIPSE_WIDTH";
	public static final String HEIGHT = "ELLIPSE_HEIGHT";
	public static final String SOLID  = "ELLIPSE_SOLID";

	private Ellipse2D ellipse;

	private double width;
	private double height;
	
	public EllipseAtom()
	{
		this(0, 0, 0.0, 0.0);
	}
	
	public EllipseAtom(int x, int y)
	{
		this(x, y, 0.0,  0.0);
	}
	
	public EllipseAtom(int x, int y, double w, double h)
	{
		super(x, y);

		this.width  = w;
		this.height = h;
	}
	
	public double getWidth()
	{
		return width;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public void setWidth(double w)
	{
		this.width = w;
	}
	
	public void setHeight(double h)
	{
		this.height = h;
	}

	
	public void draw(Graphics2D g2d, JComponent component, Color color)
	{
		super.draw(g2d, component, color);
		
		if (ellipse == null)
			ellipse = new Ellipse2D.Double();
		
		// So much for Java's sense of orthogonality.
		// Line2D has setLine, Rect2D has setRect, but
		// Ellipse2D has setFrame ;-)
		ellipse.setFrame(getX(), getY(), width, height);
		
		if (isSolid())
			g2d.fill(ellipse);
		else
			g2d.draw(ellipse);
	}

	public Object getAnimProperty(String propertyName)
	{
		if (propertyName.equals(WIDTH))
			return new Double(width);

		if (propertyName.equals(HEIGHT))
			return new Double(height);
		
		if (propertyName.equals(SOLID))
			return new Boolean(isSolid());
		
		throw new IllegalArgumentException("unknown property: "+ propertyName);
	}

	public void setAnimProperty(String propertyName, Object newValue)
	{
		if (propertyName.equals(WIDTH) && newValue instanceof Number)
		{
			double oldValue = width;
			width = ((Number)newValue).doubleValue();
			firePropertyChange(propertyName, oldValue, width);
		}
		else if (propertyName.equals(HEIGHT) && newValue instanceof Number)
		{
			double oldValue = height;
			height = ((Number)newValue).doubleValue();
			firePropertyChange(propertyName, oldValue, height);
		}
		else if (propertyName.equals(SOLID) && newValue instanceof Boolean)
		{
			boolean oldValue = isSolid();
			setSolid(((Boolean)newValue).booleanValue());
			firePropertyChange(propertyName, oldValue, isSolid());
		}
		else
		{
			String msg = "illegal property/value for ellipse: " +
				"name="+propertyName+", value="+newValue;
			throw new IllegalArgumentException(msg);
		}
	}
}

// vim:ts=4:sw=4
