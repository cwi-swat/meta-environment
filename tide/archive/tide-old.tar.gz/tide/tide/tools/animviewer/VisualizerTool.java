/**
 * $Id: VisualizerTool.java,v 1.1 1999/09/02 11:35:36 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports

import aterm.*;
import aterm.tool.*;

import java.io.IOException;
import java.net.UnknownHostException;

/*
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
*/
import java.util.*;

import tide.tools.*;
import tide.debug.*;
import tide.config.*;

//}

/**
 * A Visualizer generates painting commands for a given expression.
 *
 */
public class VisualizerTool
	extends VisualizerTif
{
	//{ Public constants.

	public static final String ANIM_GENERIC = "Generic";
	public static final String ANIM_COUNTER = "Counter";
	public static final String ANIM_STRING  = "String";
	public static final String ANIM_ATERM   = "ATerm";

	//}
	//{ Private fields.

	/**
	 * Each expression to be visualized is kept in a map.
	 */
	private HashMap expressionMap;

	/**
	 * All visualization templates are stored in a vector.
	 */
	private Vector templates;

	//}
	
	//{ Constructor(s)
	//{ public Visualizer(String[] args)

	public VisualizerTool(String[] args)
		throws UnknownHostException
	{
		super(args);
		expressionMap = new HashMap();
		templates = new Vector();

		// Initialize templateMap.
		templates.add(ANIM_GENERIC);
		templates.add(ANIM_COUNTER);
		templates.add(ANIM_STRING);
		templates.add(ANIM_ATERM);
	}

	//}
	//}

	//{ Auxiliary methods.
	//{ private AnimatorTemplate createAnimator(expr, tmpl, key)

	private AnimatorTemplate createAnimator(String tmpl, String expr,
											ATermAppl key)
	{
		// If we know the template, create the required animator.
		if (tmpl.equals(ANIM_GENERIC))
			return new GenericAnimator(expr, new VisualizationHandler(key));

		// Unknown template if we haven't found one by now.
		throw new RuntimeException(
			"Visualizer: unknown template: \"" + tmpl + "\"");
	}

	//}
	//{ class VisualizationHandler implements AnimCommandHandler

	class VisualizationHandler implements AnimCommandHandler
	{
		private ATermAppl key;
		public VisualizationHandler(ATermAppl key)
		{
			this.key = key;
		}
		public void issueAnimCommand(AnimCommand cmd)
		{
			try {
				ATerm event = ATerm.make(
					"anim-cmd(<term>,<term>)", key, cmd.toTerm());
				post((ATermAppl)event);
			} catch (ParseError e) {
				System.err.println("parse error: " + e.getMessage());
			} catch (ToolException e) {
				System.err.println("toolexception: " + e.getMessage());
			}
		}
	}

	//}
	//}

	//{ Implementation of abstract methods from VisualizerTif
	//{ public ATerm getTemplates

	/**
	 * Handle request for a list of the available templates.
	 */
	public ATerm getTemplates()
	{
		String value = "";
		Iterator iter = templates.iterator();
		while (iter.hasNext())
		{
			value += '"' + (String) iter.next() + '"';
			if (iter.hasNext())
				value += ',';
		}
		System.err.println("value: " + value);
		return ATerm.make("snd-value(templates([" + value + "]))");
	}

	//}
	//{ public void recAckEvent(ATerm t)

	/**
	 * Acknowledgment of a previously sent event.
	 */
	public void recAckEvent(ATerm t)
	{
		/* empty */
	}

	//}
	//{ public void recTerminate(ATerm t)

	/**
	 * Handle request to terminate this tool.
	 */
	public void recTerminate(ATerm t)
	{
		System.exit(0);
	}

	//}
	//{ public void visualize(updateKey, canvasKey, expr, tmpl)

	/**
	 * Setup a new visualization.
	 *
	 * @param updateKey the key used when updating the state of expr.
	 * @param canvasKey the key used when sending painting commands.
	 * @param expr the expression to be visualized.
	 * @param tmpl the template defining how <code>expr</code> will be
	 * visualized.
	 */
	
	public void visualize(ATermAppl updateKey, ATermAppl canvasKey,
						  String expr, String tmpl)
	{
		System.err.println("visualize("+updateKey+","+canvasKey+","+
						   expr+","+tmpl+")");
		// Avoid duplicate keys.
		if (expressionMap.containsKey(updateKey))
			throw new RuntimeException(
				"Visualizer already has key: " + updateKey);

		// Create a new animator.
		AnimatorTemplate handler = createAnimator(tmpl, expr, canvasKey);

		// Associate this animator with the expression.
		expressionMap.put(updateKey, handler);
	}

	//}
	//{ public void update(ATermAppl key, ATerm newValue)

	/**
	 * Update the value of an expression.
	 */
	public void update(ATermAppl key, ATerm newValue)
	{
		System.err.println("#V# event("+key+','+newValue+')');

		// Fetch the animator for this expression.
		AnimatorTemplate anim = (AnimatorTemplate) expressionMap.get(key);
		if (anim == null)
			throw new RuntimeException("Visualizer does not know: " + key);


		// The new value could be a real for the expression.
		Vector value = newValue.match("value(<str>)");
		if (value != null)
		{
			String valueString = (String) value.elementAt(0);
			anim.setValue(valueString);
			return;
		}

		// Alternatively the new value may indicate an error state.
		value = newValue.match("error(<str>)");
		if (value != null)
		{
			String valueString = (String) value.elementAt(0);
			anim.setError(valueString);
			return;
		}

		// The new value is neither value nor error .. we're in trouble.
		throw new RuntimeException("Visualizer got illegal value " + newValue);
	}

	//}
	//}

	//{ public static void main(String[] args)

	public static void main(String[] args)
	{
		VisualizerTool visTool = null;

		// Try to create and connect the visualizer tool.
		// Early exit if we encounter any exceptions at this stage.
		try {
			visTool = new VisualizerTool(args);
			visTool.connect();
		} catch (UnknownHostException e) {
			System.err.println("Visualizer: unknown host" + e.getMessage());
			System.exit(1);
		} catch (IOException e) {
			System.err.println("Visualizer: I/O exception " + e.getMessage());
			System.exit(2);
		} catch (ToolException e) {
			System.err.println("Visualizer: tool exception " + e.getMessage());
			System.exit(3);
		}

		// If we have a valid visualizer tool, run it.
		if (visTool != null)
			visTool.run();
	}

	//}
}
