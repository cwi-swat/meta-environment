/**
 * $Id: CommandFactory.java,v 1.2 1999/09/15 09:18:27 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports.

import aterm.*;

import java.awt.Color;

import java.util.Enumeration;
import java.util.Vector;

//}

public class CommandFactory
{
	public final static int	CMD_CREATE          =  0;
	public final static int	CMD_RANGE_X         =  1;
	public final static int	CMD_RANGE_Y         =  2;
	public final static int	CMD_REPAINT         =  3;
	public final static int	CMD_SET_COLOR       =  4;
	public final static int	CMD_SET_LOCATION    =  5;
	public final static int	CMD_SET_PROPERTY    =  6;
	public final static int	CMD_SET_SOLID       =  7;
	public final static int	CMD_SET_VISIBLE     =  8;
	public final static int CMD_REGISTER_COLOR  =  9;
	public final static int CMD_SET_CONFIG_PATH = 10;

	private final static String[] commandPatterns =
	{
		"create(<int>,<str>)",
		"range-x(<int>,<int>)",
		"range-y(<int>,<int>)",
		"repaint",
		"set-color(<int>,<str>)",
		"set-location(<int>,<int>,<int>)",
		"set-property(<int>,<str>,<str>)",
		"set-solid(<int>,<appl>)",
		"set-visible(<int>,<appl>)",
		"register-color(<str>,<str>,<int>,<int>,<int>)",
		"config-path(<str>)",
	};

	//{ protected static AnimCommand command(int cmdNr)

	protected static AnimCommand command(int cmdNr)
	{
		return command(cmdNr, null);
	}

	//}

	//{ protected static AnimCommand command(int cmdNr, Vector params)

	protected static AnimCommand command(int cmdNr, Vector params)
		throws ParseError
	{
		ATerm cmd = null;
		if (params == null)
			cmd = ATerm.parse(commandPatterns[cmdNr]);
		else
			cmd = ATerm.make(commandPatterns[cmdNr], params.elements());
		return new ATermCommand(cmd);
	}

	//}

	//{ public static AnimCommand cmdCreate(id, type)

	public static AnimCommand cmdCreate(int id, String type)
	{
		Vector v = new Vector(4);
		v.addElement(new Integer(id));
		v.addElement(type);
		return command(CMD_CREATE, v);
	}

	//}
	//{ public static AnimCommand cmdRangeX(int low, int high)

	public static AnimCommand cmdRangeX(int low, int high)
	{
		Vector v = new Vector(2);
		v.addElement(new Integer(low));
		v.addElement(new Integer(high));
		return command(CMD_RANGE_X, v);
	}

	//}
	//{ public static AnimCommand cmdRangeY(int low, int high)

	public static AnimCommand cmdRangeY(int low, int high)
	{
		Vector v = new Vector(2);
		v.addElement(new Integer(low));
		v.addElement(new Integer(high));
		return command(CMD_RANGE_Y, v);
	}

	//}
	//{ public static AnimCommand cmdRepaint()

	public static AnimCommand cmdRepaint()
	{
		return command(CMD_REPAINT);
	}

	//}
	//{ public static AnimCommand cmdSetColor(int id, String colorKey)

	public static AnimCommand cmdSetColor(int id, String colorKey)
	{
		Vector v = new Vector(2);
		v.addElement(new Integer(id));
		v.addElement(new String(colorKey));
		return command(CMD_SET_COLOR, v);
	}

	//}
	//{ public static AnimCommand cmdSetLocation(int id, int x, int y)

	public static AnimCommand cmdSetLocation(int id, int x, int y)
	{
		Vector v = new Vector(3);
		v.addElement(new Integer(id));
		v.addElement(new Integer(x));
		v.addElement(new Integer(y));
		return command(CMD_SET_LOCATION, v);
	}

	//}
	//{ public static AnimCommand cmdSetSolid(int id, boolean solid)

	public static AnimCommand cmdSetSolid(int id, boolean solid)
	{
		Vector v = new Vector(2);
		v.addElement(new Integer(id));
		v.addElement(solid ? "true" : "false");
		return command(CMD_SET_SOLID, v);
	}

	//}
	//{ public static AnimCommand cmdSetVisible(int id, boolean visible)

	public static AnimCommand cmdSetVisible(int id, boolean visible)
	{
		Vector v = new Vector(2);
		v.addElement(new Integer(id));
		v.addElement(visible ? "true" : "false");
		return command(CMD_SET_VISIBLE, v);
	}

	//}
	//{ public static AnimCommand cmdSetProperty(int id, String key, value)

	public static AnimCommand cmdSetProperty(int id, String key, String value)
	{
		Vector v = new Vector(3);
		v.addElement(new Integer(id));
		v.addElement(key);
		v.addElement(value);
		return command(CMD_SET_PROPERTY, v);
	}

	//}
	//{ public static AnimCommand cmdRegisterColor(String path, String key, Color color)

	public static AnimCommand cmdRegisterColor(String path, String key, Color c)
	{
		Vector v = new Vector(5);
		v.addElement(path);
		v.addElement(key);
		v.addElement(new Integer(c.getRed()));
		v.addElement(new Integer(c.getGreen()));
		v.addElement(new Integer(c.getBlue()));
		return command(CMD_REGISTER_COLOR, v);
	}

	//}
	//{ public static AnimCommand cmdInfo(String info)

	public static AnimCommand cmdSetConfigPath(String configPath)
	{
		Vector v = new Vector(1);
		v.addElement(configPath);
		return command(CMD_SET_CONFIG_PATH, v);
	}

	//}
}

// vim:ts=4:sw=4
