package tide.tools.animviewer;

//{ Imports

import tide.tools.*;
import tide.debug.*;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

import java.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.tree.*;

//}

public class AnimCanvas
	extends JComponent
{
	//{ Public fields.

	public static final String ARC       = "ATOM_ARC";
	public static final String ELLIPSE   = "ATOM_ELLIPSE";
	public static final String IMAGE     = "ATOM_IMAGE";
	public static final String LINE      = "ATOM_LINE";
	public static final String RECTANGLE = "ATOM_RECTANGLE";
	public static final String TEXT      = "ATOM_TEXT";

	//}
	//{ Private fields.

	/**
	 * Eheu! "List" ambigu est: java.awt.List vs java.util.List
	 * @serial
	 */
	private java.util.List animAtoms;
	
	/**
	 * @serial
	 */
	private int startX;

	/**
	 * @serial
	 */
	private int startY;

	/**
	 * @serial
	 */
	private int endX;

	/**
	 * @serial
	 */
	private int endY;

	private int zoomPctX;
	private int zoomPctY;

	private Map renderingHints;
	private JToolBar toolBar;
	private JScrollPane scrollPane;
	private JInternalFrame parent;
	private Container contentPane;
	private String configPath;

	/**
	 * Mapping to hold all registered colors.
	 */
	private Map colorMap;

	//}

	//{ Constructor(s)
	//{ public AnimCanvas(JInternalFrame parent)

	/**
	 * Create a new AnimCanvas object.
	 */
	public AnimCanvas(JInternalFrame parent)
	{
		//{ Initialize private fields.
		this.animAtoms = null;

		// Default coordinates: 0..100
		this.startX = 0;
		this.startY = 0;
		this.endX   = 100;
		this.endY   = 100;

		// Default zoom is at 100%
		this.zoomPctX = 100;
		this.zoomPctY = 100;

		// Create a mapping of the RenderingHints for later reuse.
		this.renderingHints = new HashMap();
		this.renderingHints.put(RenderingHints.KEY_ANTIALIASING,
								RenderingHints.VALUE_ANTIALIAS_ON);
		this.renderingHints.put(RenderingHints.KEY_RENDERING,
								RenderingHints.VALUE_RENDER_QUALITY);
		this.renderingHints.put(RenderingHints.KEY_TEXT_ANTIALIASING,
								RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		this.toolBar = createToolBar();

		this.parent = parent;
		// Surround ourselves by a scroll pane.
		this.scrollPane = new JScrollPane(this);

		// Use a hash map to hold all registered colors.
		this.colorMap = new HashMap();

		// Extract content pane.
		this.contentPane = parent.getContentPane();

		this.configPath = "";
		//}

		// Install a BorderLayout.
		contentPane.setLayout(new BorderLayout());

		// Put scroll pane in the center, toolbar below.
		contentPane.add(scrollPane, BorderLayout.CENTER);
		contentPane.add(toolBar, BorderLayout.SOUTH);

		// Start with a white background.
		setBackground(Color.white);

		// Curtain up.
		setVisible(true);
	}

	//}
	//}

	//{ private JButton createColorButton(final JPanel f, final Object key)

	private JButton createColorButton(final JPanel panel, final Object key)
	{
		Color curColor = (Color) colorMap.get(key);
		final JButton b = new JButton("Change", new ColorIcon(curColor));
		b.setFont(new Font("Helvetica", Font.PLAIN, 12));
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				Color newColor = JColorChooser.showDialog(
					panel, "Select color", (Color) colorMap.get(key));
				if (newColor != null)
				{
					// Update color on this very button
					b.setIcon(new ColorIcon(newColor, 12, 12));
					// Update color map.
					colorMap.put(key, newColor);
					repaint();
				}
			}
		});
		return b;
	}

	//}
	//{ private void customize()

	private void customize()
	{
		JPanel treePanel = new JPanel();
		treePanel.setBorder(new CompoundBorder(
			new EmptyBorder(2, 2, 2, 2),
			new TitledBorder(new EtchedBorder(), "Persistency",
			TitledBorder.DEFAULT_JUSTIFICATION,
			TitledBorder.DEFAULT_POSITION,
			new Font("Helvetica", Font.PLAIN, 10))));
		CustomizeTree tree = new CustomizeTree();
		treePanel.add(tree);
		JScrollPane treeScroll = new JScrollPane(treePanel);
		treeScroll.setBorder(null);
		tree.addCustomPath(configPath);

		JPanel colorPanel = new JPanel();
		colorPanel.setLayout(new BoxLayout(colorPanel, BoxLayout.Y_AXIS));
		colorPanel.setBorder(new CompoundBorder(
			new EmptyBorder(2, 2, 2, 2),
			new TitledBorder(new EtchedBorder(), "Colors",
				TitledBorder.DEFAULT_JUSTIFICATION,
				TitledBorder.DEFAULT_POSITION,
				new Font("Helvetica", Font.PLAIN, 10))));
		Iterator iter = colorMap.keySet().iterator();
		while (iter.hasNext())
			colorPanel.add(createColorButton(colorPanel, iter.next()));
		colorPanel.add(Box.createVerticalGlue());

		JPanel p = new JPanel();
		p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
		p.add(treeScroll);
		p.add(colorPanel);

		JInternalFrame frame =
			new JInternalFrame("Customize", true, true, true, true);
		frame.getContentPane().add(p);
		frame.pack();

		JDesktopPane desktop = (JDesktopPane) parent.getParent();
		desktop.add(frame, JLayeredPane.PALETTE_LAYER);
		desktop.moveToFront(frame);
	}

	//}

	private Icon createCustomIcon()
	{
		return new Icon()
		{
			public void paintIcon(Component c, Graphics g, int x, int y)
			{
				Color oldColor = g.getColor();
				g.setColor(Color.yellow);
				g.fill3DRect(x+1,y+1,4,4,true);
				g.setColor(Color.red);
				g.fill3DRect(x+7,y+1,4,4,true);
				g.setColor(Color.green);
				g.fill3DRect(x+1,y+7,4,4,true);
				g.setColor(Color.blue);
				g.fill3DRect(x+7,y+7,4,4,true);
				g.setColor(oldColor);
			}
			public int getIconWidth()  { return 12; }
			public int getIconHeight() { return 12; }
		};
	}

	private JToolBar createToolBar()
	{
		JButton bAction;

		JToolBar toolBar = new JToolBar(JToolBar.HORIZONTAL);
		toolBar.setFloatable(false);

		//{ Condense in X direction.
		bAction = toolBar.add(new
			AbstractAction("condense X",
						   new ImageIcon("images/condense-x.gif")) {
				public void actionPerformed(ActionEvent e) {
					zoomPctX -= 10;
					repaint();
				}
			}
		);
		bAction.setText(null);
		bAction.setToolTipText("Condense X");
		//}
		//{ Expand in X direction.
		bAction = toolBar.add(new
			AbstractAction("expand X",
						   new ImageIcon("images/expand-x.gif")) {
				public void actionPerformed(ActionEvent e) {
					zoomPctX += 10;
					repaint();
				}
			}
		);
		bAction.setText(null);
		bAction.setToolTipText("Expand X");
		//}
		//{ Condense in Y direction.
		bAction = toolBar.add(new
			AbstractAction("condense Y",
						   new ImageIcon("images/condense-y.gif")) {
				public void actionPerformed(ActionEvent e) {
					zoomPctY -= 10;
					repaint();
				}
			}
		);
		bAction.setText(null);
		bAction.setToolTipText("Condense Y");
		//}
		//{ Expand in Y direction.
		bAction = toolBar.add(new
			AbstractAction("expand Y",
						   new ImageIcon("images/expand-y.gif")) {
				public void actionPerformed(ActionEvent e) {
					zoomPctY += 10;
					repaint();
				}
			}
		);
		bAction.setText(null);
		bAction.setToolTipText("Expand Y");
		//}
		toolBar.addSeparator();
		//{ Customize.
		bAction = toolBar.add(new
			AbstractAction("customize", createCustomIcon())
			{
				public void actionPerformed(ActionEvent e) {
					customize();
				}
			}
		);
		bAction.setText(null);
		bAction.setToolTipText("Customize");
		//}

		return toolBar;
	}

	public Dimension getPreferredSize()
	{
		//System.err.println("AnimCanvas:getPreferredSize() called.");
		return new Dimension(endX-startX, endY-startY);
	}
	
	public void setRangeX(int low, int high)
	{
		this.startX = low;
		this.endX   = high;

		int unitInc  = (endX-startX)/100;	// equals 1% of area
		if (unitInc > 0)
			scrollPane.getHorizontalScrollBar().setUnitIncrement(unitInc);

		int blockInc = (endX-startX)/20;	// equals 5% of area
		if (blockInc > 0)
			scrollPane.getHorizontalScrollBar().setBlockIncrement(blockInc);

		scrollPane.revalidate();
	}
	
	public void setRangeY(int low, int high)
	{
		this.startY = low;
		this.endY   = high;

		scrollPane.revalidate();
	}
	
	private void addAtomImpl(int animID, AnimAtom atom)
	{
		if (animAtoms == null)
			animAtoms = new ArrayList();

		animAtoms.add(animID, atom);
	}
	
	private void delAtomImpl(int key)
	{
		animAtoms.remove(key);

		if (animAtoms.isEmpty())
			animAtoms = null;
	}
	
	protected void setAtomsVisibility(boolean visible)
	{
		if (animAtoms == null || animAtoms.isEmpty())
			return;

		Iterator i = animAtoms.iterator();

		while (i.hasNext())
			((AnimAtom)i.next()).setVisible(visible);
		
		repaint();
	}

	public void showAll()
	{
		setAtomsVisibility(true);
	}
	
	public void hideAll()
	{
		setAtomsVisibility(false);
	}

	//{ public void paintChildren(Graphics g)

	public void paintChildren(Graphics g)
	{
		//System.err.println("AnimCanvas.paintChildren() called.");

		// First let JComponent do its work.
		super.paintChildren(g);

		// Early exit if we have nothing to do.
		if (animAtoms == null || animAtoms.isEmpty())
			return;

		// Clear background.
		g.setColor(getBackground());
		g.fillRect(0, 0, getSize().width, getSize().height);

		// Advance to the more sophisticated Graphics2D object.
		Graphics2D g2d = (Graphics2D) g;

		// Set the preferred rendering hints.
		g2d.setRenderingHints(renderingHints);

		// Translate over vector (-startX, -startY) to reflect
		// origin offset in userspace.
		g2d.translate(-startX, -startY);
		
		// Scale according to specified zoom factors.
		g2d.scale((double)zoomPctX/100.0, (double)zoomPctY/100.0);
		
		// Iterate over all animAtoms.
		Iterator i = animAtoms.listIterator();
		while (i.hasNext())
		{
			// Get the next AnimAtom.
			AnimAtom curAtom = (AnimAtom) i.next();
			
			// If current atom is visible, draw it.
			if (curAtom.isVisible())
			{
				Color color = (Color) colorMap.get(curAtom.getColorKey());
				curAtom.draw(g2d, this, color);
			}
		}
	}

	//}
	
	/**
	 * Create a new animation atom on the painter.
	 *
	 * @param animID the unique ID of the atom.
	 * @param type the type of atom to create.
	 *
	 * @exception IllegalArgumentException
	 *     if <code>type</code> is an illegal type.
	 *
	 * @see #ARC
	 * @see #ELLIPSE
	 * @see #IMAGE
	 * @see #LINE
	 * @see #RECTANGLE
	 * @see #TEXT
	 */
	public void createAnimAtom(int animID, String type)
	{
		AnimAtom atom;

		// Checks made in alphabetical order.
		if (type.equals(ARC))				atom = new ArcAtom();
		else if (type.equals(ELLIPSE))		atom = new EllipseAtom();
		else if (type.equals(IMAGE))		atom = new ImageAtom();
		else if (type.equals(LINE))			atom = new LineAtom();
		else if (type.equals(RECTANGLE))	atom = new RectangleAtom();
		else if (type.equals(TEXT))			atom = new TextAtom();
		else throw new IllegalArgumentException("Illegal type");
		
		addAtomImpl(animID, atom);
	}
	
	private AnimAtom getAtom(int atomID)
	{
		AnimAtom atom = (AnimAtom) animAtoms.get(atomID);

		if (atom == null)
			throw new IllegalArgumentException("no such AnimAtom: " + atomID);
		
		return atom;
	}
	
	public void setAtomLocation(int atomID, int x, int y)
	{
		getAtom(atomID).setLocation(x, y);
	}
	
	public void setAtomColor(int atomID, String colorKey)
	{
		getAtom(atomID).setColorKey(colorKey);
	}
	
	public void setAtomSolidness(int atomID, boolean solid)
	{
		getAtom(atomID).setSolid(solid);
	}
	
	public void setAtomVisibility(int atomID, boolean visible)
	{
		getAtom(atomID).setVisible(visible);
	}
	
	public Object getAtomProperty(int atomID, String propertyName)
	{
		return getAtom(atomID).getAnimProperty(propertyName);
	}

	public void setAtomProperty(int atomID, String propertyName,
								Object newValue)
	{
		getAtom(atomID).setAnimProperty(propertyName, newValue);
	}

	public void registerColor(String path, Object key, Color defaultColor)
	{
		colorMap.put(key, defaultColor);
	}

	public void setConfigPath(String configPath)
	{
		this.configPath = configPath;
		System.err.println("#C# configPath = " + configPath);
	}

	class ColorIcon implements Icon
	{
		int w;
		int h;
		Color color;
		public ColorIcon(Color c)
		{
			this(c, 12, 12);
		}
		public ColorIcon(Color c, int w, int h)
		{
			this.color = c;
			this.w = w;
			this.h = h;
		}
		public void paintIcon(Component c, Graphics g, int x, int y)
		{
			Color oldColor = g.getColor();
			g.setColor(color);
			g.fill3DRect(x, y, getIconWidth(), getIconHeight(), true);
			g.setColor(oldColor);
		}
		public int getIconWidth() { return w; }
		public int getIconHeight() { return h; }
    }
}

// vim:ts=4:sw=4
