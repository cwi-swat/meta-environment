/**
 * $Id: AnimCommand.java,v 1.1 1999/09/02 11:35:34 jong Exp $
 *
 * author: Hayco de Jong
 *
 */

package tide.tools.animviewer;

//{ Imports.

import aterm.*;

//}

public interface AnimCommand
{
	public ATerm toTerm();
}

// vim:ts=4:sw=4
