package tide.tools.sourceviewer;

//{ imports

import tide.tools.*;
import tide.debug.*;
import tide.config.*;

import java.util.*;
import java.util.List;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.*;
import javax.swing.text.Highlighter.HighlightPainter;

//}

public class SourceViewer
  extends TideTool
  implements RuleListener, WatchpointListener, MouseListener, ProcessListener
{
	//{ Constants

	private final static String TYPE_TRACKER    = "source-viewer(tracker)";
	private final static String TYPE_CPE        = "source-viewer(cpe)";
	private final static String TYPE_BREAKPOINT = "source-viewer(break)";
	private final static String TYPE_SHOWVAR    = "source-viewer(showvar)";

	private final static int HL_EXT_WATCH  = 1;
	private final static int HL_EXT_BREAK  = 2;
	private final static int HL_SV_WATCH   = 3;
	private final static int HL_SV_BREAK   = 4;

	private final static Color[] HL_COLOR = {
		null,                         // No highlights
		new Color(0x66, 0xFF, 0x66),  // HL_EXT_WATCH
		new Color(0xFF, 0x66, 0x66),  // HL_EXT_BREAK
		new Color(0x33, 0xFF, 0x33),  // HL_SV_WATCH		
		new Color(0xFF, 0x33, 0x33),  // HL_SV_BREAK
	};

	private final static Color COLOR_CPE = new Color(0xCC, 0xCC, 0xFF);

	private final static int MAX_LINE_LENGTH   = 256;

	//}

	DebugProcess process;
	SourceViewerCanvas source;
	JButton      step;
	JLabel       fileLabel;
	JLabel       locationLabel;
	JLabel       msgLabel;
	ValuePopup   popup;

	Rule trackerRule;

	FileManager files;
	SourceFile  currentFile;
	Hashtable   locationRules;

	String      variable;
	int         mouseX;
	int         mouseY;

	//{ class SourceViewerCanvas extends JComponent

	class SourceViewerCanvas 
		extends JComponent
		implements AdjustmentListener
	{
		SourceViewer viewer;
		Font font;
		FontMetrics metrics;
		SourceArea cpe;
		SourceFile source;
		JScrollBar horizontal;
		JScrollBar vertical;
		byte[] line;
		int nrLines;
		int startLine;
		int startColumn;
		int lineHeight;

		//{ Images

		private Image imgExtWatch;
		private Image imgExtBreak;
		private Image imgSVWatch;
		private Image imgSVBreak;
	
		//}

		//{ public SourceViewerCanvas(SourceViewer viewer, JScrollBar hor, vert)
		
		public SourceViewerCanvas(SourceViewer viewer, 
															JScrollBar hor, JScrollBar vert)
		{
			this.viewer = viewer;
			horizontal  = hor;
			vertical    = vert;
			font = new Font("Courier", 0, 12);
			setFont(font);
			//font = getFont();
			metrics = getFontMetrics(font);

			horizontal.setValues(0, 1, 0, 1);
			vertical.setValues(0, 1, 0, 1);
			vertical.setUnitIncrement(1);
			horizontal.addAdjustmentListener(this);
			vertical.addAdjustmentListener(this);
			
			setOpaque(true);
			setBackground(Color.white);
			line = new byte[MAX_LINE_LENGTH];

			Toolkit tk = getToolkit();
			imgSVBreak  = tk.createImage("images/sv-break.gif");
			imgSVWatch  = tk.createImage("images/sv-watch.gif");
			imgExtBreak = tk.createImage("images/ext-break.gif");
			imgExtWatch = tk.createImage("images/ext-watch.gif");
		}

		//}		

		//{ public void adjustmentValueChanged(AdjustmentEvent evt)

		/**
			* An adjustment value has changed
			*/

		public void adjustmentValueChanged(AdjustmentEvent evt)
		{
			if(evt.getSource() == horizontal)
				horizontal.repaint();
			else 
				vertical.repaint();
			repaint();
		}

		//}
		//{ public void setSource(SourceFile file)

		/**
			* The source has changed
			*/

		public void setSource(SourceFile file)
		{
			source = file;
			if(file == null)
				vertical.setValues(0, 1, 0, 1);
			else
				vertical.setValues(1, nrLines, 1, file.getNrLines());
			repaint();
		}

		//}
		//{ public void cpeChanged(SourceArea cpe)

		/**
			* The current point of execution changed
			*/

		public void cpeChanged(SourceArea area)
		{
			cpe = area;
			int rel = area.start_line-vertical.getValue();
			if(rel < 2 || rel > (nrLines-3)) {
				int newstart = area.start_line-nrLines/2;
				if(newstart < 1)
					newstart = 1;
				vertical.setValue(newstart);
			}
			repaint();
		}

		//}

		//{ public void paint(Graphics g)

		/**
			* Show the text
			*/

		public void paint(Graphics g)
		{
			g.setFont(font);
			g.setColor(getBackground());
			g.fillRect(0, 0, getSize().width, getSize().height);
			g.setColor(Color.black);

			if(source != null) {
				startLine = vertical.getValue();
				int startCol  = horizontal.getValue();
				int height = getSize().height;
				lineHeight = metrics.getMaxAscent() + metrics.getMaxDescent();

				if(nrLines != height/lineHeight) {
					nrLines = height/lineHeight;
					vertical.setBlockIncrement(nrLines);
				}
			
				for(int i=0; i<nrLines; i++) {
					int y = i*lineHeight;
					int lineNr = startLine+i;
					Vector images = new Vector();
					Vector image_positions = new Vector();


					if(lineNr > 0 && lineNr <= source.getNrLines()) {
						//{ Replace tabs with spaces

						int offset = source.getStart(lineNr);
						int end    = source.getEnd(lineNr);
						int col = 0;
						int idx = 0, len = end-offset+1;
						int[] starts = new int[len+1];
						for(int j=0; j<len; j++) {
							starts[j] = idx;
							byte b = source.text[offset+j];
							if(b == '\t') {
								line[idx++] = (byte)' ';
								for( ; (idx % source.getTabWidth()) != 0; idx++)
									line[idx] = (byte)' ';
							} else
								line[idx++] = source.text[offset+j];
						}
						starts[len] = idx;

						//}

						int highlight = 0;

						//{ Check for break/watchpoints

						java.util.List rules = viewer.getLocationRules(source.getRelativePath(),
																													 lineNr);
						if(rules != null) {
							Iterator iter = rules.iterator();
							int count = 0;
							while(iter.hasNext()) {
								Rule rule = (Rule)iter.next();
								Image img;
								count++;
								if(rule.getType().equals(TYPE_BREAKPOINT)) {
									// Created from within the sourceviewer
									if(rule.isBreak()) {
										highlight = Math.max(HL_SV_BREAK, highlight);
										img = imgSVBreak;
									} else {
										highlight = Math.max(HL_SV_WATCH, highlight);
										img = imgSVWatch;
									}
								} else {
									// Created by some outside tool
									if(rule.isBreak()) {
										highlight = Math.max(HL_EXT_BREAK, highlight);
										img = imgExtBreak;
									} else {
										highlight = Math.max(HL_EXT_WATCH, highlight);
										img = imgExtWatch;
									}
								}
								Port port = rule.getPort();
								int column = port.getLocationColumn();
								int x = metrics.bytesWidth(line, 0, column);
								images.addElement(img);
								image_positions.addElement(new Integer(x));
							}
							if(highlight > 0) {
								g.setColor(HL_COLOR[highlight]);
								g.fillRect(0, y, getSize().width, lineHeight-1);
							}
						}

						//}
						//{ Check for CPE

						if(cpe != null) {
							g.setColor(COLOR_CPE);
							boolean draw_cpe   = false;
							
							int startx = 0;
							int endx   = getSize().width;
							
							if(lineNr == cpe.start_line) {
								draw_cpe = true;
								if(cpe.start_col != 0) {
									startx = metrics.bytesWidth(line, 0, starts[cpe.start_col]);
									//System.err.println("startx = " + startx);
								}
							} 
							
							if(lineNr == cpe.end_line) {
								draw_cpe = true;
								if(cpe.end_col != -1)
									endx = metrics.bytesWidth(line, 0, starts[cpe.end_col]);
							}
							
							if(lineNr > cpe.start_line && lineNr < cpe.end_line)
								draw_cpe = true;
							
							if(draw_cpe)
								g.fillRect(startx, y, endx-startx, lineHeight-1);
						}

						//}
						//{ Paint break/watchpoint images

						for(int j=0; j<images.size(); j++) {
							Image img = (Image)images.elementAt(j);
							int x = ((Integer)image_positions.elementAt(j)).intValue();
							g.drawImage(img, x-5, y-24, this);								
						}

						//}

						g.setColor(Color.black);
						
						y += metrics.getMaxAscent();
						
						g.drawBytes(line, 0, idx, 0, y);
					}
				}
			}
		}

		//}
		//{ public int getLineNr(int x, int y)

		/**
			* Retrieve the linenumber at a certain x,y coordinate
			*/

		public int getLineNr(int x, int y)
		{
			int relLine = y/lineHeight;
			return startLine + relLine;
		}

		//}
		//{ public int getColumn(int x, int y)

		/**
			* Retrieve the column at a certain x,y coordinate
			*/

		public int getColumn(int x, int y)
		{
			int relCol = x/metrics.getMaxAdvance();
			return startColumn + relCol;
		}

		//}

	}

	//}

	//{ public SourceViewer(interface, process, fileManager)

	/**
		* Build a new SourceViewer tool
		*/

	public SourceViewer(DebugInterface iface, 
											DebugProcess process, FileManager manager)
	{
		super("Source Viewer: " + process.getID(), true, true, true, true);
		setSize(500, 350);

		this.process = process;
		this.files   = manager;
		iface.addProcessListener(this);
		process.addRuleListener(this);
		locationRules = new Hashtable();

		//{ Create UI components

		JScrollBar hor  = new JScrollBar(JScrollBar.HORIZONTAL);
		JScrollBar vert = new JScrollBar(JScrollBar.VERTICAL);
		source = new SourceViewerCanvas(this, hor, vert);

		fileLabel = new JLabel();
		locationLabel = new JLabel();
		msgLabel = new JLabel();

		source.addMouseListener(this);

		//}
		//{ Build UI

		Container content = getContentPane();
		content.setLayout(new BorderLayout());

		JPanel sourcePanel = new JPanel();
		sourcePanel.setLayout(new BorderLayout());
		sourcePanel.add(hor,  BorderLayout.SOUTH);
		sourcePanel.add(vert, BorderLayout.EAST);
		sourcePanel.add(source, BorderLayout.CENTER);
		content.add(sourcePanel, BorderLayout.CENTER);

		JPanel bottom = new JPanel();
		bottom.setLayout(new GridLayout(2,1));
		JPanel status = new JPanel();
		status.setLayout(new GridLayout(1,2));
		JPanel filePanel = new JPanel();
		filePanel.setLayout(new BorderLayout());
		filePanel.add(new JLabel("File:"), BorderLayout.WEST);
		filePanel.add(fileLabel, BorderLayout.CENTER);
		JPanel locPanel = new JPanel();
		locPanel.setLayout(new BorderLayout());
		locPanel.add(locationLabel, BorderLayout.CENTER);
		status.add(filePanel);
		status.add(locPanel);
		bottom.add(status);

		bottom.add(msgLabel);
		content.add(bottom, BorderLayout.SOUTH);

		//}
		//{ Add all existing rules for viewing

		Iterator iter = process.getRules();
		while(iter.hasNext()) {
			Rule rule = (Rule)iter.next();
			ruleCreated(rule);
		}		

		//}
		//{ Request rules to be created

		Port port;
		Condition cond;
		DebugAction acts;

		port = PortFactory.parse("stopped");
		cond = ConditionFactory.parse("true");
		acts = DebugActionFactory.parse("cpe");
		process.requestRuleCreation(TYPE_TRACKER, port, cond, acts);

		DebugAction cpe = DebugActionFactory.parse("cpe");
		process.requestEvaluation(TYPE_CPE, cpe);

		//}
	}

	//}
	//{ public String getName()

	/**
		* Retrieve the name of this tool
		*/

	public String getName()
	{
		return "sourceviewer(" + process.getID() + ")";
	}

	//}
	//{ public void cleanup()

	/**
		* Remove all rules created by this tool
		*/

	public void cleanup()
	{
		if(trackerRule != null)
			process.requestRuleDeletion(trackerRule);
		Enumeration enum = locationRules.elements();
		while(enum.hasMoreElements()) {
			Rule rule = (Rule)enum.nextElement();
			if(rule.getType().equals(TYPE_BREAKPOINT))
				process.requestRuleDeletion(rule);
		}
	}

	//}

	//{ public List getLocationRules(String file, int line)

	/**
		* Retrieve all rule at a specific line (if any)
		*/

	public java.util.List getLocationRules(String file, int line)
	{
		java.util.List rules = null;
		Hashtable table = (Hashtable)locationRules.get(file);
		if(table != null)
			rules = (java.util.List)table.get(new Integer(line));

		return rules;
	}

	//}

	//{ public void ruleCreated(Rule rule)

	/**
		* A new rule has been created
		*/

	public void ruleCreated(Rule rule)
	{
		Port port = rule.getPort();

		// source.insertIcon(Icon c)
		System.out.println("new rule: " + rule);
		if(rule.getType().equals(TYPE_TRACKER)) {
			trackerRule = rule;
			rule.requestEnabling(true);
			rule.addWatchpointListener(this);
		} else if(port.getType() == Port.PORT_LOCATION) {
			System.out.println("Location rule!");
			String file = port.getLocationFileName();
			int lineNr  = port.getLocationLineNr();
			if(rule.getType().equals(TYPE_BREAKPOINT))
				rule.requestEnabling(true);
			Hashtable table = (Hashtable)locationRules.get(file);
			if(table == null) {
				table = new Hashtable(10);
				locationRules.put(file, table);
			}
			Integer key = new Integer(lineNr);
			java.util.List rules = (java.util.List)table.get(key);
			if(rules == null) {
				rules = new LinkedList();
				table.put(key, rules);
			}
			rules.add(rule);
			source.repaint();
		}
	}

	//}
	//{ public void ruleDeleted(Rule rule)

	/**
		* An existing rule has been removed
		*/

	public void ruleDeleted(Rule rule)
	{
		Port port = rule.getPort();
		if(port.getType() == Port.PORT_LOCATION) {
			String file = port.getLocationFileName();
			int lineNr  = port.getLocationLineNr();
			Hashtable table = (Hashtable)locationRules.get(file);
			if(table != null)
				table.remove(new Integer(lineNr));
			source.repaint();
		}
	}

	//}
	//{ public void ruleModified(Rule rule)

	/**
		* A rule has been modified
		*/

	public void ruleModified(Rule rule)
	{
	}

	//}
	//{ public void ruleEnablingChanged(Rule rule)

	/**
		* The enabled status of a rule has changed
		*/
	
	public void ruleEnablingChanged(Rule rule)
	{
	}

	//}
	//{ public void evaluated(String type, DebugAction act, Value value)

	/**
		* An expression has been evaluated
		*/

	public void evaluated(String type, DebugAction act, Value value)
	{
		if(type.equals(TYPE_CPE)) {
			watchpoint(null, value);
		} else if(type.equals(TYPE_SHOWVAR)) {
			String txt = variable + "=" + value.toString();
			msgLabel.setText(txt);

			Point screenLocation = this.getLocationOnScreen();
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			Point location = new Point();

			location.x = screenLocation.x + mouseX + 30;
			location.y = screenLocation.y + mouseY + 20;

			/*
			if (location.x + size.width > screenSize.width) {
				location.x -= size.width;
			}
			if (location.y + size.height > screenSize.height) {
				location.y -= (size.height + 20);
			}
			*/

			popup = new ValuePopup(txt);
			popup.show(this, location.x, location.y);
		}
	}

	//}

	//{ public void watchpoint(Rule rule, Value value)

	/**
		* A watchpoint was triggered
		*/

	public void watchpoint(Rule rule, Value value)
	{
		if(rule == null || rule == trackerRule) {
			//{ Handle tracker-rules

			System.out.println("trackerRule triggered: " + value);
			if(value.toTerm().match("cpe(unknown)") == null) {
				if(value.isLocation()) {
					String rel = value.getLocationFile();
					System.out.println("relative path: " + rel);
					SourceFile file = null;
					try {
						file = files.getFile(rel);
						if(file == null) {
							source.setSource(null);
							fileLabel.setForeground(Color.red);
							fileLabel.setText(rel);
							locationLabel.setText("Line: -");
							msgLabel.setText("File not found: " + rel);
						}
					} catch (IOException e) {
						source.setSource(null);
						fileLabel.setForeground(Color.red);
						msgLabel.setText("IOException: " + e.getMessage());
					}
					
					if(file != null) {
						if(file != currentFile) {
							currentFile = file;
							source.setSource(file);
							fileLabel.setForeground(Color.black);
							msgLabel.setText("");
						}
						SourceArea area = file.getArea(value);
						source.cpeChanged(area);
						fileLabel.setText(file.getRelativePath());
						locationLabel.setText("Area: " + area);
					}
				}
			}

			//}
		}
	}

	//}

	//{ public void processCreated(DebugProcess process, DebugProcessGroup parent)

	/**
		* Ignore process creations
		*/

	public void processCreated(DebugProcess process, DebugProcessGroup parent)
	{
	}

	//}
	//{ public void processDestroyed(DebugProcess process)

	/**
		* Dispose this window when process is destroyed
		*/

	public void processDestroyed(DebugProcess process)
	{
		if(process == this.process) {
			trackerRule = null;
			locationRules = new Hashtable();
			dispose();
		}
	}

	//}
	//{ public void processGroupCreated(DebugProcessGroup group, DebugProcessGroup parent)

	/**
		* Ignore process group creations
		*/

	public void processGroupCreated(DebugProcessGroup group, DebugProcessGroup parent)
	{
	}

	//}
	//{ public void processGroupDestroyed(DebugProcessGroup group)

	/**
		* Look for parent destruction
		*/

	public void processGroupDestroyed(DebugProcessGroup group)
	{
		if(process.isNodeAncestor(group)) {
			trackerRule = null;
			locationRules = new Hashtable();
			dispose();
		}
	}

	//}

	//{ public void mouseClicked(MouseEvent e) 

	/**
		* The user clicked the mouse-button inside the SourceViewerCanvas
		*/

	public void mouseClicked(MouseEvent e) 
	{
	}

	//}
	//{ public void mouseEntered(MouseEvent e) 

	/**
		* The mouse pointer entered the window
		*/

	public void mouseEntered(MouseEvent e) 
	{
	}

	//}
	//{ public void mouseExited(MouseEvent e) 

	/**
		* The mouse pointer left the window
		*/

	public void mouseExited(MouseEvent e) 
	{
	}

	//}
	//{ public void mousePressed(MouseEvent e) 

	/**
		* The user pressed a mouse-button inside the SourceViewerCanvas
		* We will toggle any breakpoints under source-viewer control
		*/

	public void mousePressed(MouseEvent e) 
	{
		int lineNr = source.getLineNr(e.getX(), e.getY());
		int column = source.getColumn(e.getX(), e.getY());
		
		System.out.println("mousePressed at line: " + lineNr);
		if(e.isAltDown()) {
			if(currentFile != null) {
				byte[] text = currentFile.text;
				int start = currentFile.getStart(lineNr);
				int end   = currentFile.getEnd(lineNr);
				int cur   = start+column;
				if(process.isIdentifierChar((char)text[cur])) {
					int wordstart = cur;
					int wordend   = cur;
					while(wordstart > start && 
								process.isIdentifierChar((char)text[wordstart-1]))
						wordstart--;
					while(wordend < end && 
								process.isIdentifierChar((char)text[wordend+1]))
						wordend++;
					variable = new String(text, wordstart, wordend-wordstart+1);
					mouseX = e.getX();
					mouseY = e.getY();
					DebugAction var = DebugActionFactory.parse("var(\"" + variable +
																										 "\")");
					process.requestEvaluation(TYPE_SHOWVAR, var);
					msgLabel.setText("Looking up value of variable " + variable);
				}
			}
		} else if(e.getClickCount() >= 2) {
			// Look for existing breakpoint at this line
			Rule rule = null;
			List rules = getLocationRules(currentFile.getRelativePath(), lineNr);
			if(rules != null) {
				Iterator iter = rules.iterator();
				while(iter.hasNext()) {
					Rule r = (Rule)iter.next();
					if(r.getType().equals(TYPE_BREAKPOINT))
						rule = r;
				}
			}

			if(rule == null) {
				// Create a new breakpoint
				System.out.println("creating new breakpoint at " + lineNr + "," +
													 column);
				Port port;
				Condition cond;
				DebugAction acts;

				port = PortFactory.parse("location(pos(\"" + 
																 currentFile.getRelativePath() + "\"," +
																 lineNr + "," + column + "))");
				cond = ConditionFactory.parse("true");
				acts = DebugActionFactory.parse("break");
				process.requestRuleCreation(TYPE_BREAKPOINT, port, cond, acts);
			} else {
				// Delete existing breakpoint
				System.out.println("deleting breakpoint at " + lineNr);
				process.requestRuleDeletion(rule);
			}
		}
	}

	//}
	//{ public void mouseReleased(MouseEvent e) 

	/**
		* The user released the mouse-button inside the SourceViewerCanvas
		*/

	public void mouseReleased(MouseEvent e) 
	{
		if(popup != null) {
			popup.hide();
			popup = null;
		}
	}

	//}
}

//{ class ValuePopup extends JPanel

class ValuePopup extends JPanel
{
	final static Color COLOR_BACKGROUND = new Color(0xFF, 0xCC, 0xCC);
	final static Color COLOR_BORDER     = new Color(0x00, 0x00, 0x00);

	String value;
	Font font;
	FontMetrics metrics;


	public ValuePopup(String value)
	{
		this.value = value;
		setLayout(new BorderLayout());
		setBackground(new Color(0xFF, 0xFF, 0x00));
		this.setOpaque(true);
		setDoubleBuffered(true);
		font = new Font("Helvetica", Font.BOLD, 12);
		metrics = getFontMetrics(font);
		setSize(getPreferredSize());
	}

	public Dimension getPreferredSize()
	{
		return new Dimension(4+metrics.stringWidth(value), 
												 2 + metrics.getMaxAscent() + metrics.getMaxDescent());
	}
	
	public void paint(Graphics g)
	{
		g.setFont(font);
		g.setColor(COLOR_BACKGROUND);
		g.fillRect(0, 0, size().width, size().height);
		g.setColor(COLOR_BORDER);
		g.drawRect(0, 0, size().width-1, size().height-1);
		g.setColor(Color.black);
		g.drawString(value, 2, metrics.getMaxAscent()+1);
	}
	
	public void show(JComponent invoker, int x, int y) 
	{
		Point p = new Point(x,y);
		SwingUtilities.convertPointFromScreen(p,invoker.getRootPane().getLayeredPane());
		this.setBounds(p.x,p.y,getSize().width, getSize().height);
		System.out.println("showing popup at " + p);
		invoker.getRootPane().getLayeredPane().add(this,
																							 JLayeredPane.POPUP_LAYER,0);
		setVisible(true);
	}
	
	public void hide() 
	{
		Container parent = getParent();
		Rectangle r = this.getBounds();
		if(parent != null) {
			parent.remove(this);
			parent.repaint(r.x, r.y, r.width, r.height);
		}
	}
}

//}
