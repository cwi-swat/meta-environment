package tide.tools;

//{ imports

import tide.util.*;
import tide.debug.*;
import tide.toolbus.*;

import aterm.*;

import java.util.*;
import java.util.List;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

//}

public class ProcessViewer
  extends TideTool
  implements ProcessListener, RuleListener, WatchpointListener, Painter
{
	//{ Constants

	static final String TYPE_SEND_MSG = "process-viewer(send)";
	static final String TYPE_RECV_MSG = "process-viewer(recv)";
	static final String TYPE_STARTED  = "process-viewer(started)";
	static final String TYPE_STOPPED  = "process-viewer(stopped)";

	static final int TOOLBUS_BORDER = 20;
	static final int TOOLBUS_OUTLINE_THICKNESS = 4;

	static final int PROCESS_WIDTH             = 70;
	static final int PROCESS_HEIGHT            = 70;
	static final int PROCESS_BORDER_WIDTH      = 8;
	static final int PROCESS_BORDER_HEIGHT     = 8;
	static final int PROCESS_OUTLINE_THICKNESS = 2;
	static final int MAX_PROCESS_NAME_LENGTH   = 8;
	static final int MAX_TOOL_NAME_LENGTH      = 10;

	static final Color COLOR_TOOLBUS_INTERIOR = new Color(0x66, 0xCC, 0xFF);
	static final Color COLOR_TOOLBUS_OUTLINE  = Color.black;
	static final Color COLOR_PROCESS_INTERIOR = Color.green;
	static final Color COLOR_PROCESS_OUTLINE  = Color.darkGray;
	static final Color COLOR_PROCESS_NAME     = Color.black;
	static final Color COLOR_TOOL_INTERIOR    = new Color(0x99, 0x99, 0xFF);
	static final Color COLOR_TOOL_OUTLINE     = Color.darkGray;
	static final Color COLOR_TOOL_NAME        = Color.black;
	static final Color COLOR_MESSAGES         = new Color(0xCC, 0x00, 0x00);

	static final Font FONT = new Font("Helvetica", 0, 10);

	//}

	DebugInterface dbgInterface;
	DebugAdapter   adapter;
	SlaveCanvas    canvas;

	Hashtable send;
	Hashtable recv;

	List tools;

	//{ Geometry variables

	int nrProcesses;     // The total number of processes

	int toolbusWidth;    // Width of the ToolBus box
	int toolbusHeight;   // The height of the ToolBus box

	int totalProcWidth;  // Width of a full line of processes
	int totalProcHeight; // The height of all lines of processes together

	int procsPerLine;    // How many processes fit on one line
	int processLines;    // How many lines of processes are needed

	int processWidth;    // Width of one process cirkel
	int processHeight;   // Height of one process cirkel
	int firstTool;       // Index of first 'external process' a.k.a. 'tool'

	FontMetrics metrics;

	//}
	//{ Debug rules

	Port        portSendMsg;
	Condition   condSendMsg;
	DebugAction actSendMsg;

	Port        portRecvMsg;
	Condition   condRecvMsg;
	DebugAction actRecvMsg;

	Port        portStarted;
	Condition   condStarted;
	DebugAction actStarted;

	Port        portStopped;
	Condition   condStopped;
	DebugAction actStopped;

	List rules;

	//}

	//{ public ProcessViewer(DebugInterface dbgInterface, DebugAdapter adapter)

	/**
		* Construct a new ProcessViewer object
		*/

	public ProcessViewer(DebugInterface dbgInterface, DebugAdapter adapter)
	{
		super("Process Viewer: " + adapter.getID(), true, true, true, true);
		setSize(500, 350);

		this.dbgInterface = dbgInterface;
		this.adapter = adapter;
		send = new Hashtable();
		recv = new Hashtable();
		tools = new LinkedList();

		dbgInterface.addProcessListener(this);

		Container content = getContentPane();
		content.setLayout(new BorderLayout());
		canvas = new SlaveCanvas(this);
		content.add(canvas, "Center");

		rules = new LinkedList();

		portSendMsg = PortFactory.parse("send");
		condSendMsg = ConditionFactory.parse("true");
		actSendMsg  = DebugActionFactory.parse("msg");

		portRecvMsg = PortFactory.parse("receive");
		condRecvMsg = ConditionFactory.parse("true");
		actRecvMsg  = DebugActionFactory.parse("msg");

		portStarted = PortFactory.parse("started");
		condStarted = ConditionFactory.parse("true");
		actStarted  = DebugActionFactory.parse("state");
		
		portStopped = PortFactory.parse("stopped");
		condStopped = ConditionFactory.parse("true");
		actStopped  = DebugActionFactory.parse("state");

		Enumeration processes = adapter.children();
		while(processes.hasMoreElements()) {
			DebugProcess process = (DebugProcess)processes.nextElement();
			processCreated(process, adapter);
		}		
	}

	//}
	//{ public String getName()

	/**
		* Retrieve the name of this tool
		*/

	public String getName()
	{
		return "process-viewer(" + adapter.getID() + ")";
	}

	//}
	//{ public void cleanup()

	/**
		* Tidy things up
		*/

	public void cleanup()
	{
	}

	//}
	//{ public boolean isChild(String id)

	/**
		* Look for a child process with the specified id
		*/

	public boolean isChild(String id)
	{
		Enumeration processes = adapter.children();
		while(processes.hasMoreElements()) {
			DebugProcess process = (DebugProcess)processes.nextElement();
			if(process.getID().equals(id))
				return true;
		}

		return false;
	}

	//}

	//{ public void processCreated(DebugProcess process, DebugProcessGroup parent)

	/**
		* A new process has been created
		*/

	public void processCreated(DebugProcess process, DebugProcessGroup parent)
	{
		if(parent == adapter) {
			canvas.repaint();
			process.addRuleListener(this);
			process.requestRuleCreation(TYPE_SEND_MSG, 
																	portSendMsg, condSendMsg, actSendMsg);
			process.requestRuleCreation(TYPE_RECV_MSG, 
																	portRecvMsg, condRecvMsg, actRecvMsg);
			process.requestRuleCreation(TYPE_STARTED, 
																	portStarted, condStarted, actStarted);
			process.requestRuleCreation(TYPE_STOPPED, 
																	portStopped, condStopped, actStopped);
		}
	}

	//}
	//{ public void processDestroyed(DebugProcess process)

	/**
		* An existing process was destroyed
		*/

	public void processDestroyed(DebugProcess process)
	{
		canvas.repaint();
	}

	//}
	//{ public void processGroupCreated(DebugProcessGroup group, DebugProcessGroup parent)

	/**
		* A process-group was created
		*/

	public void processGroupCreated(DebugProcessGroup group, DebugProcessGroup parent)
	{
	}

	//}
	//{ public void processGroupDestroyed(DebugProcessGroup group)

	/**
		* A process group has been destroyed
		*/

	public void processGroupDestroyed(DebugProcessGroup group)
	{
	}

	//}

	//{ public void ruleCreated(Rule rule)

	/**
		* A rule was created
		*/

	public void ruleCreated(Rule rule)
	{
		if(rule.getType().equals(TYPE_SEND_MSG) ||
			 rule.getType().equals(TYPE_RECV_MSG) ||
			 rule.getType().equals(TYPE_STARTED) ||
			 rule.getType().equals(TYPE_STOPPED))  {
			rule.addWatchpointListener(this);
			rule.requestEnabling(true);
			rules.add(rule);
		}
	}

	//}
	//{ public void ruleDeleted(Rule rule)

	/**
		* A rule was deleted
		*/

	public void ruleDeleted(Rule rule)
	{
	}

	//}
	//{ public void ruleModified(Rule rule)

	/**
		* A rule was modified
		*/

	public void ruleModified(Rule rule)
	{
	}

	//}
	//{ public void ruleEnablingChanged(Rule rule)

	/**
		* The enabling of a rule has changed
		*/

	public void ruleEnablingChanged(Rule rule)
	{
	}

	//}
	//{ public void evaluated(String type, DebugAction act, Value value)

	/**
		* An expression has been evaluated
		*/

	public void evaluated(String type, DebugAction act, Value value)
	{
	}

	//}

	//{ public void watchpoint(Rule rule, Value value)

	/**
		* A watchpoint was triggered
		*/

	public void watchpoint(Rule rule, Value value)
	{
		if(rule.getType().equals(TYPE_SEND_MSG) ||
			 rule.getType().equals(TYPE_RECV_MSG)) {
			System.out.println("*** send rule triggered: " + value);
			Vector result = value.toTerm().match("msg(<term>,<term>,<term>)");
			if(result != null) {
				String from = result.elementAt(0).toString();
				String to = result.elementAt(1).toString();
				ATerm msg = (ATerm)result.elementAt(2);

				if(isChild(from)) {
					/* Ignore ->process recv msgs, these are handled
					 * as the send comes in! 
					 */
					if(rule.getType().equals(TYPE_RECV_MSG))
						return; 
				}	else {
					if(!tools.contains(from))
						tools.add(from);
				}

				if(!isChild(to) && !tools.contains(to))
					tools.add(to);

				send.put(from, new Msg(from, to, msg));
				recv.remove(from);
				recv.put(to, new Msg(from, to, msg));
				send.remove(to);
				repaint();
			}
		} else if(rule.getType().equals(TYPE_STARTED)) {
			Msg msg = (Msg)send.get(rule.getProcess().getID());
			if(msg != null) {
				send.remove(msg.from);
				recv.remove(msg.to);
				repaint();
			}
			msg = (Msg)recv.get(rule.getProcess().getID());
			if(msg != null) {
				send.remove(msg.from);
				recv.remove(msg.to);
				repaint();
			}
		}
	}

	//}
	//{ int getX(int index)

	/**
		* Retrieve the x-coordinate of the process at the specified index
		*/

	int getX(int index)
	{
		int col  = index % procsPerLine;
		return TOOLBUS_BORDER + col*PROCESS_WIDTH + PROCESS_BORDER_WIDTH;		
	}

	//}
	//{ int getY(int index)

	/**
		* Retrieve the y-coordinate of the process at the specified index
		*/

	int getY(int index)
	{
		if(index < firstTool) {
			int line = index/procsPerLine;
			return TOOLBUS_BORDER + line*PROCESS_HEIGHT + PROCESS_BORDER_HEIGHT;
		} else {
			index -= firstTool;
			int line = index/procsPerLine;
			return toolbusHeight + line*PROCESS_HEIGHT + PROCESS_BORDER_HEIGHT;
		}
	}

	//}
	//{ int getXCol(int col)

	/**
		* Retrieve the x-coordinate of the process at the specified index
		*/

	int getXCol(int col)
	{
		return TOOLBUS_BORDER + col*PROCESS_WIDTH + PROCESS_BORDER_WIDTH;		
	}

	//}
	//{ int getYLine(int line)

	/**
		* Retrieve the y-coordinate of the process at the specified line
		*/

	int getYLine(int line)
	{
		if(line < processLines) {
			return TOOLBUS_BORDER + line*PROCESS_HEIGHT + PROCESS_BORDER_WIDTH;
		} else {
			line -= processLines;
			return toolbusHeight + line*PROCESS_HEIGHT + PROCESS_BORDER_WIDTH;
		}
	}

	//}
	//{ int getXCol2(int col)

	/**
		* Retrieve the x-coordinate of the process at the specified 
		* fine grained index
		*/

	int getXCol2(int col)
	{
		return TOOLBUS_BORDER + col*PROCESS_WIDTH/2;
	}

	//}
	//{ int getYLine2(int line)

	/**
		* Retrieve the y-coordinate of the process at the specified line
		*/

	int getYLine2(int line)
	{
		if(line < processLines*2) {
			return TOOLBUS_BORDER + (line*PROCESS_HEIGHT)/2;
		} else {
			line -= processLines*2;
			return toolbusHeight + (line*PROCESS_HEIGHT)/2;
		}
	}

	//}

	//{ public void doPaint(SlaveCanvas canvas, Graphics g)

	/**
		* Paint the slave canvas
		*/

	public void doPaint(SlaveCanvas canvas, Graphics g)
	{
		Dimension size = canvas.getSize();
		g.setColor(Color.white);
		g.fillRect(0, 0, size.width, size.height);
		Hashtable procs = new Hashtable();

		//{ Calculate geometry 

		nrProcesses     = adapter.getChildCount();
		toolbusWidth    = size.width;
		totalProcWidth  = size.width-TOOLBUS_BORDER*2;
		procsPerLine    = totalProcWidth/PROCESS_WIDTH;
		processLines    = 1+(nrProcesses-1)/procsPerLine;
		totalProcHeight = processLines*PROCESS_HEIGHT;
		toolbusHeight   = totalProcHeight+TOOLBUS_BORDER*2;
		firstTool       = procsPerLine*processLines;

		g.setFont(FONT);
		metrics = getFontMetrics(FONT);

		//}
		
		paintToolBus(g);

		//{ Paint processes

		int index = 0;
		Enumeration processes = adapter.children();
		while(processes.hasMoreElements()) {
			DebugProcess process = (DebugProcess)processes.nextElement();
			paintProcess(g, process, index);
			procs.put(process.getID(), new Integer(index));
			index++;
		}

		//}
		//{ Paint tools

		index = firstTool;
		Iterator iter = tools.iterator();
		while(iter.hasNext()) {
			String tool = (String)iter.next();
			paintTool(g, tool, index);
			procs.put(tool, new Integer(index));
			index++;
		}

		//}
		//{ Paint messages

		Enumeration en = send.elements();
		while(en.hasMoreElements()) {
			Msg msg = (Msg)en.nextElement();
			System.out.println("paint msg: " + msg.from + " to " + msg.to + ": " +
												 msg.msg);
			int from = ((Integer)procs.get(msg.from)).intValue();
			int to   = ((Integer)procs.get(msg.to)).intValue();

			paintMessage(g, from, to, msg.msg, true);
		}

		//}
	}

	//}
	//{ void paintToolBus(Graphics g)

	/**
		* Paint the ToolBus outline
		*/

	public void paintToolBus(Graphics g)
	{
		int offset = (TOOLBUS_BORDER-TOOLBUS_OUTLINE_THICKNESS)/2;

		int w = toolbusWidth-offset*2;
		int h = toolbusHeight-offset*2;

		g.setColor(COLOR_TOOLBUS_OUTLINE);
		g.fillRect(offset, offset, w, h);
		g.setColor(COLOR_TOOLBUS_INTERIOR);
		g.fillRect(offset+TOOLBUS_OUTLINE_THICKNESS, 
							 offset+TOOLBUS_OUTLINE_THICKNESS,
							 w-TOOLBUS_OUTLINE_THICKNESS*2, h-TOOLBUS_OUTLINE_THICKNESS*2);
	}

	//}
	//{ void paintProcess(Graphics g, DebugProcess process, int index)

	/**
		* Paint a single process
		*/

	void paintProcess(Graphics g, DebugProcess process, int index)
	{
		int x = getX(index);
		int y = getY(index);
		int w = PROCESS_WIDTH-PROCESS_BORDER_WIDTH*2;
		int h = PROCESS_HEIGHT-PROCESS_BORDER_HEIGHT*2;

		/*if(w > h)
			w = h;
		else
			h = w;
		*/

		processWidth = w;
		processHeight = h;
		
		g.setColor(COLOR_PROCESS_OUTLINE);
		g.fillOval(x, y, w, h);

		g.setColor(COLOR_PROCESS_INTERIOR);
		g.fillOval(x+PROCESS_OUTLINE_THICKNESS, 
							 y+PROCESS_OUTLINE_THICKNESS, 
							 w-PROCESS_OUTLINE_THICKNESS*2, 
							 h-PROCESS_OUTLINE_THICKNESS*2);

		g.setColor(COLOR_PROCESS_NAME);
		String id = process.getID();

		int i=0, len=id.length();
		while(i<len && Character.isLetter(id.charAt(i)))
			i++;

		String first = id;
		String last  = null;
		if(i<len) {
			first = id.substring(0, i);
			last  = id.substring(i);
			len = first.length();
			if(len > MAX_PROCESS_NAME_LENGTH) {
				int to_remove = len-MAX_PROCESS_NAME_LENGTH+2;
				int prefix = len/2-to_remove/2;
				int postfix = prefix+to_remove;
				
				first = first.substring(0, prefix) + ".." + first.substring(postfix);
			}

			int first_x = x+(w-metrics.stringWidth(first))/2;
			int first_y = y+h/2-4;
			g.drawString(first, first_x, first_y);

			int last_x = x+(w-metrics.stringWidth(last))/2;
			int last_y = y+h/2+metrics.getMaxAscent();
			g.drawString(last, last_x, last_y);
		} else {
			if(len > MAX_PROCESS_NAME_LENGTH) {
				int to_remove = len-MAX_PROCESS_NAME_LENGTH+2;
				int prefix = len/2-to_remove/2;
				int postfix = prefix+to_remove;
				
				id = id.substring(0, prefix) + ".." + id.substring(postfix);
			}

			int id_x = x+(w-metrics.stringWidth(id))/2;
			int id_y = y+(h+metrics.getMaxAscent())/2;
			g.drawString(id, id_x, id_y);
		}
	}

	//}
	//{ void paintTool(Graphics g, String tool, int index)

	/**
		* Paint a single tool
		*/

	void paintTool(Graphics g, String tool, int index)
	{
		int x = getX(index);
		int y = getY(index);

		int w = PROCESS_WIDTH-PROCESS_BORDER_WIDTH*2;
		int h = PROCESS_HEIGHT-PROCESS_BORDER_HEIGHT*2;

		/*if(w > h)
			w = h;
		else
			h = w;
		*/

		processWidth = w;
		processHeight = h;
		
		g.setColor(COLOR_TOOL_OUTLINE);
		g.fillRect(x, y, w, h);

		g.setColor(COLOR_TOOL_INTERIOR);
		g.fillRect(x+PROCESS_OUTLINE_THICKNESS, 
							 y+PROCESS_OUTLINE_THICKNESS, 
							 w-PROCESS_OUTLINE_THICKNESS*2, 
							 h-PROCESS_OUTLINE_THICKNESS*2);

		g.setColor(COLOR_PROCESS_NAME);
		//String id = process.getID();
		String id = tool;

		int i=0, len=id.length();
		while(i<len && (Character.isLetter(id.charAt(i)) || 
										id.charAt(i) == '-' || id.charAt(i) == '_'))
			i++;

		String first = id;
		String last  = null;
		if(i<len) {
			first = id.substring(0, i);
			last  = id.substring(i);
			len = first.length();
			if(len > MAX_TOOL_NAME_LENGTH) {
				int to_remove = len-MAX_TOOL_NAME_LENGTH+2;
				int prefix = len/2-to_remove/2;
				int postfix = prefix+to_remove;
				
				first = first.substring(0, prefix) + ".." + first.substring(postfix);
			}

			int first_x = x+(w-metrics.stringWidth(first))/2;
			int first_y = y+h/2-1;
			g.drawString(first, first_x, first_y);

			int last_x = x+(w-metrics.stringWidth(last))/2;
			int last_y = y+h/2+metrics.getMaxAscent();
			g.drawString(last, last_x, last_y);
		} else {
			if(len > MAX_TOOL_NAME_LENGTH) {
				int to_remove = len-MAX_TOOL_NAME_LENGTH+2;
				int prefix = len/2-to_remove/2;
				int postfix = prefix+to_remove;
				
				id = id.substring(0, prefix) + ".." + id.substring(postfix);
			}

			int id_x = x+(w-metrics.stringWidth(id))/2;
			int id_y = y+(h+metrics.getMaxAscent())/2;
			g.drawString(id, id_x, id_y);
		}
	}

	//}
	//{ void paintMessage(Graphics g, int from, int to, ATerm msg, boolean send)

	/**
		* Paint a message
		*/

	void paintMessage(Graphics g, int from, int to, ATerm msg, boolean send)
	{
		int from_line = from/procsPerLine;
		int from_col  = from % procsPerLine;
		int to_line   = to/procsPerLine;
		int to_col    = to % procsPerLine;

		System.out.println("paintMessage from " + from_line + "," + from_col +
											 " to " + to_line + "," + to_col + ", send=" + send);
		g.setColor(COLOR_MESSAGES);
		if(from_line == to_line+1 && from_col == to_col) {
			paintTopConn(g, from_line, from_col, false);
			paintBottomConn(g, to_line, to_col, true);
		} else if(from_line == to_line-1 && from_col == to_col) {
			paintBottomConn(g, from_line, from_col, false);
			paintTopConn(g, to_line, to_col, true);
		} else if(from_line == to_line && from_col == to_col+1) {
			paintLeftConn(g, from_line, from_col, false);
			paintRightConn(g, to_line, to_col, true);
		} else if(from_line == to_line && from_col == to_col-1) {
			paintRightConn(g, from_line, from_col, false);
			paintLeftConn(g, to_line, to_col, true);
		} else if(from_line > to_line) {
			paintTopConn(g, from_line, from_col, false);
			if(to_col >= from_col) {
				paintHorConn(g, from_line*2, from_col*2+1, to_col*2);
				paintVerConn(g, from_line*2, to_col*2, to_line*2+2);
				paintHorConn(g, to_line*2+2, to_col*2, to_col*2+1);
			} else {
				paintHorConn(g, from_line*2, from_col*2+1, to_col*2+2);
				paintVerConn(g, from_line*2, to_col*2+2, to_line*2+2);
				paintHorConn(g, to_line*2+2, to_col*2+2, to_col*2+1);
			}
			paintBottomConn(g, to_line, to_col, true);
		} else if(from_line == to_line) {
			paintTopConn(g, from_line, from_col, false);
			paintHorConn(g, from_line*2, from_col*2+1, to_col*2+1);
			paintTopConn(g, to_line, to_col, true);
		} else {
			paintBottomConn(g, from_line, from_col, false);
			if(to_col >= from_col) {
				paintHorConn(g, from_line*2+2, from_col*2+1, to_col*2);
				paintVerConn(g, from_line*2+2, to_col*2, to_line*2);
				paintHorConn(g, to_line*2, to_col*2, to_col*2+1);
			} else {
				paintHorConn(g, from_line*2+2, from_col*2+1, to_col*2+2);
				paintVerConn(g, from_line*2+2, to_col*2+2, to_line*2);
				paintHorConn(g, to_line*2, to_col*2+2, to_col*2+1);
			}
			paintTopConn(g, to_line, to_col, true);
		}
	}

	//}
	//{ void paintRightConn(Graphics g, int line, int col, boolean arrow)

	void paintRightConn(Graphics g, int line, int col, boolean arrow)
	{
		int x = getXCol(col) + processWidth;
		int y = getYLine(line) + processHeight/2;

		g.fillRect(x, y-1, PROCESS_BORDER_WIDTH, 3);

		if(arrow) {
			g.drawLine(x, y, x+4, y-4);
			g.drawLine(x, y, x+4, y+4);
		}
	}

	//}
	//{ void paintLeftConn(Graphics g, int line, int col, boolean arrow)

	void paintLeftConn(Graphics g, int line, int col, boolean arrow)
	{
		System.out.println("paintLeftConn: " + line + "," + col + ", " + arrow);
		int x2 = getXCol(col);
		int x = x2 - PROCESS_BORDER_WIDTH;
		int y = getYLine(line) + processHeight/2;

		g.fillRect(x, y-1, x2-x, 3);

		if(arrow) {
			g.drawLine(x2-4, y-4, x2, y);
			g.drawLine(x2-4, y+4, x2, y);
		}
	}

	//}
	//{ void paintTopConn(Graphics g, int line, int col, boolean arrow)

	void paintTopConn(Graphics g, int line, int col, boolean arrow)
	{
		System.out.println("paintTopConn: " + line + "," + col + ", " + arrow);
		int x = getXCol(col) - PROCESS_BORDER_WIDTH + PROCESS_WIDTH/2;
		int y2 = getYLine(line);
		int y = y2 - PROCESS_BORDER_HEIGHT;

		g.fillRect(x-1, y, 3, y2-y);

		if(arrow) {
			g.drawLine(x, y2, x+4, y2-4);
			g.drawLine(x, y2, x-4, y2-4);
		}
	}

	//}
	//{ void paintBottomConn(Graphics g, int line, int col, boolean arrow)

	void paintBottomConn(Graphics g, int line, int col, boolean arrow)
	{
		System.out.println("paintBottomConn: " + line + "," + col + ", " + arrow);
		int x = getXCol(col) + PROCESS_WIDTH/2 - PROCESS_BORDER_WIDTH;
		int y = getYLine(line) + processHeight;
		int y2 = getYLine(line+1) - PROCESS_BORDER_HEIGHT;

		g.fillRect(x-1, y, 3, y2-y);

		if(arrow) {
			g.drawLine(x, y, x+4, y+4);
			g.drawLine(x, y, x-4, y+4);
		}
	}

	//}

	//{ void paintHorConn(Graphics g, int line, int from_col, int to_col)

	void paintHorConn(Graphics g, int line, int from_col, int to_col)
	{
		System.out.println("paintHorConn: " + line + "," + from_col + ", " + to_col);
		int from_x = getXCol2(from_col);
		int to_x = getXCol2(to_col);
		int y = getYLine2(line);

		if(to_x > from_x)
			g.fillRect(from_x, y-1, to_x-from_x, 3);
		else
			g.fillRect(to_x, y-1, from_x-to_x, 3);
	}

	//}
	//{ void paintVerConn(Graphics g, int from_line, int col, int to_line)

	void paintVerConn(Graphics g, int from_line, int col, int to_line)
	{
		System.out.println("paintVerConn: " + from_line + "," + to_line + "," + col);

		int x = getXCol2(col);
		int from_y = getYLine2(from_line);
		int to_y = getYLine2(to_line);
		
		if(from_y < to_y)
			g.fillRect(x-1, from_y, 3, to_y-from_y);
		else
			g.fillRect(x-1, to_y, 3, from_y-to_y);
	}

	//}
}

class Msg
{
	public String from;
	public String to;
	public ATerm  msg;

	public Msg(String from, String to, ATerm msg)
	{
		this.from = from;
		this.to   = to;
		this.msg  = msg;
	}
}
