package tide.tools;

//{ imports

import tide.debug.*;

import aterm.*;

import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;

//}

public class RuleTracer
  extends TideTool
  implements RuleListener, ActionListener, WatchpointListener
{
	static final int CREATE  = 0x0001;
	static final int DESTROY = 0x0002;
	static final int ENABLE  = 0x0004;
	static final int DISABLE = 0x0008;
	static final int TRIGGER = 0x0010;
	static final int EVAL    = 0x0020;

  DebugProcess process;
	java.util.List events;
	int mask;
	PrintStream output;

	JPanel      rulePanel;
	JScrollPane rulePane;
	JScrollPane tracePane;
	Hashtable   rules;

	JCheckBox   creation;
	JCheckBox   destruction;
	JCheckBox   enabling;
	JCheckBox   disabling;
	JCheckBox   triggering;
	JCheckBox   evaluation;

	JCheckBox   showID;
	JCheckBox   showType;
	JCheckBox   showPort;
	JCheckBox   showCond;
	JCheckBox   showValue;

	JCheckBox   logToFile;
	JTextField  logFile;

	JTextArea   trace;
	JButton     clear;
	JButton     close;

	//{ public RuleTracer(DebugProcess process)

	/**
		* Create a new RuleTracer
		*/

	public RuleTracer(DebugProcess process)
	{
		super("Rule Tracer: " + process.getID(), true, true, true, true);
		setSize(500, 350);

		this.process = process;
		events = new LinkedList();

		//{ Create UI components

		rulePanel   = new JPanel();
		rulePanel.setLayout(new BoxLayout(rulePanel, BoxLayout.Y_AXIS));

		rulePane    = new JScrollPane(rulePanel);
		rules       = new Hashtable();

		creation    = new JCheckBox("Create");
		destruction = new JCheckBox("Destroy");
		enabling    = new JCheckBox("Enable");
		disabling   = new JCheckBox("Disable");
		triggering  = new JCheckBox("Trigger");
		evaluation  = new JCheckBox("Eval");
		
		showID      = new JCheckBox("ID");
		showType    = new JCheckBox("Type");
		showPort    = new JCheckBox("Port");
		showCond    = new JCheckBox("Cond");
		showValue   = new JCheckBox("Value");

		trace       = new JTextArea();
		trace.setEditable(false);
		trace.setFont(new Font("Courier", 0, 10));

		logToFile   = new JCheckBox("Log to file:");
		logFile     = new JTextField("rule.trace", 10);
		clear       = new JButton("Clear");
		close       = new JButton("Close");

		//}
		//{ Construct user interface

		Container container = getContentPane();

		container.setLayout(new BorderLayout());
		rulePane.setPreferredSize(new Dimension(60, 80));

		JPanel left = new JPanel();
		JPanel top  = new JPanel();
		JPanel center = new JPanel();
		
		left.setBorder(new TitledBorder(new LineBorder(Color.darkGray), 
																		"Rules"));
		top.setBorder(new TitledBorder(new LineBorder(Color.darkGray), 
																	 "Trace Control"));
		center.setBorder(new TitledBorder(new LineBorder(Color.darkGray),
																			"Trace Output"));

		//{ Left window (containing list of rules)

		left.setLayout(new BorderLayout());
		left.add(rulePane, BorderLayout.CENTER);

		//}
		//{ Top window (containing trace control)

		top.setLayout(new GridLayout(2,6));

		top.add(new JLabel("Trace:"));
		top.add(creation);
		top.add(destruction);
		top.add(enabling);
		top.add(disabling);
		top.add(triggering);
		top.add(evaluation);

		top.add(new JLabel("Display:"));
		top.add(showID);
		top.add(showType);
		top.add(showPort);
		top.add(showCond);
		top.add(showValue);

		//}
		//{ Center window (containing trace and buttons)

		tracePane = new JScrollPane(trace);

		center.setLayout(new BorderLayout());
		center.add(tracePane, BorderLayout.CENTER);

		JPanel buttons = new JPanel();
		buttons.setLayout(new FlowLayout());
		buttons.add(logToFile);
		buttons.add(logFile);
		buttons.add(clear);
		buttons.add(close);

		center.add(buttons, BorderLayout.SOUTH);

		//}

		container.add(left, BorderLayout.WEST);
		container.add(top,  BorderLayout.NORTH);
		container.add(center, BorderLayout.CENTER);

		//}
		//{ Add listeners

		creation.addActionListener(this);
		destruction.addActionListener(this);
		enabling.addActionListener(this);
		disabling.addActionListener(this);
		triggering.addActionListener(this);
		evaluation.addActionListener(this);

		showID.addActionListener(this);
		showType.addActionListener(this);
		showPort.addActionListener(this);
		showCond.addActionListener(this);
		showValue.addActionListener(this);

		logToFile.addActionListener(this);
		logFile.addActionListener(this);
		clear.addActionListener(this);
		close.addActionListener(this);

		//}
		//{ Enable some checkboxes

		showID.setSelected(true);
		showType.setSelected(true);
		showPort.setSelected(true);
		showValue.setSelected(true);

		creation.setSelected(true);
		destruction.setSelected(true);
		enabling.setSelected(true);
		disabling.setSelected(true);
		triggering.setSelected(true);
		evaluation.setSelected(true);

		mask = CREATE | DESTROY | ENABLE | DISABLE | TRIGGER | EVAL;

		trace.setText(RuleEvent.header(showID.isSelected(), 
																	 showType.isSelected(),
																	 showPort.isSelected(), 
																	 showCond.isSelected(),
																	 showValue.isSelected()) + "\n");
		trace.append("---------------------------------------------------------\n");

		//}
		//{ Add existing rules

		Iterator iter = process.getRules();
		while(iter.hasNext()) {
			Rule rule = (Rule)iter.next();
			ruleCreated(rule);
		}

		//}

		process.addRuleListener(this);
	}

	//}

	//{ public String getName()

	/**
		* Retrieve the name of this tool
		*/

	public String getName()
	{
		return "ruletracer(" + process.getID() + ")";
	}

	//}
	//{ public void cleanup()

	/**
		* Remove all rules created by this tool
		*/

	public void cleanup()
	{
	}

	//}

	//{ public void ruleCreated(Rule rule)

	/**
		* A new rule has been created
		*/

	public void ruleCreated(Rule rule)
	{
		JCheckBox ruleBox = new JCheckBox("" + rule.getID());
		ruleBox.addActionListener(this);
		rulePanel.add(ruleBox);
		rules.put(rule, ruleBox);
		rule.addWatchpointListener(this);

		addEvent(CREATE, rule);
	}

	//}
	//{ public void ruleDeleted(Rule rule)

	/**
		* An existing rule has been removed
		*/

	public void ruleDeleted(Rule rule)
	{
		JCheckBox ruleBox = (JCheckBox)rules.get(rule);
		rulePanel.remove(ruleBox);
		rules.remove(rule);
		addEvent(DESTROY, rule);
	}

	//}
	//{ public void ruleModified(Rule rule)

	/**
		* A rule has been modified
		*/

	public void ruleModified(Rule rule)
	{
	}

	//}
	//{ public void public void watchpoint(Rule rule, Value value)

	/**
		* A rule has been triggered
		*/

	public void watchpoint(Rule rule, Value value)
	{
		addEvent(TRIGGER, rule, value);
	}

	//}
	//{ public void ruleEnablingChanged(Rule rule)

	/**
		* The enabled status of a rule has changed
		*/
	
	public void ruleEnablingChanged(Rule rule)
	{
		if(rule.isEnabled())
			addEvent(ENABLE, rule);
		else
			addEvent(DISABLE, rule);
	}

	//}
	//{ public void evaluated(String type, DebugAction act, Value val)

	/**
		* An expression has been evaluated
		*/

	public void evaluated(String type, DebugAction act, Value val)
	{
		addEvent(EVAL, new Rule(null, -1, type, null, null, act), val);
	}

	//}

	//{ public void actionPerformed(ActionEvent evt)

	/**
		* The user might have pressed a button
		*/

	public void actionPerformed(ActionEvent evt)
	{
		int oldmask = mask;
		boolean redisplay = false;

		if(evt.getSource() == creation) {
			//{ Enable/disable logging of creation

			if(creation.isSelected())
				mask |= CREATE;
			else
				mask &= ~CREATE;

			//}
		} else if(evt.getSource() == destruction) {
			//{ Enable/disable logging of destruction

			if(destruction.isSelected())
				mask |= DESTROY;
			else
				mask &= ~DESTROY;

			//}
		} else if(evt.getSource() == enabling) {
			//{ Enable/disable logging of enabling

			if(enabling.isSelected())
				mask |= ENABLE;
			else
				mask &= ~ENABLE;

			//}
		} else if(evt.getSource() == disabling) {
			//{ Enable/disable logging of disabling

			if(disabling.isSelected())
				mask |= DISABLE;
			else
				mask &= ~DISABLE;

			//}
		} else 	if(evt.getSource() == triggering) {
			//{ Enable/disable logging of triggering

			if(creation.isSelected())
				mask |= TRIGGER;
			else
				mask &= ~TRIGGER;

			//}
		} else if(evt.getSource() == showID) {
			redisplay = true;
		} else if(evt.getSource() == showType) {
			redisplay = true;
		} else if(evt.getSource() == showPort) {
			redisplay = true;
		} else if(evt.getSource() == showCond) {
			redisplay = true;
		} else if(evt.getSource() == showValue) {
			redisplay = true;
		} else if(evt.getSource() == logFile || evt.getSource() == logToFile) {
			//{ Handle file changes

			if(logToFile.isSelected()) {
				try {
					if(output != null)
						output.close();
					output = new PrintStream(new FileOutputStream(logFile.getText(), true));
				} catch (IOException e) {
					JOptionPane.showInternalMessageDialog(this, 
																								"IOException: " + e.getMessage(),
																								"Can't open log file",
																								JOptionPane.ERROR_MESSAGE);
					logToFile.setSelected(false);
				}
			} else if(output != null) {
				output.close();
				output = null;
			}

			//}
		} else if(evt.getSource() == clear) {
			//{ Clear the current trace (and optionally the log file)

			events.clear();
			if(logToFile.isSelected()) {
				try {
					if(output != null)
						output.close();
					output = new PrintStream(new FileOutputStream(logFile.getText()));
				} catch (IOException e) {
					JOptionPane.showInternalMessageDialog(this, 
																								"IOException: " + e.getMessage(),
																								"Can't open log file",
																								JOptionPane.ERROR_MESSAGE);
					logToFile.setSelected(false);
				}				
			}
			redisplay = true;

			//}
		} else if(evt.getSource() == close) {
			// Now what should we do here?
		} else {
			redisplay = true; // Probably a ruleBox toggle
		}

		if(oldmask != mask)
			redisplay = true;

		if(redisplay)
			redisplayEvents();
	}

	//}

	//{ void addEvent(int type, Rule rule)

	/**
		* Add an event without results
		*/

	void addEvent(int type, Rule rule)
	{
		addEvent(type, rule, null);
	}

	//}
	//{ void addEvent(int type, Rule rule, Value value)

	/**
		* Add an event
		*/

	void addEvent(int type, Rule rule, Value value)
	{
		System.out.println("event added: " + rule + ", mask=" + mask);

		RuleEvent event = new RuleEvent(type, rule, value);
		events.add(event);

		if((mask & type) != 0) {
			addEventToDisplay(event);
			logEvent(event);
		}
	}

	//}
	//{ void addEventToDisplay(RuleEvent event)

	/**
		* Add an event to the event display
		*/

	void addEventToDisplay(RuleEvent event)
	{
		String result;

		JCheckBox box = (JCheckBox)rules.get(event.getRule());
		if(box == null || box.isSelected()) {
			result = event.toString(showID.isSelected(), showType.isSelected(),
															showPort.isSelected(), showCond.isSelected(),
															showValue.isSelected());
			
			trace.append(result + "\n");

			JScrollBar vert = tracePane.getVerticalScrollBar();
			if(vert != null)
				vert.setValue(vert.getMaximum()-vert.getVisibleAmount()-1);
		}
	}

	//}
	//{ void logEvent(RuleEvent event)

	/**
		* Optionally write an event to the log file
		*/

	void logEvent(RuleEvent event)
	{
		String result;

		if(logToFile.isSelected()) {
			result = event.toString(true, true, true, true, true);
			output.println(result);
			output.flush();
		}
	}

	//}
	//{ void redisplayEvents()

	/**
		* Redisplay all events
		*/

	void redisplayEvents()
	{
		trace.setText(RuleEvent.header(showID.isSelected(), 
																	 showType.isSelected(),
																	 showPort.isSelected(), 
																	 showCond.isSelected(),
																	 showValue.isSelected()) + "\n");
		trace.append("---------------------------------------------------------\n");

		Iterator iter = events.iterator();
		while(iter.hasNext()) {
			RuleEvent event = (RuleEvent)iter.next();
			if((mask & event.getType()) != 0)
				addEventToDisplay(event);
		}
	}

	//}
}

//{ class RuleEvent

class RuleEvent
{
	int type;
	Rule rule;
	Value value;

	public RuleEvent(int type, Rule rule, Value value)
	{
		this.type  = type;
		this.rule  = rule;
		this.value = value;
	}

	public int getType()
	{
		return type;
	}

	public Rule getRule()
	{
		return rule;
	}

	public static String header(boolean showid, boolean showtype,
															boolean showport, boolean showcond, 
															boolean showval)
	{
		String result = " type   ";

		if(showid)
			result += "id ";
		
		if(showtype)
			result += "        rule-type         ";

		if(showport)
			result += "rule-port  ";

		if(showcond)
			result += " condtion ";
		if(showval)
			result += " value ";

		return result;
	}

	public String toString(boolean showid, boolean showtype, boolean showport,
												 boolean showcond, boolean showvalue)
	{
		String result = null;
		String txt;

		switch(type) {
			case RuleTracer.CREATE:
				result = "create  ";
				break;
			case RuleTracer.DESTROY:
				result = "destroy ";
				break;
			case RuleTracer.ENABLE:
				result = "enable  ";
				break;
			case RuleTracer.DISABLE:
				result = "disable ";
				break;
			case RuleTracer.TRIGGER:
				result = "trigger ";
				break;
			case RuleTracer.EVAL:
				result = "evaluate";
				break;
		}

		if(showid) {
			if(rule == null || rule.getID() == -1) {
				result += "   ";
			} else {
				txt = " " + rule.getID() + " "; 
				txt = txt.substring(txt.length()-3);
				result += txt + " ";
			}
		}

		if(showtype) {
			if(rule == null) {
				result += "                       ".substring(0,24);
			} else {
				txt = rule.getType() + "                        ";
				txt = txt.substring(0, 24);
				result += txt + " ";
			}
		}

		if(showport) {
			if(rule == null || rule.getPort() == null) {
				result += "           ".substring(0,10);
			} else {
				txt = rule.getPort() + "          ";
				txt = txt.substring(0, 10);
				result += txt + " ";
			}
		}
			
		if(rule != null && rule.getCondition() != null && showcond)
			result += "" + rule.getCondition() + " ";
		if(showvalue && value != null)
			result += "" + value;
			
		return result;
	}
}

//}
