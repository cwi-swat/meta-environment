/* GENERATED AUTOMATICALLY, DO NOT MODIFY */
/* Tool Interface File for tool: clock */

#include "TB.h"

/* Prototypes for functions used in event handler */
