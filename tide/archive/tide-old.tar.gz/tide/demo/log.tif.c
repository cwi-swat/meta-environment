/* GENERATED AUTOMATICALLY, DO NOT MODIFY */
/* Tool Interface File for tool: log */

#include "TB.h"

/* Prototypes for functions used in event handler */
